import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import {
  Upload,
  FileText,
  Brain,
  CheckCircle,
  AlertCircle,
  Clock,
  Zap,
  Eye,
  Settings,
} from 'lucide-react';

interface PipelineStep {
  id: string;
  name: string;
  description: string;
  status: 'pending' | 'processing' | 'completed' | 'error' | 'review';
  icon: React.ElementType;
  progress: number;
  duration?: number;
  error?: string;
}

interface PipelineStatusProps {
  steps: PipelineStep[];
  currentStep: string;
  overallProgress: number;
}

export function PipelineStatus({ steps, currentStep, overallProgress }: PipelineStatusProps) {
  const getStatusIcon = (status: PipelineStep['status']) => {
    switch (status) {
      case 'processing':
        return <Clock className="h-4 w-4 animate-spin" />;
      case 'completed':
        return <CheckCircle className="h-4 w-4" />;
      case 'error':
        return <AlertCircle className="h-4 w-4" />;
      case 'review':
        return <Eye className="h-4 w-4" />;
      default:
        return <Clock className="h-4 w-4 opacity-50" />;
    }
  };

  const getStatusBadge = (status: PipelineStep['status']) => {
    const configs = {
      pending: { label: 'Pendiente', className: 'status-pending' },
      processing: { label: 'Procesando', className: 'status-processing' },
      completed: { label: 'Completado', className: 'status-completed' },
      error: { label: 'Error', className: 'status-error' },
      review: { label: 'Revisión', className: 'status-review' },
    };
    
    const config = configs[status];
    return (
      <Badge variant="outline" className={config.className}>
        {config.label}
      </Badge>
    );
  };

  return (
    <Card className="cinema-card">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Zap className="h-5 w-5 text-primary" />
          Pipeline de Procesamiento
        </CardTitle>
        <CardDescription>
          Estado del procesamiento de documentos
        </CardDescription>
        <div className="space-y-2">
          <div className="flex justify-between text-sm">
            <span>Progreso general</span>
            <span>{overallProgress}%</span>
          </div>
          <Progress value={overallProgress} className="h-2" />
        </div>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {steps.map((step, index) => {
            const Icon = step.icon;
            const isActive = step.id === currentStep;
            const isCompleted = step.status === 'completed';
            
            return (
              <div
                key={step.id}
                className={`pipeline-step ${isActive ? 'active' : ''} ${
                  isCompleted ? 'border-green-500/30 bg-green-500/5' : 
                  isActive ? 'border-primary/30 bg-primary/5' : 
                  'border-border bg-muted/20'
                }`}
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className={`
                      p-2 rounded-lg border
                      ${isCompleted ? 'bg-green-500/20 border-green-500/30' :
                        isActive ? 'bg-primary/20 border-primary/30' :
                        'bg-muted border-border'}
                    `}>
                      <Icon className={`h-4 w-4 ${
                        isCompleted ? 'text-green-400' :
                        isActive ? 'text-primary' :
                        'text-muted-foreground'
                      }`} />
                    </div>
                    <div>
                      <h4 className="font-medium">{step.name}</h4>
                      <p className="text-sm text-muted-foreground">
                        {step.description}
                      </p>
                      {step.duration && (
                        <p className="text-xs text-muted-foreground">
                          {step.duration}ms
                        </p>
                      )}
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    {getStatusIcon(step.status)}
                    {getStatusBadge(step.status)}
                  </div>
                </div>
                
                {step.status === 'processing' && (
                  <div className="mt-3">
                    <Progress value={step.progress} className="h-1" />
                  </div>
                )}
                
                {step.error && (
                  <div className="mt-3 text-sm text-destructive bg-destructive/10 p-2 rounded">
                    {step.error}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </CardContent>
    </Card>
  );
}