import { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { useToast } from '@/hooks/use-toast';
import {
  AlertCircle,
  CheckCircle,
  FileText,
  XCircle,
  RefreshCw,
  Eye,
} from 'lucide-react';

interface ProcessingException {
  id: string;
  doc_id: string;
  stage: string;
  suggested_data: any;
  status: 'pending' | 'accepted' | 'rejected';
  filename: string;
}

export function ExceptionReview() {
  const [exceptions, setExceptions] = useState<ProcessingException[]>([]);
  const [loading, setLoading] = useState(true);
  const { toast } = useToast();

  useEffect(() => {
    fetchExceptions();
  }, []);

  const fetchExceptions = async () => {
    try {
      setLoading(true);
      
      // Simulate some exceptions for demo purposes
      const mockExceptions: ProcessingException[] = [
        {
          id: '1',
          doc_id: 'doc1',
          stage: 'classification',
          filename: 'contrato_produccion.pdf',
          status: 'pending',
          suggested_data: {
            doc_type: 'contract',
            project_code: 'FILM-2024-001',
            confidence: 0.75
          }
        },
        {
          id: '2',
          doc_id: 'doc2',
          stage: 'validation',
          filename: 'presupuesto_final.xlsx',
          status: 'pending',
          suggested_data: {
            doc_type: 'invoice',
            total_amount: 850000,
            confidence: 0.68
          }
        }
      ];
      
      setExceptions(mockExceptions);
    } catch (error) {
      console.error('Error fetching exceptions:', error);
      toast({
        title: "Error",
        description: "No se pudieron cargar las excepciones",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const handleException = async (
    exceptionId: string, 
    action: 'accepted' | 'rejected'
  ) => {
    try {
      // Update the exception status
      setExceptions(prev => prev.filter(ex => ex.id !== exceptionId));

      toast({
        title: "Excepción procesada",
        description: `La excepción ha sido ${action === 'accepted' ? 'aceptada' : 'rechazada'}`,
      });

    } catch (error) {
      console.error('Error handling exception:', error);
      toast({
        title: "Error",
        description: "No se pudo procesar la excepción",
        variant: "destructive",
      });
    }
  };

  const getStageIcon = (stage: string) => {
    switch (stage) {
      case 'classification':
        return <FileText className="h-4 w-4" />;
      case 'extraction':
        return <Eye className="h-4 w-4" />;
      case 'validation':
        return <CheckCircle className="h-4 w-4" />;
      default:
        return <AlertCircle className="h-4 w-4" />;
    }
  };

  if (loading) {
    return (
      <Card className="cinema-card">
        <CardContent className="flex items-center justify-center py-8">
          <RefreshCw className="h-6 w-6 animate-spin mr-2" />
          Cargando excepciones...
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-6">
      <Card className="cinema-card">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <AlertCircle className="h-5 w-5 text-yellow-500" />
            Revisión de Excepciones (HITL)
          </CardTitle>
          <CardDescription>
            Documentos que requieren revisión humana por baja confianza o errores
          </CardDescription>
        </CardHeader>
        <CardContent>
          {exceptions.length === 0 ? (
            <div className="text-center py-8">
              <CheckCircle className="h-12 w-12 text-green-500 mx-auto mb-4" />
              <h3 className="text-lg font-semibold mb-2">¡Todo en orden!</h3>
              <p className="text-muted-foreground">
                No hay excepciones pendientes de revisión
              </p>
            </div>
          ) : (
            <div className="space-y-4">
              {exceptions.map((exception) => (
                <Card key={exception.id} className="p-4">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      {getStageIcon(exception.stage)}
                      <div>
                        <h4 className="font-medium">{exception.filename}</h4>
                        <p className="text-sm text-muted-foreground">
                          Etapa: {exception.stage}
                        </p>
                      </div>
                    </div>
                    <div className="flex gap-2">
                      <Button
                        variant="default"
                        size="sm"
                        onClick={() => handleException(exception.id, 'accepted')}
                      >
                        <CheckCircle className="h-4 w-4 mr-2" />
                        Aceptar
                      </Button>
                      <Button
                        variant="destructive"
                        size="sm"
                        onClick={() => handleException(exception.id, 'rejected')}
                      >
                        <XCircle className="h-4 w-4 mr-2" />
                        Rechazar
                      </Button>
                    </div>
                  </div>
                  
                  {exception.suggested_data && (
                    <div className="mt-4 p-3 bg-primary/5 rounded border">
                      <h5 className="font-medium mb-2">Datos Sugeridos:</h5>
                      <pre className="text-xs overflow-auto">
                        {JSON.stringify(exception.suggested_data, null, 2)}
                      </pre>
                    </div>
                  )}
                </Card>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}