import { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { DocumentProcessor } from './DocumentProcessor';
import { ExceptionReview } from './ExceptionReview';
import { PipelineStatus } from './PipelineStatus';
import { DocumentStats } from './DocumentStats';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';
import {
  Upload,
  FileText,
  Brain,
  Eye,
  CheckCircle,
  AlertTriangle,
  BarChart3,
  Workflow,
  Settings,
  RefreshCw,
} from 'lucide-react';

export function PipelineOverview() {
  const [activeTab, setActiveTab] = useState('upload');
  const [stats, setStats] = useState({
    total: 0,
    processing: 0,
    completed: 0,
    errors: 0,
    pending_review: 0,
    average_processing_time: 0,
    success_rate: 0,
    doc_types: {} as Record<string, number>,
  });
  const [recentActivity, setRecentActivity] = useState([]);
  const [isLoading, setIsLoading] = useState(false);
  const { toast } = useToast();

  const pipelineSteps = [
    {
      id: 'collector',
      name: 'Collector',
      description: 'Recepción y almacenamiento',
      status: 'completed' as const,
      icon: Upload,
      progress: 100,
    },
    {
      id: 'classifier',
      name: 'Classifier',
      description: 'Detección de tipo y proyecto',
      status: 'processing' as const,
      icon: Brain,
      progress: 75,
    },
    {
      id: 'parser',
      name: 'Parser',
      description: 'Extracción de texto y OCR',
      status: 'pending' as const,
      icon: FileText,
      progress: 0,
    },
    {
      id: 'extractor',
      name: 'Extractor LLM',
      description: 'Estructuración con JSON Schema',
      status: 'pending' as const,
      icon: Brain,
      progress: 0,
    },
    {
      id: 'validator',
      name: 'Validator',
      description: 'Validación de reglas de negocio',
      status: 'pending' as const,
      icon: CheckCircle,
      progress: 0,
    },
    {
      id: 'publisher',
      name: 'Publisher',
      description: 'Mapeo a tablas destino',
      status: 'pending' as const,
      icon: CheckCircle,
      progress: 0,
    },
  ];

  const loadStats = async () => {
    setIsLoading(true);
    try {
      // Mock stats for now - replace with actual queries when types are available
      const mockStats = {
        total: 156,
        processing: 8,
        completed: 142,
        errors: 4,
        pending_review: 2,
        average_processing_time: 3500,
        success_rate: 91.2,
        doc_types: {
          contract: 45,
          invoice: 38,
          proposal: 32,
          legal: 25,
          other: 16,
        },
      };
      
      setStats(mockStats);
      
      // Mock recent activity
      setRecentActivity([
        {
          id: '1',
          type: 'document_processed',
          message: 'Contrato de distribución procesado',
          timestamp: new Date().toISOString(),
          status: 'completed',
        },
        {
          id: '2',
          type: 'exception_created',
          message: 'Factura requiere revisión manual',
          timestamp: new Date(Date.now() - 300000).toISOString(),
          status: 'review',
        },
      ]);
    } catch (error) {
      console.error('Error loading stats:', error);
      toast({
        title: 'Error',
        description: 'No se pudieron cargar las estadísticas',
        variant: 'destructive',
      });
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    loadStats();
  }, []);

  const getActivityIcon = (type: string) => {
    switch (type) {
      case 'document_processed':
        return <CheckCircle className="h-4 w-4 text-green-400" />;
      case 'exception_created':
        return <AlertTriangle className="h-4 w-4 text-orange-400" />;
      default:
        return <FileText className="h-4 w-4 text-muted-foreground" />;
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold text-gradient-primary">
            Pipeline de Documentos
          </h1>
          <p className="text-muted-foreground">
            Sistema completo de ingesta y procesamiento
          </p>
        </div>
        <Button onClick={loadStats} variant="outline" disabled={isLoading}>
          <RefreshCw className={`h-4 w-4 mr-2 ${isLoading ? 'animate-spin' : ''}`} />
          Actualizar
        </Button>
      </div>

      {/* Stats Overview */}
      <DocumentStats stats={stats} />

      {/* Main Pipeline Interface */}
      <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
        <TabsList className="grid w-full grid-cols-5">
          <TabsTrigger value="upload" className="flex items-center gap-2">
            <Upload className="h-4 w-4" />
            <span className="hidden sm:inline">Subir</span>
          </TabsTrigger>
          <TabsTrigger value="pipeline" className="flex items-center gap-2">
            <Workflow className="h-4 w-4" />
            <span className="hidden sm:inline">Pipeline</span>
          </TabsTrigger>
          <TabsTrigger value="exceptions" className="flex items-center gap-2">
            <Eye className="h-4 w-4" />
            <span className="hidden sm:inline">Excepciones</span>
          </TabsTrigger>
          <TabsTrigger value="analytics" className="flex items-center gap-2">
            <BarChart3 className="h-4 w-4" />
            <span className="hidden sm:inline">Analytics</span>
          </TabsTrigger>
          <TabsTrigger value="settings" className="flex items-center gap-2">
            <Settings className="h-4 w-4" />
            <span className="hidden sm:inline">Config</span>
          </TabsTrigger>
        </TabsList>

        <TabsContent value="upload" className="space-y-6">
          <DocumentProcessor />
        </TabsContent>

        <TabsContent value="pipeline" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <div className="lg:col-span-2">
              <PipelineStatus
                steps={pipelineSteps}
                currentStep="classifier"
                overallProgress={35}
              />
            </div>
            <div className="space-y-4">
              <Card className="cinema-card">
                <CardHeader>
                  <CardTitle className="text-lg">Actividad Reciente</CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  {recentActivity.map((activity: any) => (
                    <div key={activity.id} className="flex items-start gap-3 p-2 rounded border border-border">
                      {getActivityIcon(activity.type)}
                      <div className="flex-1">
                        <p className="text-sm">{activity.message}</p>
                        <p className="text-xs text-muted-foreground">
                          {new Date(activity.timestamp).toLocaleTimeString()}
                        </p>
                      </div>
                    </div>
                  ))}
                </CardContent>
              </Card>
            </div>
          </div>
        </TabsContent>

        <TabsContent value="exceptions" className="space-y-6">
          <ExceptionReview />
        </TabsContent>

        <TabsContent value="analytics" className="space-y-6">
          <Card className="cinema-card">
            <CardHeader>
              <CardTitle>Analytics Avanzado</CardTitle>
              <CardDescription>
                Métricas detalladas del pipeline de procesamiento
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="text-center py-12">
                <BarChart3 className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                <p className="text-muted-foreground">
                  Analytics detallado próximamente
                </p>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="settings" className="space-y-6">
          <Card className="cinema-card">
            <CardHeader>
              <CardTitle>Configuración del Pipeline</CardTitle>
              <CardDescription>
                Ajustes y configuración del sistema de procesamiento
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="text-center py-12">
                <Settings className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                <p className="text-muted-foreground">
                  Panel de configuración próximamente
                </p>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}