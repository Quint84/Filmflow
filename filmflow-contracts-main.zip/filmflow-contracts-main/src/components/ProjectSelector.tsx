import { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Badge } from '@/components/ui/badge';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';
import { Folder, Plus, FolderOpen, Calendar, User } from 'lucide-react';

interface Project {
  id: string;
  project_code: string;
  project_title: string;
  project_status: string;
  created_at: string;
  production_company?: string;
  director?: string;
}

interface ProjectSelectorProps {
  isOpen: boolean;
  onClose: () => void;
  onProjectSelected: (projectCode: string) => void;
  fileName: string;
}

export function ProjectSelector({ isOpen, onClose, onProjectSelected, fileName }: ProjectSelectorProps) {
  const [projects, setProjects] = useState<Project[]>([]);
  const [loading, setLoading] = useState(false);
  const [showCreateForm, setShowCreateForm] = useState(false);
  const [selectedProjectCode, setSelectedProjectCode] = useState<string>('');
  const { toast } = useToast();

  // New project form state
  const [newProject, setNewProject] = useState({
    project_code: '',
    project_title: '',
    project_status: 'development',
    format: 'feature',
    production_company: '',
    director: '',
  });

  useEffect(() => {
    if (isOpen) {
      fetchProjects();
    }
  }, [isOpen]);

  const fetchProjects = async () => {
    setLoading(true);
    try {
      const { data, error } = await supabase
        .from('projects')
        .select('id, project_code, project_title, project_status, created_at, production_company, director')
        .order('created_at', { ascending: false });

      if (error) throw error;
      setProjects(data || []);
    } catch (error) {
      console.error('Error fetching projects:', error);
      toast({
        title: "Error",
        description: "No se pudieron cargar los proyectos",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const createProject = async () => {
    if (!newProject.project_code || !newProject.project_title) {
      toast({
        title: "Campos requeridos",
        description: "Código de proyecto y título son obligatorios",
        variant: "destructive",
      });
      return;
    }

    try {
      const { data: user } = await supabase.auth.getUser();
      if (!user.user) throw new Error('No authenticated user');

      const { error } = await supabase
        .from('projects')
        .insert({
          project_code: newProject.project_code,
          project_title: newProject.project_title,
          project_status: newProject.project_status,
          format: newProject.format,
          production_company: newProject.production_company,
          director: newProject.director,
          user_id: user.user.id,
        });

      if (error) throw error;

      toast({
        title: "Proyecto creado",
        description: `Proyecto ${newProject.project_code} creado exitosamente`,
      });

      // Reset form and refresh projects
      setNewProject({
        project_code: '',
        project_title: '',
        project_status: 'development',
        format: 'feature',
        production_company: '',
        director: '',
      });
      setShowCreateForm(false);
      
      // Use the new project
      onProjectSelected(newProject.project_code);
      onClose();
      
    } catch (error) {
      console.error('Error creating project:', error);
      toast({
        title: "Error",
        description: "No se pudo crear el proyecto",
        variant: "destructive",
      });
    }
  };

  const handleProjectSelect = () => {
    if (selectedProjectCode) {
      onProjectSelected(selectedProjectCode);
      onClose();
    }
  };

  const getStatusColor = (status: string) => {
    const colors = {
      development: 'bg-blue-100 text-blue-800',
      pre_production: 'bg-yellow-100 text-yellow-800',
      production: 'bg-green-100 text-green-800',
      post_production: 'bg-purple-100 text-purple-800',
      completed: 'bg-gray-100 text-gray-800',
      distribution: 'bg-indigo-100 text-indigo-800',
      archived: 'bg-red-100 text-red-800',
    };
    return colors[status as keyof typeof colors] || 'bg-gray-100 text-gray-800';
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Folder className="h-5 w-5" />
            Asignar documento a proyecto
          </DialogTitle>
          <DialogDescription>
            Selecciona un proyecto existente o crea uno nuevo para: <strong>{fileName}</strong>
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4">
          {/* Create New Project Toggle */}
          <div className="flex gap-2">
            <Button 
              variant={!showCreateForm ? "default" : "outline"}
              onClick={() => setShowCreateForm(false)}
              className="flex-1"
            >
              <FolderOpen className="h-4 w-4 mr-2" />
              Seleccionar Existente
            </Button>
            <Button 
              variant={showCreateForm ? "default" : "outline"}
              onClick={() => setShowCreateForm(true)}
              className="flex-1"
            >
              <Plus className="h-4 w-4 mr-2" />
              Crear Nuevo
            </Button>
          </div>

          {showCreateForm ? (
            /* Create New Project Form */
            <Card>
              <CardHeader>
                <CardTitle>Crear Nuevo Proyecto</CardTitle>
                <CardDescription>
                  Completa los datos básicos del proyecto
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="project_code">Código de Proyecto *</Label>
                    <Input
                      id="project_code"
                      placeholder="FILM-2024-001"
                      value={newProject.project_code}
                      onChange={(e) => setNewProject(prev => ({ ...prev, project_code: e.target.value }))}
                    />
                  </div>
                  <div>
                    <Label htmlFor="project_status">Estado</Label>
                    <Select 
                      value={newProject.project_status}
                      onValueChange={(value) => setNewProject(prev => ({ ...prev, project_status: value }))}
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="development">Desarrollo</SelectItem>
                        <SelectItem value="pre_production">Pre-producción</SelectItem>
                        <SelectItem value="production">Producción</SelectItem>
                        <SelectItem value="post_production">Post-producción</SelectItem>
                        <SelectItem value="completed">Completado</SelectItem>
                        <SelectItem value="distribution">Distribución</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <div>
                  <Label htmlFor="project_title">Título del Proyecto *</Label>
                  <Input
                    id="project_title"
                    placeholder="Nombre del proyecto"
                    value={newProject.project_title}
                    onChange={(e) => setNewProject(prev => ({ ...prev, project_title: e.target.value }))}
                  />
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="format">Formato</Label>
                    <Select 
                      value={newProject.format}
                      onValueChange={(value) => setNewProject(prev => ({ ...prev, format: value }))}
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="feature">Largometraje</SelectItem>
                        <SelectItem value="series">Serie</SelectItem>
                        <SelectItem value="short">Cortometraje</SelectItem>
                        <SelectItem value="documentary">Documental</SelectItem>
                        <SelectItem value="animation">Animación</SelectItem>
                        <SelectItem value="other">Otro</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <Label htmlFor="production_company">Productora</Label>
                    <Input
                      id="production_company"
                      placeholder="Nombre de la productora"
                      value={newProject.production_company}
                      onChange={(e) => setNewProject(prev => ({ ...prev, production_company: e.target.value }))}
                    />
                  </div>
                </div>

                <div>
                  <Label htmlFor="director">Director</Label>
                  <Input
                    id="director"
                    placeholder="Nombre del director"
                    value={newProject.director}
                    onChange={(e) => setNewProject(prev => ({ ...prev, director: e.target.value }))}
                  />
                </div>

                <div className="flex justify-end gap-2 pt-4">
                  <Button variant="outline" onClick={() => setShowCreateForm(false)}>
                    Cancelar
                  </Button>
                  <Button onClick={createProject}>
                    Crear Proyecto
                  </Button>
                </div>
              </CardContent>
            </Card>
          ) : (
            /* Select Existing Project */
            <div className="space-y-4">
              {loading ? (
                <div className="text-center py-8">
                  <div className="text-muted-foreground">Cargando proyectos...</div>
                </div>
              ) : projects.length === 0 ? (
                <div className="text-center py-8">
                  <div className="text-muted-foreground mb-4">No hay proyectos disponibles</div>
                  <Button onClick={() => setShowCreateForm(true)}>
                    <Plus className="h-4 w-4 mr-2" />
                    Crear Primer Proyecto
                  </Button>
                </div>
              ) : (
                <>
                  <div className="max-h-60 overflow-y-auto space-y-2">
                    {projects.map((project) => (
                      <Card 
                        key={project.id}
                        className={`cursor-pointer transition-colors hover:bg-accent ${
                          selectedProjectCode === project.project_code ? 'ring-2 ring-primary' : ''
                        }`}
                        onClick={() => setSelectedProjectCode(project.project_code)}
                      >
                        <CardContent className="p-4">
                          <div className="flex items-center justify-between">
                            <div className="space-y-1">
                              <div className="flex items-center gap-2">
                                <h4 className="font-medium">{project.project_title}</h4>
                                <Badge className={getStatusColor(project.project_status)}>
                                  {project.project_status}
                                </Badge>
                              </div>
                              <div className="text-sm text-muted-foreground">
                                Código: {project.project_code}
                              </div>
                              {(project.production_company || project.director) && (
                                <div className="text-xs text-muted-foreground">
                                  {project.production_company && (
                                    <span className="flex items-center gap-1">
                                      <User className="h-3 w-3" />
                                      {project.production_company}
                                    </span>
                                  )}
                                  {project.director && (
                                    <span>Dir: {project.director}</span>
                                  )}
                                </div>
                              )}
                            </div>
                            <div className="text-xs text-muted-foreground">
                              <Calendar className="h-3 w-3 inline mr-1" />
                              {new Date(project.created_at).toLocaleDateString()}
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                  </div>

                  <div className="flex justify-end gap-2 pt-4">
                    <Button variant="outline" onClick={onClose}>
                      Cancelar
                    </Button>
                    <Button 
                      onClick={handleProjectSelect}
                      disabled={!selectedProjectCode}
                    >
                      Asignar a Proyecto
                    </Button>
                  </div>
                </>
              )}
            </div>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}