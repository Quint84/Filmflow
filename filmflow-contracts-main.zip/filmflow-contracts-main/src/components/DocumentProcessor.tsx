import { useState, useCallback } from 'react';
import { useDropzone } from 'react-dropzone';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { ScrollArea } from '@/components/ui/scroll-area';
import { ProjectSelector } from '@/components/ProjectSelector';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';
import {
  FileText,
  Upload,
  Eye,
  Zap,
  CheckCircle,
  AlertCircle,
  Download,
  Loader2,
  Folder,
} from 'lucide-react';

interface ProcessingResult {
  id: string;
  filename: string;
  status: 'processing' | 'completed' | 'error' | 'pending_project';
  progress: number;
  extractedText?: string;
  structuredData?: any;
  error?: string;
  processingTime?: number;
  file?: File;
  projectCode?: string;
}

export function DocumentProcessor() {
  const [files, setFiles] = useState<ProcessingResult[]>([]);
  const [isProcessing, setIsProcessing] = useState(false);
  const [showProjectSelector, setShowProjectSelector] = useState(false);
  const [currentFile, setCurrentFile] = useState<ProcessingResult | null>(null);
  const { toast } = useToast();

  const onDrop = useCallback(async (acceptedFiles: File[]) => {
    const newFiles = acceptedFiles.map(file => ({
      id: crypto.randomUUID(),
      filename: file.name,
      status: 'pending_project' as const,
      progress: 0,
      file,
    }));

    setFiles(prev => [...prev, ...newFiles]);

    // Show project selector for the first file
    if (newFiles.length > 0) {
      setCurrentFile(newFiles[0]);
      setShowProjectSelector(true);
    }
  }, []);

  const onProjectSelected = async (projectCode: string) => {
    if (!currentFile) return;

    // Update current file with project code
    updateFileStatus(currentFile.id, { 
      projectCode,
      status: 'processing',
      progress: 10
    });

    setIsProcessing(true);

    try {
      // Process the current file
      await processDocument(currentFile.file!, currentFile.id, projectCode);
      
      // Check if there are more files waiting for project assignment
      const pendingFiles = files.filter(f => f.status === 'pending_project' && f.id !== currentFile.id);
      if (pendingFiles.length > 0) {
        setCurrentFile(pendingFiles[0]);
        setShowProjectSelector(true);
      } else {
        setCurrentFile(null);
        setIsProcessing(false);
      }
    } catch (error) {
      console.error('Error processing document:', error);
      updateFileStatus(currentFile.id, {
        status: 'error',
        error: error instanceof Error ? error.message : 'Error desconocido',
        progress: 100,
      });
      setIsProcessing(false);
    }
  };

  const updateFileStatus = (fileId: string, updates: Partial<ProcessingResult>) => {
    setFiles(prev => prev.map(file => 
      file.id === fileId ? { ...file, ...updates } : file
    ));
  };

  const processDocument = async (file: File, fileId: string, projectCode: string) => {
    const startTime = Date.now();
    
    try {
      // Step 1: Upload to Supabase Storage (20%)
      updateFileStatus(fileId, { progress: 20 });
      
      const fileExt = file.name.split('.').pop();
      const fileName = `${Date.now()}-${file.name}`;
      const uploadPath = `pending/${fileName}`;
      
      const { error: uploadError } = await supabase.storage
        .from('documents')
        .upload(uploadPath, file);

      if (uploadError) throw uploadError;

      // Step 2: Create doc_index entry (40%)
      updateFileStatus(fileId, { progress: 40 });
      
      const { data: docResult, error: docError } = await supabase
        .from('doc_index')
        .insert({
          file_name: file.name,
          file_path: uploadPath,
          status: 'uploaded',
          project_code: projectCode,
          user_id: (await supabase.auth.getUser()).data.user?.id
        })
        .select('id')
        .single();

      if (docError) throw docError;

      // Step 3: Run document collector (50%)
      updateFileStatus(fileId, { progress: 50 });
      
      const { data: collectorResult, error: collectorError } = await supabase.functions.invoke('doc-collector', {
        body: {
          fileName: file.name,
          docId: docResult.id,
          uploadPath,
        },
      });

      if (collectorError) throw collectorError;

      // Step 4: Parse document and extract text (60%)
      updateFileStatus(fileId, { progress: 60 });
      
      const { data: parseResult, error: parseError } = await supabase.functions.invoke('doc-parser', {
        body: {
          docId: docResult.id,
        },
      });

      if (parseError) throw parseError;

      // Step 5: Run LLM Orchestrator for extraction (75%)
      updateFileStatus(fileId, { progress: 75 });
      
      const { data: extractResult, error: extractError } = await supabase.functions.invoke('llm-orchestrator', {
        body: {
          docId: docResult.id,
          action: 'extract'
        },
      });

      if (extractError) throw extractError;

      // Step 6: Run LLM Orchestrator for classification (90%)
      updateFileStatus(fileId, { progress: 90 });
      
      const { data: classifyResult, error: classifyError } = await supabase.functions.invoke('llm-orchestrator', {
        body: {
          docId: docResult.id,
          action: 'classify'
        },
      });

      if (classifyError) throw classifyError;

      // Step 7: Complete (100%)
      const processingTime = Date.now() - startTime;
      updateFileStatus(fileId, {
        status: 'completed',
        progress: 100,
        extractedText: `Documento procesado por Nostromo LLM Orchestrator
Tipo: ${extractResult.result.document_type}
Confianza: ${(extractResult.result.confidence_score * 100).toFixed(1)}%
Preocupaciones: ${Array.isArray(extractResult.result.extraction_concerns) ? extractResult.result.extraction_concerns.join(', ') : 'Ninguna'}`,
        structuredData: {
          ...extractResult.result,
          classification: classifyResult.result
        },
        processingTime,
      });

      toast({
        title: "Documento procesado",
        description: `${file.name} se ha procesado correctamente en ${(processingTime / 1000).toFixed(1)}s`,
      });

    } catch (error) {
      console.error('Processing error:', error);
      updateFileStatus(fileId, {
        status: 'error',
        error: error instanceof Error ? error.message : 'Error en el procesamiento',
        progress: 100,
      });

      toast({
        title: "Error en el procesamiento",
        description: `No se pudo procesar ${file.name}`,
        variant: "destructive",
      });
    }
  };

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop,
    accept: {
      'application/pdf': ['.pdf'],
      'image/*': ['.png', '.jpg', '.jpeg', '.gif', '.bmp', '.tiff'],
      'application/msword': ['.doc'],
      'application/vnd.openxmlformats-officedocument.wordprocessingml.document': ['.docx'],
    },
    multiple: true,
  });

  const getStatusIcon = (status: ProcessingResult['status']) => {
    switch (status) {
      case 'pending_project':
        return <Folder className="h-4 w-4 text-yellow-500" />;
      case 'processing':
        return <Loader2 className="h-4 w-4 animate-spin text-blue-500" />;
      case 'completed':
        return <CheckCircle className="h-4 w-4 text-green-500" />;
      case 'error':
        return <AlertCircle className="h-4 w-4 text-red-500" />;
    }
  };

  const getStatusBadge = (status: ProcessingResult['status']) => {
    const configs = {
      pending_project: { label: 'Esperando Proyecto', variant: 'secondary' as const },
      processing: { label: 'Procesando', variant: 'secondary' as const },
      completed: { label: 'Completado', variant: 'default' as const },
      error: { label: 'Error', variant: 'destructive' as const },
    };
    
    const config = configs[status];
    return <Badge variant={config.variant}>{config.label}</Badge>;
  };

  return (
    <div className="space-y-6">
      {/* Upload Area */}
      <Card className="cinema-card">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Zap className="h-5 w-5 text-primary" />
            Procesador de Documentos
          </CardTitle>
          <CardDescription>
            OCR local → Extracción de texto relevante → LLM con JSON Schema
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div
            {...getRootProps()}
            className={`border-2 border-dashed rounded-lg p-8 text-center cursor-pointer transition-colors
              ${isDragActive 
                ? 'border-primary bg-primary/5' 
                : 'border-border hover:border-primary/50'
              }`}
          >
            <input {...getInputProps()} />
            <Upload className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
            <h3 className="text-lg font-semibold mb-2">
              {isDragActive ? 'Suelta los archivos aquí' : 'Arrastra archivos o haz clic para seleccionar'}
            </h3>
            <p className="text-muted-foreground">
              Soporta PDF, imágenes, DOC, DOCX
            </p>
          </div>
        </CardContent>
      </Card>

      {/* Processing Results */}
      {files.length > 0 && (
        <Card className="cinema-card">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <FileText className="h-5 w-5 text-primary" />
              Resultados del Procesamiento
            </CardTitle>
            <CardDescription>
              {files.filter(f => f.status === 'completed').length} de {files.length} documentos procesados
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {files.map((file) => (
                <Card key={file.id} className="p-4">
                  <div className="flex items-center justify-between mb-3">
                    <div className="flex items-center gap-3">
                      {getStatusIcon(file.status)}
                        <div>
                          <h4 className="font-medium">{file.filename}</h4>
                          {file.projectCode && (
                            <p className="text-xs text-muted-foreground">
                              Proyecto: {file.projectCode}
                            </p>
                          )}
                          {file.processingTime && (
                            <p className="text-xs text-muted-foreground">
                              Procesado en {(file.processingTime / 1000).toFixed(1)}s
                            </p>
                          )}
                        </div>
                    </div>
                    {getStatusBadge(file.status)}
                  </div>

                  <Progress value={file.progress} className="mb-3" />

                  {file.error && (
                    <div className="text-sm text-destructive bg-destructive/10 p-2 rounded">
                      {file.error}
                    </div>
                  )}

                  {file.status === 'completed' && (file.extractedText || file.structuredData) && (
                    <Tabs defaultValue="text" className="mt-4">
                      <TabsList className="grid w-full grid-cols-2">
                        <TabsTrigger value="text">Texto Extraído</TabsTrigger>
                        <TabsTrigger value="structured">Datos Estructurados</TabsTrigger>
                      </TabsList>
                      
                      <TabsContent value="text" className="mt-4">
                        <ScrollArea className="h-32 w-full rounded border p-3">
                          <pre className="text-sm whitespace-pre-wrap">
                            {file.extractedText || 'No se extrajo texto'}
                          </pre>
                        </ScrollArea>
                      </TabsContent>
                      
                      <TabsContent value="structured" className="mt-4">
                        <ScrollArea className="h-32 w-full rounded border p-3">
                          <pre className="text-sm">
                            {JSON.stringify(file.structuredData, null, 2)}
                          </pre>
                        </ScrollArea>
                      </TabsContent>
                    </Tabs>
                  )}
                </Card>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Project Selector Dialog */}
      <ProjectSelector
        isOpen={showProjectSelector}
        onClose={() => {
          setShowProjectSelector(false);
          setCurrentFile(null);
        }}
        onProjectSelected={onProjectSelected}
        fileName={currentFile?.filename || ''}
      />
    </div>
  );
}