import { Link, useLocation } from 'react-router-dom';
import { useAuth } from '@/hooks/useAuth';
import { Button } from '@/components/ui/button';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { Badge } from '@/components/ui/badge';
import {
  Film,
  FolderOpen,
  FileText,
  Users,
  Settings,
  LogOut,
  BarChart3,
  Shield,
} from 'lucide-react';

const navigationItems = [
  {
    title: 'Proyectos',
    href: '/',
    icon: FolderOpen,
    roles: ['ADMIN', 'PRODUCER', 'LP_FINANCE', 'LEGAL', 'SALES', 'HOD'],
  },
  {
    title: 'Documentos',
    href: '/documents',
    icon: FileText,
    roles: ['ADMIN', 'PRODUCER', 'LP_FINANCE', 'LEGAL', 'SALES'],
  },
  {
    title: 'Equipo',
    href: '/team',
    icon: Users,
    roles: ['ADMIN', 'PRODUCER'],
  },
  {
    title: 'Analytics',
    href: '/analytics',
    icon: BarChart3,
    roles: ['ADMIN', 'PRODUCER', 'LP_FINANCE'],
  },
  {
    title: 'Admin',
    href: '/admin',
    icon: Shield,
    roles: ['ADMIN'],
  },
];

export function Navigation() {
  const { profile, signOut, hasRole } = useAuth();
  const location = useLocation();

  const visibleItems = navigationItems.filter(item =>
    item.roles.some(role => hasRole(role))
  );

  const getUserInitials = (name: string | null) => {
    if (!name) return 'U';
    return name
      .split(' ')
      .map(n => n[0])
      .join('')
      .toUpperCase()
      .slice(0, 2);
  };

  const getRoleBadgeColor = (roles: string[]) => {
    if (roles.includes('ADMIN')) return 'bg-red-500/20 text-red-400 border-red-500/30';
    if (roles.includes('PRODUCER')) return 'bg-blue-500/20 text-blue-400 border-blue-500/30';
    if (roles.includes('LP_FINANCE')) return 'bg-green-500/20 text-green-400 border-green-500/30';
    if (roles.includes('LEGAL')) return 'bg-purple-500/20 text-purple-400 border-purple-500/30';
    if (roles.includes('SALES')) return 'bg-orange-500/20 text-orange-400 border-orange-500/30';
    return 'bg-gray-500/20 text-gray-400 border-gray-500/30';
  };

  const getPrimaryRole = (roles: string[]) => {
    const roleOrder = ['ADMIN', 'PRODUCER', 'LP_FINANCE', 'LEGAL', 'SALES', 'HOD', 'INVESTOR_VIEW'];
    for (const role of roleOrder) {
      if (roles.includes(role)) return role;
    }
    return roles[0] || 'USER';
  };

  return (
    <nav className="border-b border-border bg-card/50 backdrop-blur-sm sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          {/* Logo */}
          <Link to="/" className="flex items-center gap-2 hover:opacity-80 cinema-transition">
            <Film className="h-6 w-6 text-primary cinema-glow" />
            <span className="text-xl font-bold text-gradient-primary">
              FilmFlow
            </span>
          </Link>

          {/* Navigation Items */}
          <div className="hidden md:flex items-center space-x-1">
            {visibleItems.map((item) => {
              const isActive = location.pathname === item.href;
              const Icon = item.icon;
              
              return (
                <Link
                  key={item.href}
                  to={item.href}
                  className={`
                    flex items-center gap-2 px-3 py-2 rounded-lg text-sm font-medium cinema-transition
                    ${isActive 
                      ? 'bg-primary/20 text-primary border border-primary/30' 
                      : 'text-muted-foreground hover:text-foreground hover:bg-secondary/50'
                    }
                  `}
                >
                  <Icon className="h-4 w-4" />
                  {item.title}
                </Link>
              );
            })}
          </div>

          {/* User Menu */}
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" size="sm" className="gap-2">
                <Avatar className="h-7 w-7">
                  <AvatarImage src={profile?.avatar_url || undefined} />
                  <AvatarFallback className="text-xs bg-primary/20 text-primary">
                    {getUserInitials(profile?.full_name || null)}
                  </AvatarFallback>
                </Avatar>
                <span className="hidden sm:inline text-sm">
                  {profile?.full_name || 'Usuario'}
                </span>
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="w-64">
              <DropdownMenuLabel className="pb-2">
                <div className="flex flex-col space-y-2">
                  <p className="text-sm font-medium">{profile?.full_name}</p>
                  <p className="text-xs text-muted-foreground">{profile?.email}</p>
                  <div className="flex flex-wrap gap-1">
                    {profile?.roles.map((role) => (
                      <Badge
                        key={role}
                        variant="outline"
                        className={`text-xs ${getRoleBadgeColor(profile.roles)}`}
                      >
                        {role.replace('_', ' ')}
                      </Badge>
                    ))}
                  </div>
                </div>
              </DropdownMenuLabel>
              <DropdownMenuSeparator />
              <DropdownMenuItem asChild>
                <Link to="/profile" className="cursor-pointer">
                  <Settings className="h-4 w-4 mr-2" />
                  Configuración
                </Link>
              </DropdownMenuItem>
              <DropdownMenuSeparator />
              <DropdownMenuItem 
                onClick={signOut}
                className="cursor-pointer text-destructive focus:text-destructive"
              >
                <LogOut className="h-4 w-4 mr-2" />
                Cerrar Sesión
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </div>
    </nav>
  );
}