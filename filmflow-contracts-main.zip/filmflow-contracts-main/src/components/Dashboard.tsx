import { useState, useEffect } from 'react';
import { useAuth } from '@/hooks/useAuth';
import { supabase } from '@/integrations/supabase/client';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { PipelineOverview } from '@/components/PipelineOverview';
import { ExceptionReview } from '@/components/ExceptionReview';
import { DocumentHistory } from '@/components/DocumentHistory';
import {
  Film,
  FolderOpen,
  FileText,
  Clock,
  AlertCircle,
  TrendingUp,
  Plus,
  Eye,
  Zap,
  Database,
} from 'lucide-react';

interface Project {
  id: string;
  project_code: string;
  title: string;
  genre: string | null;
  status: string;
  budget_total: number | null;
  currency: string;
  start_date: string | null;
  end_date: string | null;
  created_at: string;
}

interface DashboardStats {
  totalProjects: number;
  activeProjects: number;
  totalDocuments: number;
  pendingDocuments: number;
  totalBudget: number;
}

const statusConfig = {
  DEVELOPMENT: { label: 'Desarrollo', color: 'bg-yellow-500/20 text-yellow-400', progress: 10 },
  PRE_PRODUCTION: { label: 'Pre-producción', color: 'bg-orange-500/20 text-orange-400', progress: 25 },
  PRODUCTION: { label: 'Producción', color: 'bg-blue-500/20 text-blue-400', progress: 50 },
  POST_PRODUCTION: { label: 'Post-producción', color: 'bg-purple-500/20 text-purple-400', progress: 75 },
  DISTRIBUTION: { label: 'Distribución', color: 'bg-green-500/20 text-green-400', progress: 90 },
  COMPLETED: { label: 'Completado', color: 'bg-emerald-500/20 text-emerald-400', progress: 100 },
  CANCELLED: { label: 'Cancelado', color: 'bg-red-500/20 text-red-400', progress: 0 },
};

export function Dashboard() {
  const { profile, canManageProjects } = useAuth();
  const [projects, setProjects] = useState<Project[]>([]);
  const [stats, setStats] = useState<DashboardStats>({
    totalProjects: 0,
    activeProjects: 0,
    totalDocuments: 0,
    pendingDocuments: 0,
    totalBudget: 0,
  });
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchDashboardData();
  }, []);

  const fetchDashboardData = async () => {
    try {
      setLoading(true);

      // Mock data for now since we need to query schema tables
      const mockProjects: Project[] = [
        {
          id: '1',
          project_code: 'FILM-001',
          title: 'El Último Verano',
          genre: 'Drama',
          status: 'PRODUCTION',
          budget_total: 850000,
          currency: 'EUR',
          start_date: '2024-01-15',
          end_date: '2024-06-30',
          created_at: '2024-01-01T00:00:00Z',
        },
        {
          id: '2',
          project_code: 'DOC-002',
          title: 'Historias de Madrid',
          genre: 'Documental',
          status: 'POST_PRODUCTION',
          budget_total: 320000,
          currency: 'EUR',
          start_date: '2023-09-01',
          end_date: '2024-03-15',
          created_at: '2023-08-15T00:00:00Z',
        },
        {
          id: '3',
          project_code: 'SER-003',
          title: 'Corazones Rotos',
          genre: 'Series',
          status: 'DEVELOPMENT',
          budget_total: 1250000,
          currency: 'EUR',
          start_date: '2024-06-01',
          end_date: '2025-01-30',
          created_at: '2024-02-10T00:00:00Z',
        }
      ];

      setProjects(mockProjects);
      
      // Mock stats
      setStats({
        totalProjects: 8,
        activeProjects: 5,
        totalDocuments: 24,
        pendingDocuments: 3,
        totalBudget: 2420000,
      });
    } catch (error) {
      console.error('Error fetching dashboard data:', error);
    } finally {
      setLoading(false);
    }
  };

  const formatCurrency = (amount: number, currency: string = 'EUR') => {
    return new Intl.NumberFormat('es-ES', {
      style: 'currency',
      currency,
      minimumFractionDigits: 0,
      maximumFractionDigits: 0,
    }).format(amount);
  };

  const getStatusBadge = (status: string) => {
    const config = statusConfig[status as keyof typeof statusConfig] || statusConfig.DEVELOPMENT;
    return (
      <Badge variant="outline" className={config.color}>
        {config.label}
      </Badge>
    );
  };

  return (
    <div className="space-y-8">
      {/* Welcome Section */}
      <div className="text-center space-y-4">
        <h1 className="text-4xl font-bold text-gradient-primary">
          Bienvenido, {profile?.full_name || 'Usuario'}
        </h1>
        <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
          Gestiona tus proyectos audiovisuales y procesa documentos con IA
        </p>
      </div>

      {/* Main Content Tabs */}
      <Tabs defaultValue="projects" className="w-full">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="projects" className="flex items-center gap-2">
            <Film className="h-4 w-4" />
            Proyectos
          </TabsTrigger>
          <TabsTrigger value="documents" className="flex items-center gap-2">
            <Zap className="h-4 w-4" />
            Procesador
          </TabsTrigger>
          <TabsTrigger value="history" className="flex items-center gap-2">
            <Database className="h-4 w-4" />
            Historial
          </TabsTrigger>
          <TabsTrigger value="exceptions" className="flex items-center gap-2">
            <AlertCircle className="h-4 w-4" />
            Excepciones
          </TabsTrigger>
        </TabsList>

        <TabsContent value="projects" className="space-y-6 mt-6">
          {/* Projects Content */}

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <Card className="cinema-card">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Proyectos Totales</CardTitle>
            <FolderOpen className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-primary">{stats.totalProjects}</div>
            <p className="text-xs text-muted-foreground">
              {stats.activeProjects} activos
            </p>
          </CardContent>
        </Card>

        <Card className="cinema-card">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Documentos</CardTitle>
            <FileText className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-primary">{stats.totalDocuments}</div>
            <p className="text-xs text-muted-foreground">
              {stats.pendingDocuments} pendientes
            </p>
          </CardContent>
        </Card>

        <Card className="cinema-card">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Presupuesto Total</CardTitle>
            <TrendingUp className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-accent">
              {formatCurrency(stats.totalBudget)}
            </div>
            <p className="text-xs text-muted-foreground">
              Suma de todos los proyectos
            </p>
          </CardContent>
        </Card>

        <Card className="cinema-card">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Alertas</CardTitle>
            <AlertCircle className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-destructive">{stats.pendingDocuments}</div>
            <p className="text-xs text-muted-foreground">
              Documentos por revisar
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Recent Projects */}
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <h2 className="text-2xl font-bold text-gradient-accent">
            Proyectos Recientes
          </h2>
          {canManageProjects() && (
            <Button variant="cinema" size="sm">
              <Plus className="h-4 w-4 mr-2" />
              Nuevo Proyecto
            </Button>
          )}
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {projects.map((project) => {
            const statusInfo = statusConfig[project.status as keyof typeof statusConfig] || statusConfig.DEVELOPMENT;
            
            return (
              <Card key={project.id} className="cinema-card hover:shadow-lg cinema-transition">
                <CardHeader>
                  <div className="flex items-start justify-between">
                    <div className="space-y-1">
                      <CardTitle className="text-lg">{project.title}</CardTitle>
                      <CardDescription>{project.project_code}</CardDescription>
                    </div>
                    <Film className="h-5 w-5 text-primary" />
                  </div>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex items-center justify-between">
                    {getStatusBadge(project.status)}
                    <span className="text-sm text-muted-foreground">
                      {project.genre}
                    </span>
                  </div>
                  
                  <div className="space-y-2">
                    <div className="flex items-center justify-between text-sm">
                      <span>Progreso</span>
                      <span>{statusInfo.progress}%</span>
                    </div>
                    <Progress value={statusInfo.progress} className="h-2" />
                  </div>

                  {project.budget_total && (
                    <div className="text-sm">
                      <span className="text-muted-foreground">Presupuesto: </span>
                      <span className="font-semibold text-accent">
                        {formatCurrency(project.budget_total, project.currency)}
                      </span>
                    </div>
                  )}

                  <div className="flex items-center gap-2 pt-2">
                    <Button variant="outline" size="sm" className="flex-1">
                      <Eye className="h-4 w-4 mr-2" />
                      Ver Detalles
                    </Button>
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>

        {projects.length === 0 && !loading && (
          <div className="text-center py-12">
            <Film className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
            <h3 className="text-lg font-semibold mb-2">No hay proyectos</h3>
            <p className="text-muted-foreground mb-4">
              Comienza creando tu primer proyecto audiovisual
            </p>
            {canManageProjects() && (
              <Button variant="cinema">
                <Plus className="h-4 w-4 mr-2" />
                Crear Primer Proyecto
              </Button>
            )}
          </div>
        )}
      </div>
        </TabsContent>

        <TabsContent value="documents" className="mt-6">
          <PipelineOverview />
        </TabsContent>

        <TabsContent value="history" className="mt-6">
          <DocumentHistory />
        </TabsContent>

        <TabsContent value="exceptions" className="mt-6">
          <ExceptionReview />
        </TabsContent>
      </Tabs>
    </div>
  );
}