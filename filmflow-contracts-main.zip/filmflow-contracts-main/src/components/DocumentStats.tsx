import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import {
  FileText,
  Clock,
  CheckCircle,
  AlertTriangle,
  BarChart3,
  TrendingUp,
  Users,
  Zap,
} from 'lucide-react';

interface DocumentStatsProps {
  stats: {
    total: number;
    processing: number;
    completed: number;
    errors: number;
    pending_review: number;
    average_processing_time: number;
    success_rate: number;
    doc_types: Record<string, number>;
  };
}

export function DocumentStats({ stats }: DocumentStatsProps) {
  const statCards = [
    {
      title: 'Total Documentos',
      value: stats.total,
      icon: FileText,
      description: 'Documentos procesados',
      color: 'text-foreground',
    },
    {
      title: 'Procesando',
      value: stats.processing,
      icon: Clock,
      description: 'En pipeline',
      color: 'text-primary',
    },
    {
      title: 'Completados',
      value: stats.completed,
      icon: CheckCircle,
      description: 'Procesados exitosamente',
      color: 'text-green-400',
    },
    {
      title: 'Errores',
      value: stats.errors,
      icon: AlertTriangle,
      description: 'Requieren atención',
      color: 'text-destructive',
    },
    {
      title: 'Revisión Humana',
      value: stats.pending_review,
      icon: Users,
      description: 'Pendientes de revisión',
      color: 'text-orange-400',
    },
    {
      title: 'Tiempo Promedio',
      value: `${(stats.average_processing_time / 1000).toFixed(1)}s`,
      icon: Zap,
      description: 'Tiempo de procesamiento',
      color: 'text-accent',
    },
    {
      title: 'Tasa de Éxito',
      value: `${stats.success_rate.toFixed(1)}%`,
      icon: TrendingUp,
      description: 'Procesamiento exitoso',
      color: 'text-green-400',
    },
  ];

  const getDocTypeBadgeClass = (docType: string) => {
    const classes = {
      contract: 'doc-type-contract',
      invoice: 'doc-type-invoice',
      proposal: 'doc-type-proposal',
      legal: 'doc-type-legal',
    };
    return classes[docType as keyof typeof classes] || 'status-pending';
  };

  return (
    <div className="space-y-6">
      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {statCards.map((stat) => {
          const Icon = stat.icon;
          return (
            <Card key={stat.title} className="cinema-card">
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-muted-foreground">{stat.title}</p>
                    <p className={`text-2xl font-bold ${stat.color}`}>
                      {stat.value}
                    </p>
                    <p className="text-xs text-muted-foreground">
                      {stat.description}
                    </p>
                  </div>
                  <Icon className={`h-8 w-8 ${stat.color} opacity-80`} />
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>

      {/* Document Types Distribution */}
      <Card className="cinema-card">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <BarChart3 className="h-5 w-5 text-primary" />
            Distribución por Tipo de Documento
          </CardTitle>
          <CardDescription>
            Tipos de documentos procesados
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {Object.entries(stats.doc_types).map(([type, count]) => (
              <div
                key={type}
                className="flex items-center justify-between p-3 rounded-lg border border-border bg-muted/20"
              >
                <div>
                  <Badge variant="outline" className={getDocTypeBadgeClass(type)}>
                    {type.toUpperCase()}
                  </Badge>
                  <p className="text-sm text-muted-foreground mt-1">
                    {count} documentos
                  </p>
                </div>
                <div className="text-right">
                  <p className="text-lg font-semibold">
                    {((count / stats.total) * 100).toFixed(1)}%
                  </p>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}