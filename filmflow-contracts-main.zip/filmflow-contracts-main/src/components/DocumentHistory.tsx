import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { ScrollArea } from '@/components/ui/scroll-area';
import { FileText, Calendar, User, AlertCircle, CheckCircle, Clock } from 'lucide-react';
import { Button } from '@/components/ui/button';

interface ProcessedDocument {
  id: string;
  file_name: string;
  status: string;
  created_at: string;
  updated_at: string;
  doc_type: string;
  confidence: number;
  extracted_text: string;
  structured_data: any;
}

export function DocumentHistory() {
  const [documents, setDocuments] = useState<ProcessedDocument[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedDoc, setSelectedDoc] = useState<ProcessedDocument | null>(null);

  useEffect(() => {
    fetchDocuments();
  }, []);

  const fetchDocuments = async () => {
    try {
      const { data, error } = await supabase
        .from('doc_index')
        .select('*')
        .order('created_at', { ascending: false });

      if (error) throw error;
      setDocuments(data || []);
    } catch (error) {
      console.error('Error fetching documents:', error);
    } finally {
      setLoading(false);
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'completed':
        return <CheckCircle className="h-4 w-4 text-green-500" />;
      case 'processing':
        return <Clock className="h-4 w-4 text-blue-500" />;
      case 'error':
        return <AlertCircle className="h-4 w-4 text-red-500" />;
      default:
        return <FileText className="h-4 w-4 text-gray-500" />;
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'completed':
        return 'bg-green-100 text-green-800';
      case 'processing':
        return 'bg-blue-100 text-blue-800';
      case 'error':
        return 'bg-red-100 text-red-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  if (loading) {
    return <div className="flex justify-center p-8">Cargando historial de documentos...</div>;
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold">Historial de Documentos Procesados</h2>
        <Button onClick={fetchDocuments} variant="outline">
          Actualizar
        </Button>
      </div>

      <div className="grid gap-6 md:grid-cols-2">
        {/* Lista de documentos */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <FileText className="h-5 w-5" />
              Documentos ({documents.length})
            </CardTitle>
          </CardHeader>
          <CardContent>
            <ScrollArea className="h-96 pr-4">
              <div className="space-y-3">
                {documents.map((doc) => (
                  <div
                    key={doc.id}
                    className={`p-3 rounded-lg border cursor-pointer transition-colors hover:bg-gray-50 ${
                      selectedDoc?.id === doc.id ? 'border-blue-500 bg-blue-50' : ''
                    }`}
                    onClick={() => setSelectedDoc(doc)}
                  >
                    <div className="flex items-start justify-between gap-2">
                      <div className="flex-1 min-w-0">
                        <p className="font-medium text-sm truncate">{doc.file_name}</p>
                        <div className="flex items-center gap-2 mt-1">
                          {getStatusIcon(doc.status)}
                          <Badge className={`text-xs ${getStatusColor(doc.status)}`}>
                            {doc.status}
                          </Badge>
                          {doc.doc_type && (
                            <Badge variant="outline" className="text-xs">
                              {doc.doc_type}
                            </Badge>
                          )}
                        </div>
                        <div className="flex items-center gap-1 mt-1 text-xs text-gray-500">
                          <Calendar className="h-3 w-3" />
                          {new Date(doc.created_at).toLocaleDateString('es-ES')}
                        </div>
                      </div>
                      {doc.confidence && (
                        <div className="text-xs text-gray-600">
                          {Math.round(doc.confidence * 100)}%
                        </div>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </ScrollArea>
          </CardContent>
        </Card>

        {/* Detalles del documento seleccionado */}
        <Card>
          <CardHeader>
            <CardTitle>
              {selectedDoc ? selectedDoc.file_name : 'Selecciona un documento'}
            </CardTitle>
          </CardHeader>
          <CardContent>
            {selectedDoc ? (
              <Tabs defaultValue="info" className="w-full">
                <TabsList className="grid w-full grid-cols-3">
                  <TabsTrigger value="info">Info</TabsTrigger>
                  <TabsTrigger value="text">Texto</TabsTrigger>
                  <TabsTrigger value="data">Datos</TabsTrigger>
                </TabsList>
                
                <TabsContent value="info" className="mt-4">
                  <div className="space-y-4">
                    <div className="grid grid-cols-2 gap-4 text-sm">
                      <div>
                        <strong>Estado:</strong>
                        <div className="flex items-center gap-2 mt-1">
                          {getStatusIcon(selectedDoc.status)}
                          <Badge className={getStatusColor(selectedDoc.status)}>
                            {selectedDoc.status}
                          </Badge>
                        </div>
                      </div>
                      <div>
                        <strong>Tipo:</strong>
                        <p className="mt-1">{selectedDoc.doc_type || 'No detectado'}</p>
                      </div>
                      <div>
                        <strong>Confianza:</strong>
                        <p className="mt-1">
                          {selectedDoc.confidence 
                            ? `${Math.round(selectedDoc.confidence * 100)}%` 
                            : 'N/A'}
                        </p>
                      </div>
                      <div>
                        <strong>Procesado:</strong>
                        <p className="mt-1">
                          {new Date(selectedDoc.updated_at).toLocaleString('es-ES')}
                        </p>
                      </div>
                    </div>
                  </div>
                </TabsContent>
                
                <TabsContent value="text" className="mt-4">
                  <ScrollArea className="h-64 w-full rounded border p-3">
                    <pre className="text-sm whitespace-pre-wrap">
                      {selectedDoc.extracted_text || 'No hay texto extraído disponible'}
                    </pre>
                  </ScrollArea>
                </TabsContent>
                
                <TabsContent value="data" className="mt-4">
                  <ScrollArea className="h-64 w-full rounded border p-3">
                    <pre className="text-sm">
                      {selectedDoc.structured_data 
                        ? JSON.stringify(selectedDoc.structured_data, null, 2)
                        : 'No hay datos estructurados disponibles'}
                    </pre>
                  </ScrollArea>
                </TabsContent>
              </Tabs>
            ) : (
              <div className="text-center text-gray-500 py-12">
                <FileText className="h-12 w-12 mx-auto mb-4 opacity-50" />
                <p>Selecciona un documento de la lista para ver sus detalles</p>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}