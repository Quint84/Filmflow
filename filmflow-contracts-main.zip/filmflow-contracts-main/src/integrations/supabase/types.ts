export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "13.0.4"
  }
  public: {
    Tables: {
      distribution_agreements: {
        Row: {
          approvals: Json | null
          banking: Json | null
          compliance: Json | null
          created_at: string
          doc_id: string
          doc_type: string
          document_date: string | null
          document_title: string | null
          exclusivity: boolean | null
          holdbacks: Json | null
          id: string
          languages_authorized: string[] | null
          materials_delivery: Json | null
          notices: Json | null
          parties: Json
          project_code: string | null
          project_title: string | null
          release_obligations: Json | null
          reporting: Json | null
          revenue_model: Json
          rights_granted: string[] | null
          security_and_assignments: Json | null
          signatures: Json | null
          subdistribution: Json | null
          taxes: Json | null
          term: Json
          termination: Json | null
          territory: string[] | null
          updated_at: string
          user_id: string
        }
        Insert: {
          approvals?: Json | null
          banking?: Json | null
          compliance?: Json | null
          created_at?: string
          doc_id: string
          doc_type?: string
          document_date?: string | null
          document_title?: string | null
          exclusivity?: boolean | null
          holdbacks?: Json | null
          id?: string
          languages_authorized?: string[] | null
          materials_delivery?: Json | null
          notices?: Json | null
          parties?: Json
          project_code?: string | null
          project_title?: string | null
          release_obligations?: Json | null
          reporting?: Json | null
          revenue_model?: Json
          rights_granted?: string[] | null
          security_and_assignments?: Json | null
          signatures?: Json | null
          subdistribution?: Json | null
          taxes?: Json | null
          term?: Json
          termination?: Json | null
          territory?: string[] | null
          updated_at?: string
          user_id: string
        }
        Update: {
          approvals?: Json | null
          banking?: Json | null
          compliance?: Json | null
          created_at?: string
          doc_id?: string
          doc_type?: string
          document_date?: string | null
          document_title?: string | null
          exclusivity?: boolean | null
          holdbacks?: Json | null
          id?: string
          languages_authorized?: string[] | null
          materials_delivery?: Json | null
          notices?: Json | null
          parties?: Json
          project_code?: string | null
          project_title?: string | null
          release_obligations?: Json | null
          reporting?: Json | null
          revenue_model?: Json
          rights_granted?: string[] | null
          security_and_assignments?: Json | null
          signatures?: Json | null
          subdistribution?: Json | null
          taxes?: Json | null
          term?: Json
          termination?: Json | null
          territory?: string[] | null
          updated_at?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "fk_distribution_agreements_doc_id"
            columns: ["doc_id"]
            isOneToOne: false
            referencedRelation: "doc_index"
            referencedColumns: ["id"]
          },
        ]
      }
      doc_index: {
        Row: {
          confidence: number | null
          created_at: string | null
          doc_type: string | null
          embedding: string | null
          extracted_text: string | null
          file_hash: string | null
          file_name: string
          file_path: string
          file_size: number | null
          id: string
          metadata: Json | null
          mime_type: string | null
          project_code: string | null
          status: string | null
          structured_data: Json | null
          updated_at: string | null
          upload_date: string | null
          user_id: string | null
        }
        Insert: {
          confidence?: number | null
          created_at?: string | null
          doc_type?: string | null
          embedding?: string | null
          extracted_text?: string | null
          file_hash?: string | null
          file_name: string
          file_path: string
          file_size?: number | null
          id?: string
          metadata?: Json | null
          mime_type?: string | null
          project_code?: string | null
          status?: string | null
          structured_data?: Json | null
          updated_at?: string | null
          upload_date?: string | null
          user_id?: string | null
        }
        Update: {
          confidence?: number | null
          created_at?: string | null
          doc_type?: string | null
          embedding?: string | null
          extracted_text?: string | null
          file_hash?: string | null
          file_name?: string
          file_path?: string
          file_size?: number | null
          id?: string
          metadata?: Json | null
          mime_type?: string | null
          project_code?: string | null
          status?: string | null
          structured_data?: Json | null
          updated_at?: string | null
          upload_date?: string | null
          user_id?: string | null
        }
        Relationships: []
      }
      processing_exceptions: {
        Row: {
          created_at: string
          doc_id: string
          error_message: string | null
          exception_type: string
          id: string
          payload: Json | null
          resolved_at: string | null
          status: string
          updated_at: string
        }
        Insert: {
          created_at?: string
          doc_id: string
          error_message?: string | null
          exception_type: string
          id?: string
          payload?: Json | null
          resolved_at?: string | null
          status?: string
          updated_at?: string
        }
        Update: {
          created_at?: string
          doc_id?: string
          error_message?: string | null
          exception_type?: string
          id?: string
          payload?: Json | null
          resolved_at?: string | null
          status?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "processing_exceptions_doc_id_fkey"
            columns: ["doc_id"]
            isOneToOne: false
            referencedRelation: "doc_index"
            referencedColumns: ["id"]
          },
        ]
      }
      profiles: {
        Row: {
          avatar_url: string | null
          created_at: string | null
          email: string
          full_name: string | null
          id: string
          updated_at: string | null
        }
        Insert: {
          avatar_url?: string | null
          created_at?: string | null
          email: string
          full_name?: string | null
          id: string
          updated_at?: string | null
        }
        Update: {
          avatar_url?: string | null
          created_at?: string | null
          email?: string
          full_name?: string | null
          id?: string
          updated_at?: string | null
        }
        Relationships: []
      }
      projects: {
        Row: {
          additional_contacts: Json | null
          aspect_ratio: string | null
          cast_lead: string[] | null
          chain_of_title_complete: boolean | null
          color_format: string | null
          completion_bond: boolean | null
          country_of_origin: string | null
          created_at: string
          delivery_date: string | null
          delivery_format: string | null
          development_start: string | null
          director: string | null
          distributor_domestic: string | null
          distributor_international: string | null
          errors_omissions_insurance: boolean | null
          executive_producer: string | null
          financing_plan: Json | null
          format: string | null
          genre: string[] | null
          id: string
          key_art_locked: boolean | null
          keywords: string[] | null
          language: string | null
          logline: string | null
          notes: string | null
          original_title: string | null
          post_production_end: string | null
          press_kit_complete: boolean | null
          primary_contact: Json | null
          producer: string | null
          production_company: string | null
          production_end: string | null
          production_start: string | null
          production_year: number | null
          project_code: string
          project_status: string
          project_title: string
          release_date: string | null
          runtime_minutes: number | null
          sales_agent: string | null
          shooting_format: string | null
          sound_format: string | null
          synopsis: string | null
          team_members: Json | null
          total_budget: Json | null
          trailer_available: boolean | null
          updated_at: string
          user_id: string
          writer: string | null
        }
        Insert: {
          additional_contacts?: Json | null
          aspect_ratio?: string | null
          cast_lead?: string[] | null
          chain_of_title_complete?: boolean | null
          color_format?: string | null
          completion_bond?: boolean | null
          country_of_origin?: string | null
          created_at?: string
          delivery_date?: string | null
          delivery_format?: string | null
          development_start?: string | null
          director?: string | null
          distributor_domestic?: string | null
          distributor_international?: string | null
          errors_omissions_insurance?: boolean | null
          executive_producer?: string | null
          financing_plan?: Json | null
          format?: string | null
          genre?: string[] | null
          id?: string
          key_art_locked?: boolean | null
          keywords?: string[] | null
          language?: string | null
          logline?: string | null
          notes?: string | null
          original_title?: string | null
          post_production_end?: string | null
          press_kit_complete?: boolean | null
          primary_contact?: Json | null
          producer?: string | null
          production_company?: string | null
          production_end?: string | null
          production_start?: string | null
          production_year?: number | null
          project_code: string
          project_status?: string
          project_title: string
          release_date?: string | null
          runtime_minutes?: number | null
          sales_agent?: string | null
          shooting_format?: string | null
          sound_format?: string | null
          synopsis?: string | null
          team_members?: Json | null
          total_budget?: Json | null
          trailer_available?: boolean | null
          updated_at?: string
          user_id: string
          writer?: string | null
        }
        Update: {
          additional_contacts?: Json | null
          aspect_ratio?: string | null
          cast_lead?: string[] | null
          chain_of_title_complete?: boolean | null
          color_format?: string | null
          completion_bond?: boolean | null
          country_of_origin?: string | null
          created_at?: string
          delivery_date?: string | null
          delivery_format?: string | null
          development_start?: string | null
          director?: string | null
          distributor_domestic?: string | null
          distributor_international?: string | null
          errors_omissions_insurance?: boolean | null
          executive_producer?: string | null
          financing_plan?: Json | null
          format?: string | null
          genre?: string[] | null
          id?: string
          key_art_locked?: boolean | null
          keywords?: string[] | null
          language?: string | null
          logline?: string | null
          notes?: string | null
          original_title?: string | null
          post_production_end?: string | null
          press_kit_complete?: boolean | null
          primary_contact?: Json | null
          producer?: string | null
          production_company?: string | null
          production_end?: string | null
          production_start?: string | null
          production_year?: number | null
          project_code?: string
          project_status?: string
          project_title?: string
          release_date?: string | null
          runtime_minutes?: number | null
          sales_agent?: string | null
          shooting_format?: string | null
          sound_format?: string | null
          synopsis?: string | null
          team_members?: Json | null
          total_budget?: Json | null
          trailer_available?: boolean | null
          updated_at?: string
          user_id?: string
          writer?: string | null
        }
        Relationships: []
      }
      task_queue: {
        Row: {
          completed_at: string | null
          created_at: string
          doc_id: string
          error_message: string | null
          id: string
          payload: Json | null
          status: string
          task_type: string
          updated_at: string
        }
        Insert: {
          completed_at?: string | null
          created_at?: string
          doc_id: string
          error_message?: string | null
          id?: string
          payload?: Json | null
          status?: string
          task_type: string
          updated_at?: string
        }
        Update: {
          completed_at?: string | null
          created_at?: string
          doc_id?: string
          error_message?: string | null
          id?: string
          payload?: Json | null
          status?: string
          task_type?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "task_queue_doc_id_fkey"
            columns: ["doc_id"]
            isOneToOne: false
            referencedRelation: "doc_index"
            referencedColumns: ["id"]
          },
        ]
      }
      user_roles: {
        Row: {
          created_at: string | null
          id: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Insert: {
          created_at?: string | null
          id?: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Update: {
          created_at?: string | null
          id?: string
          role?: Database["public"]["Enums"]["app_role"]
          user_id?: string
        }
        Relationships: []
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      binary_quantize: {
        Args: { "": string } | { "": unknown }
        Returns: unknown
      }
      halfvec_avg: {
        Args: { "": number[] }
        Returns: unknown
      }
      halfvec_out: {
        Args: { "": unknown }
        Returns: unknown
      }
      halfvec_send: {
        Args: { "": unknown }
        Returns: string
      }
      halfvec_typmod_in: {
        Args: { "": unknown[] }
        Returns: number
      }
      has_project_access: {
        Args: { _project_id: string; _user_id: string }
        Returns: boolean
      }
      has_role: {
        Args: {
          _role: Database["public"]["Enums"]["app_role"]
          _user_id: string
        }
        Returns: boolean
      }
      hnsw_bit_support: {
        Args: { "": unknown }
        Returns: unknown
      }
      hnsw_halfvec_support: {
        Args: { "": unknown }
        Returns: unknown
      }
      hnsw_sparsevec_support: {
        Args: { "": unknown }
        Returns: unknown
      }
      hnswhandler: {
        Args: { "": unknown }
        Returns: unknown
      }
      ivfflat_bit_support: {
        Args: { "": unknown }
        Returns: unknown
      }
      ivfflat_halfvec_support: {
        Args: { "": unknown }
        Returns: unknown
      }
      ivfflathandler: {
        Args: { "": unknown }
        Returns: unknown
      }
      l2_norm: {
        Args: { "": unknown } | { "": unknown }
        Returns: number
      }
      l2_normalize: {
        Args: { "": string } | { "": unknown } | { "": unknown }
        Returns: unknown
      }
      promote_user_to_admin: {
        Args: { user_email: string }
        Returns: boolean
      }
      sparsevec_out: {
        Args: { "": unknown }
        Returns: unknown
      }
      sparsevec_send: {
        Args: { "": unknown }
        Returns: string
      }
      sparsevec_typmod_in: {
        Args: { "": unknown[] }
        Returns: number
      }
      vector_avg: {
        Args: { "": number[] }
        Returns: string
      }
      vector_dims: {
        Args: { "": string } | { "": unknown }
        Returns: number
      }
      vector_norm: {
        Args: { "": string }
        Returns: number
      }
      vector_out: {
        Args: { "": string }
        Returns: unknown
      }
      vector_send: {
        Args: { "": string }
        Returns: string
      }
      vector_typmod_in: {
        Args: { "": unknown[] }
        Returns: number
      }
    }
    Enums: {
      app_role:
        | "ADMIN"
        | "PRODUCER"
        | "LP_FINANCE"
        | "LEGAL"
        | "SALES"
        | "HOD"
        | "INVESTOR_VIEW"
      doc_type:
        | "INV_TAX"
        | "COPRODUCTION"
        | "TALENT"
        | "DISTRIBUTION"
        | "SALES_AGENT"
        | "BANKING"
        | "SUPPLIER"
        | "LICENSE_DIRECT"
        | "LICENSE_INTERMEDIARY"
      milestone_kind:
        | "GREENLIGHT"
        | "PP_START"
        | "SHOOT_START"
        | "SHOOT_END"
        | "LOCK_CUT"
        | "DELIVERY_ESSENTIAL"
        | "DELIVERY_COMPLETE"
        | "CERT_CULTURAL"
        | "CERT_NACIONALIDAD"
        | "CERT_36X"
        | "NOA"
        | "FEST_PREMIERE"
        | "THEATRICAL_RELEASE"
        | "SVOD_START"
        | "TV_FREE_START"
        | "OTHER"
      project_status:
        | "DEVELOPMENT"
        | "PRE_PRODUCTION"
        | "PRODUCTION"
        | "POST_PRODUCTION"
        | "DISTRIBUTION"
        | "COMPLETED"
        | "CANCELLED"
        | "DEV"
        | "PREP"
        | "ROD"
        | "POST"
        | "ENTREGADA"
        | "CATALOGO"
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {
      app_role: [
        "ADMIN",
        "PRODUCER",
        "LP_FINANCE",
        "LEGAL",
        "SALES",
        "HOD",
        "INVESTOR_VIEW",
      ],
      doc_type: [
        "INV_TAX",
        "COPRODUCTION",
        "TALENT",
        "DISTRIBUTION",
        "SALES_AGENT",
        "BANKING",
        "SUPPLIER",
        "LICENSE_DIRECT",
        "LICENSE_INTERMEDIARY",
      ],
      milestone_kind: [
        "GREENLIGHT",
        "PP_START",
        "SHOOT_START",
        "SHOOT_END",
        "LOCK_CUT",
        "DELIVERY_ESSENTIAL",
        "DELIVERY_COMPLETE",
        "CERT_CULTURAL",
        "CERT_NACIONALIDAD",
        "CERT_36X",
        "NOA",
        "FEST_PREMIERE",
        "THEATRICAL_RELEASE",
        "SVOD_START",
        "TV_FREE_START",
        "OTHER",
      ],
      project_status: [
        "DEVELOPMENT",
        "PRE_PRODUCTION",
        "PRODUCTION",
        "POST_PRODUCTION",
        "DISTRIBUTION",
        "COMPLETED",
        "CANCELLED",
        "DEV",
        "PREP",
        "ROD",
        "POST",
        "ENTREGADA",
        "CATALOGO",
      ],
    },
  },
} as const
