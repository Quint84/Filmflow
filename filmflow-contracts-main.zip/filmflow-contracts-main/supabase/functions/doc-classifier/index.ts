
import "https://deno.land/x/xhr@0.1.0/mod.ts";
import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.56.1";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
const supabaseKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
const openAIApiKey = Deno.env.get('OPENAI_API_KEY')!;

const supabase = createClient(supabaseUrl, supabaseKey);

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { docId } = await req.json();
    console.log(`Starting classification for docId: ${docId}`);

    // Get document info
    const { data: docData, error: docError } = await supabase
      .from('doc_index')
      .select('*')
      .eq('id', docId)
      .single();

    if (docError || !docData) {
      console.error('Document not found:', docError);
      throw new Error('Document not found');
    }

    // Download and extract text for classification
    const { data: fileData, error: downloadError } = await supabase.storage
      .from('documents')
      .download(docData.file_path);

    if (downloadError) {
      console.error('Download error:', downloadError);
      throw new Error(`Error downloading file: ${downloadError.message}`);
    }

    // Extract text (simplified version)
    const extractedText = await extractTextFromFile(docData.file_name, fileData);
    console.log('Text extracted, length:', extractedText.length);

    // Classify using regex patterns first
    const regexResult = await classifyWithRegex(extractedText, docData.file_name);
    console.log('Regex classification result:', regexResult);
    
    // Use LLM for classification
    const llmResult = await classifyWithLLM(extractedText, docData.file_name);
    console.log('LLM classification result:', llmResult);

    // Combine results and calculate confidence
    const classification = combineClassificationResults(regexResult, llmResult);
    console.log('Final classification result:', classification);

    // Map the classification to valid status values
    const statusMapping = {
      'high_confidence': 'classified',
      'medium_confidence': 'processing', // Use processing instead of review_required
      'low_confidence': 'error'
    };

    const finalStatus = classification.confidence >= 0.85 ? 'classified' : 'processing';

    // Update doc_index with classification
    const { error: updateError } = await supabase
      .from('doc_index')
      .update({
        doc_type: classification.doc_type,
        project_code: classification.project_code,
        confidence: classification.confidence,
        status: finalStatus,
        updated_at: new Date().toISOString()
      })
      .eq('id', docId);

    if (updateError) {
      console.error('Update error:', updateError);
      throw updateError;
    }

    // If confidence is high enough, enqueue next task
    if (classification.confidence >= 0.85) {
      const { error: taskError } = await supabase
        .from('task_queue')
        .insert({
          task_type: 'TASK_PARSE',
          doc_id: docId,
          payload: {
            doc_type: classification.doc_type,
            project_code: classification.project_code
          },
          status: 'pending'
        });

      if (taskError) {
        console.error('Task queue error:', taskError);
        // Don't throw here, classification succeeded
      }
    } else {
      // Create exception for human review
      const { error: exceptionError } = await supabase
        .from('processing_exceptions')
        .insert({
          doc_id: docId,
          stage: 'classification',
          suggested_data: classification,
          status: 'pending'
        });

      if (exceptionError) {
        console.error('Exception creation error:', exceptionError);
        // Don't throw here, classification succeeded
      }
    }

    return new Response(
      JSON.stringify({ 
        success: true,
        classification,
        nextStage: classification.confidence >= 0.85 ? 'parse' : 'human_review'
      }),
      {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      }
    );

  } catch (error) {
    console.error('Error in document classifier:', error);
    
    // Try to update doc status to error if possible
    try {
      const { docId } = await req.json();
      if (docId) {
        await supabase
          .from('doc_index')
          .update({
            status: 'error',
            metadata: { error: error.message }
          })
          .eq('id', docId);
      }
    } catch (parseError) {
      console.error('Error updating doc status:', parseError);
    }

    return new Response(
      JSON.stringify({ error: error.message }),
      {
        status: 500,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      }
    );
  }
});

async function extractTextFromFile(filename: string, fileData: Blob): Promise<string> {
  // Simple text extraction - in production, use proper OCR/PDF parsing
  const text = `Mock extracted text from ${filename}
  
CONTRATO DE PRODUCCIÓN AUDIOVISUAL
Proyecto: "El Último Verano" 
Código: FILM-2024-001
Presupuesto: €850,000
Fecha inicio: 15/03/2024
Productora: Séptimo Arte Productions SL
Director: Juan Carlos Pérez`;
  
  return text;
}

async function classifyWithRegex(text: string, filename: string) {
  const patterns = {
    contract: /contrato|agreement|acuerdo/i,
    invoice: /factura|invoice|bill/i,
    mla: /mla|territory|license|distribution/i
  };

  const projectCodePattern = /(?:proyecto|project|código|code)[\s:]*([A-Z0-9-]+)/i;
  
  let doc_type = null;
  let confidence = 0;
  
  for (const [type, pattern] of Object.entries(patterns)) {
    if (pattern.test(text) || pattern.test(filename)) {
      doc_type = type;
      confidence = 0.7;
      break;
    }
  }

  const projectMatch = text.match(projectCodePattern);
  const project_code = projectMatch ? projectMatch[1] : null;

  return { doc_type, project_code, confidence, source: 'regex' };
}

async function classifyWithLLM(text: string, filename: string) {
  if (!openAIApiKey) {
    console.error('OpenAI API key not found');
    return { doc_type: null, project_code: null, confidence: 0, source: 'llm_no_key' };
  }

  const prompt = `Analiza este documento y clasifícalo:

Texto: ${text.substring(0, 1000)}
Nombre del archivo: ${filename}

Responde en formato JSON exacto:
{
  "doc_type": "contract|invoice|mla|other",
  "project_code": "código del proyecto si existe",
  "confidence": 0.0-1.0,
  "reasoning": "breve explicación"
}`;

  try {
    const response = await fetch('https://api.openai.com/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${openAIApiKey}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        model: 'gpt-4o-mini',
        messages: [{ role: 'user', content: prompt }],
        max_tokens: 200,
        response_format: { type: "json_object" }
      }),
    });

    if (!response.ok) {
      console.error('OpenAI API error:', response.status, response.statusText);
      return { doc_type: null, project_code: null, confidence: 0, source: 'llm_api_error' };
    }

    const data = await response.json();
    console.log('OpenAI response:', data);
    
    // Better error handling for the response
    if (!data.choices || !data.choices[0] || !data.choices[0].message || !data.choices[0].message.content) {
      console.error('Invalid OpenAI response structure:', data);
      return { doc_type: null, project_code: null, confidence: 0, source: 'llm_invalid_response' };
    }

    const result = JSON.parse(data.choices[0].message.content);
    return { ...result, source: 'llm' };
  } catch (error) {
    console.error('LLM classification error:', error);
    return { doc_type: null, project_code: null, confidence: 0, source: 'llm_error' };
  }
}

function combineClassificationResults(regexResult: any, llmResult: any) {
  // Use LLM result if it has higher confidence, otherwise combine
  if (llmResult.confidence > regexResult.confidence) {
    return {
      doc_type: llmResult.doc_type,
      project_code: llmResult.project_code || regexResult.project_code,
      confidence: llmResult.confidence
    };
  } else if (regexResult.doc_type && llmResult.doc_type === regexResult.doc_type) {
    // Both agree, increase confidence
    return {
      doc_type: regexResult.doc_type,
      project_code: llmResult.project_code || regexResult.project_code,
      confidence: Math.min(0.95, regexResult.confidence + llmResult.confidence)
    };
  } else {
    // Use regex result but with lower confidence due to disagreement
    return {
      doc_type: regexResult.doc_type,
      project_code: regexResult.project_code || llmResult.project_code,
      confidence: Math.max(0.4, regexResult.confidence - 0.2)
    };
  }
}
