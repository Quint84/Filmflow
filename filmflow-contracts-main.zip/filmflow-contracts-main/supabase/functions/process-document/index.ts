import "https://deno.land/x/xhr@0.1.0/mod.ts";
import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.56.1";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
const supabaseKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
const openAIApiKey = Deno.env.get('OPENAI_API_KEY')!;

const supabase = createClient(supabaseUrl, supabaseKey);

serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { fileName, action, extractedText } = await req.json();
    console.log(`Processing document: ${fileName}, action: ${action}`);

    switch (action) {
      case 'ocr':
        return await handleOCR(fileName);
      case 'extract_structured_data':
        return await handleLLMExtraction(extractedText);
      default:
        throw new Error('Invalid action');
    }
  } catch (error) {
    console.error('Error in process-document function:', error);
    return new Response(
      JSON.stringify({ error: error.message }),
      {
        status: 500,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      }
    );
  }
});

async function handleOCR(fileName: string) {
  try {
    console.log(`Starting OCR for file: ${fileName}`);
    
    // Download file from Supabase Storage
    const { data: fileData, error: downloadError } = await supabase.storage
      .from('documents')
      .download(`pending/${fileName}`);

    if (downloadError) {
      throw new Error(`Error downloading file: ${downloadError.message}`);
    }

    // Convert to base64 for processing
    const arrayBuffer = await fileData.arrayBuffer();
    const base64Data = btoa(String.fromCharCode(...new Uint8Array(arrayBuffer)));
    
    // For this demo, we'll simulate OCR processing
    // In a real implementation, you would use a service like Tesseract.js, Google Vision API, etc.
    
    console.log('Simulating OCR processing...');
    await new Promise(resolve => setTimeout(resolve, 2000)); // Simulate processing time
    
    // Mock extracted text based on file type
    const extractedText = generateMockExtractedText(fileName);
    
    console.log(`OCR completed for ${fileName}`);
    
    return new Response(
      JSON.stringify({ 
        extractedText,
        success: true 
      }),
      {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      }
    );
  } catch (error) {
    console.error('OCR error:', error);
    throw error;
  }
}

async function handleLLMExtraction(extractedText: string) {
  try {
    console.log('Starting LLM processing for structured data extraction...');
    
    const systemPrompt = `Eres un experto en análisis de documentos. Tu tarea es extraer información estructurada de documentos legales y contratos audiovisuales.

Analiza el texto proporcionado y extrae la siguiente información en formato JSON:

{
  "document_type": "string", // tipo de documento (contrato, factura, presupuesto, etc.)
  "parties": ["string"], // partes involucradas
  "project_title": "string", // título del proyecto si aplica
  "key_dates": {
    "start_date": "YYYY-MM-DD",
    "end_date": "YYYY-MM-DD",
    "other_dates": [{"date": "YYYY-MM-DD", "description": "string"}]
  },
  "financial_terms": {
    "total_amount": "number",
    "currency": "string",
    "payment_schedule": ["string"]
  },
  "key_clauses": ["string"], // cláusulas importantes
  "deliverables": ["string"], // entregables mencionados
  "locations": ["string"], // ubicaciones mencionadas
  "contact_info": {
    "emails": ["string"],
    "phones": ["string"],
    "addresses": ["string"]
  },
  "metadata": {
    "confidence_score": "number", // 0-1
    "language": "string",
    "page_count": "number"
  }
}

Si algún campo no está disponible, usa null. Mantén la estructura JSON exacta.`;

    const response = await fetch('https://api.openai.com/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${openAIApiKey}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        model: 'gpt-5-mini-2025-08-07',
        messages: [
          { role: 'system', content: systemPrompt },
          { role: 'user', content: `Analiza este documento y extrae la información estructurada:\n\n${extractedText}` }
        ],
        max_completion_tokens: 2000,
        response_format: { type: "json_object" }
      }),
    });

    if (!response.ok) {
      const errorText = await response.text();
      console.error('OpenAI API error:', errorText);
      throw new Error(`OpenAI API error: ${response.status} ${errorText}`);
    }

    const data = await response.json();
    const structuredData = JSON.parse(data.choices[0].message.content);
    
    console.log('LLM processing completed successfully');
    
    return new Response(
      JSON.stringify({ 
        structuredData,
        success: true 
      }),
      {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      }
    );
  } catch (error) {
    console.error('LLM extraction error:', error);
    throw error;
  }
}

function generateMockExtractedText(fileName: string): string {
  // Generate realistic mock text based on file type
  const fileExt = fileName.split('.').pop()?.toLowerCase();
  
  if (fileExt === 'pdf' || fileName.includes('contrato')) {
    return `CONTRATO DE PRODUCCIÓN AUDIOVISUAL

PARTES:
- Productora Cinematográfica "El Séptimo Arte", S.L.
  CIF: B-12345678
  Domicilio: Calle Mayor, 123, 28001 Madrid
  
- Director: Juan Carlos Pérez
  DNI: 12345678A
  Domicilio: Avenida del Arte, 45, 28010 Madrid

OBJETO DEL CONTRATO:
Producción de la película "Corazones en Silencio", género drama, 
duración aproximada 90 minutos.

CONDICIONES ECONÓMICAS:
- Presupuesto total: 850.000 €
- Honorarios director: 75.000 €
- Fecha de pago: 30% al inicio, 40% en mitad del rodaje, 30% al finalizar

FECHAS:
- Inicio de rodaje: 15 de marzo de 2024
- Fin de rodaje: 30 de abril de 2024
- Entrega final: 30 de junio de 2024

LOCALIZACIONES:
- Madrid (interior y exterior)
- Toledo (escenas históricas)
- Segovia (escenas finales)

CONTACTO:
Email: produccion@septimojarte.com
Teléfono: +34 91 123 45 67`;
  }
  
  return `Documento de texto extraído mediante OCR.
  
Este es un ejemplo de texto que habría sido extraído del archivo: ${fileName}

El texto contiene información relevante sobre el documento subido,
incluyendo datos como fechas, nombres, importes y otros elementos
que pueden ser procesados por el sistema de inteligencia artificial
para extraer información estructurada.

Fecha: ${new Date().toLocaleDateString()}
Archivo: ${fileName}
Estado: Procesado correctamente`;
}