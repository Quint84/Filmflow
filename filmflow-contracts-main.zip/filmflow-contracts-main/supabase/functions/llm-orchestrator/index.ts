import "https://deno.land/x/xhr@0.1.0/mod.ts";
import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.56.1";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
const supabaseKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
const openAIApiKey = Deno.env.get('OPENAI_API_KEY')!;

const supabase = createClient(supabaseUrl, supabaseKey);

// Nostromo LLM Orchestrator Configuration
const CLASSIFY_MODEL = "gpt-4o-mini";
const EXTRACT_MODEL = "gpt-4o-mini";
const EXTRACT_FALLBACK = "gpt-4o-2024-08-06";
const BATCH_ENABLED = true;

// Token limits for cost optimization
const TOKEN_LIMITS = {
  CLASSIFY: 800,
  EXTRACT: 1200
};

// Comprehensive JSON schema for distribution agreement extraction
const DISTRIBUTION_AGREEMENT_SCHEMA = {
  type: "object",
  properties: {
    doc_type: { type: "string", enum: ["DIST_AGREEMENT"] },
    document_title: { type: "string" },
    document_date: { type: "string", pattern: "^\\d{4}-\\d{2}-\\d{2}$" },
    project_title: { type: "string" },
    project_code: { type: ["string", "null"] },
    
    parties: {
      type: "object",
      properties: {
        licensor: {
          type: "object",
          properties: {
            name: { type: "string" },
            address: { type: "string" },
            contact: { type: "string" },
            email: { type: "string" }
          }
        },
        distributor_final: {
          type: "object",
          properties: {
            name: { type: "string" },
            vat_or_reg: { type: ["string", "null"] },
            address: { type: "string" },
            contact: { type: "string" },
            email: { type: "string" }
          }
        },
        licensee_intermediary: {
          type: "object",
          properties: {
            name: { type: ["string", "null"] },
            vat_or_reg: { type: ["string", "null"] },
            address: { type: ["string", "null"] },
            contact: { type: ["string", "null"] },
            email: { type: ["string", "null"] }
          }
        }
      }
    },
    
    territory: { type: "array", items: { type: "string" } },
    languages_authorized: { type: "array", items: { type: "string" } },
    rights_granted: { 
      type: "array", 
      items: { 
        type: "string",
        enum: ["ALL","Theatrical","Non-Theatrical","Home Video","TVOD","EST","SVOD","AVOD","Pay TV","Free TV","Ancillary","Internet/Wireless"]
      }
    },
    exclusivity: { type: "boolean" },
    
    term: {
      type: "object",
      properties: {
        start_event: { type: "string", enum: ["SIGN","DELIVERY_NOTICE","OTHER"] },
        start_date: { type: ["string", "null"], pattern: "^\\d{4}-\\d{2}-\\d{2}$" },
        duration_years: { type: "number" },
        end_date: { type: ["string", "null"], pattern: "^\\d{4}-\\d{2}-\\d{2}$" },
        renewal: {
          type: "object",
          properties: {
            options: { type: "number" },
            each_years: { type: "number" }
          }
        }
      }
    },
    
    revenue_model: {
      type: "object",
      properties: {
        mg: {
          type: "object",
          properties: {
            amount: { type: "number" },
            currency: { type: "string" },
            schedule: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  trigger: { type: "string", enum: ["SIGN","NOA","DELIVERY","RELEASE","DATE"] },
                  due_days: { type: "number" },
                  percent: { type: "number" },
                  amount: { type: "number" }
                }
              }
            }
          }
        },
        distribution_fee: {
          type: "array",
          items: {
            type: "object",
            properties: {
              media: { type: "string" },
              percent: { type: "number" }
            }
          }
        }
      }
    },
    
    holdbacks: {
      type: "array",
      items: {
        type: "object",
        properties: {
          media: { type: "string" },
          duration_months: { type: "number" },
          notes: { type: "string" }
        }
      }
    },
    
    confidence_score: { type: "number", minimum: 0, maximum: 1 },
    extraction_concerns: {
      type: "array",
      items: { type: "string" }
    }
  },
  required: ["doc_type", "confidence_score", "extraction_concerns"],
  additionalProperties: false
};

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { docId, action = "extract" } = await req.json();
    console.log(`LLM Orchestrator processing docId: ${docId}, action: ${action}`);

    // Get document and extracted text
    const { data: docData, error: docError } = await supabase
      .from('doc_index')
      .select('*')
      .eq('id', docId)
      .single();

    if (docError || !docData) {
      throw new Error('Document not found');
    }

    if (!docData.extracted_text) {
      throw new Error('No extracted text available for processing');
    }

    let result;
    if (action === "classify") {
      result = await classifyDocument(docData.extracted_text, docData.file_name);
    } else {
      result = await extractStructuredData(docData.extracted_text, docData.file_name);
    }

    // Update document with results
    const updateData = action === "classify" 
      ? {
          doc_type: result.document_type || result.doc_type,
          confidence: result.confidence_score,
          status: result.confidence_score >= 0.8 ? 'completed' : 'processing'
        }
      : {
          structured_data: result,
          confidence: result.confidence_score,
          status: result.confidence_score >= 0.7 ? 'completed' : 'processing'
        };

    // If it's a distribution agreement, also save to the specialized table
    if (result.doc_type === 'DIST_AGREEMENT' && action === "extract") {
      try {
        const { error: distError } = await supabase
          .from('distribution_agreements')
          .upsert({
            doc_id: docId,
            user_id: docData.user_id,
            doc_type: result.doc_type,
            document_title: result.document_title,
            document_date: result.document_date,
            project_title: result.project_title,
            project_code: result.project_code,
            parties: result.parties || {},
            territory: result.territory || [],
            languages_authorized: result.languages_authorized || [],
            rights_granted: result.rights_granted || [],
            exclusivity: result.exclusivity || false,
            term: result.term || {},
            revenue_model: result.revenue_model || {},
            holdbacks: result.holdbacks || [],
            release_obligations: result.release_obligations || {},
            reporting: result.reporting || {},
            materials_delivery: result.materials_delivery || {},
            banking: result.banking || {},
            security_and_assignments: result.security_and_assignments || {},
            taxes: result.taxes || {},
            compliance: result.compliance || {},
            subdistribution: result.subdistribution || {},
            approvals: result.approvals || {},
            termination: result.termination || [],
            notices: result.notices || {},
            signatures: result.signatures || []
          }, {
            onConflict: 'doc_id'
          });
        
        if (distError) {
          console.error('Error saving to distribution_agreements:', distError);
        }
      } catch (distSaveError) {
        console.error('Failed to save distribution agreement:', distSaveError);
      }
    }

    const { error: updateError } = await supabase
      .from('doc_index')
      .update({
        ...updateData,
        updated_at: new Date().toISOString()
      })
      .eq('id', docId);

    if (updateError) {
      console.error('Update error:', updateError);
    }

    return new Response(
      JSON.stringify({ 
        success: true,
        result,
        nextStage: result.confidence_score >= 0.8 ? 'completed' : 'human_review'
      }),
      {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      }
    );

  } catch (error) {
    console.error('LLM Orchestrator error:', error);
    return new Response(
      JSON.stringify({ error: error.message }),
      {
        status: 500,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      }
    );
  }
});

async function classifyDocument(extractedText: string, filename: string) {
  const cleanText = sanitizeText(extractedText);
  
  // Prompt caching: identical prefix for all classification requests
  const CLASSIFICATION_PREFIX = `NOSTROMO LLM ORCHESTRATOR - DOCUMENT CLASSIFICATION

You are the classification module of Nostromo Projects & Contracts Hub.
Classify the document type with high precision. Return only valid JSON.

Valid document types: contract, agreement, mla, deal_memo, invoice, budget, other

Response format:
{
  "document_type": "string",
  "confidence_score": 0.0-1.0,
  "classification_concerns": ["string"]
}

Few-shot examples:
Input: "CONTRATO DE PRODUCCIÓN..." → {"document_type": "contract", "confidence_score": 0.95, "classification_concerns": []}
Input: "MLA AGREEMENT..." → {"document_type": "mla", "confidence_score": 0.90, "classification_concerns": []}
Input: "DEAL MEMO..." → {"document_type": "deal_memo", "confidence_score": 0.85, "classification_concerns": ["Unclear financial terms"]}

DOCUMENT TO CLASSIFY:`;

  try {
    const response = await fetch('https://api.openai.com/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${openAIApiKey}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        model: CLASSIFY_MODEL,
        messages: [
          { role: 'system', content: CLASSIFICATION_PREFIX },
          { role: 'user', content: cleanText }
        ],
        max_tokens: TOKEN_LIMITS.CLASSIFY,
        temperature: 0,
        response_format: { type: "json_object" }
      }),
    });

    if (!response.ok) {
      throw new Error(`Classification API error: ${response.status}`);
    }

    const data = await response.json();
    return JSON.parse(data.choices[0].message.content);
  } catch (error) {
    console.error('Classification error:', error);
    return {
      document_type: "other",
      confidence_score: 0.0,
      classification_concerns: [`Classification failed: ${error.message}`]
    };
  }
}

async function extractStructuredData(extractedText: string, filename: string) {
  const cleanText = sanitizeText(extractedText);
  
  // Prompt caching: identical prefix for all extraction requests
  const EXTRACTION_PREFIX = `NOSTROMO LLM ORCHESTRATOR - DISTRIBUTION AGREEMENT EXTRACTION

You are the extraction module specialized in audiovisual distribution agreements.
Extract comprehensive structured data with strict JSON Schema compliance.
Focus on AFMA/IFTA distribution agreements, sales agency, and licensing deals.

REQUIRED FIELDS: doc_type, confidence_score, extraction_concerns
KEY SECTIONS TO EXTRACT:
- Parties: licensor, distributor_final, licensee_intermediary with full contact details
- Territory: countries/regions (as array)
- Rights: theatrical, home video, SVOD, TVOD, etc.
- Financial: minimum guarantee amounts, distribution fees, expense caps
- Term: duration, start/end dates, renewal options
- Holdbacks: SVOD/theatrical restrictions with durations

Return confidence_score 0.0-1.0 and list any extraction_concerns.

DOCUMENT TO EXTRACT:`;

  try {
    // First attempt with strict JSON schema
    const response = await fetch('https://api.openai.com/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${openAIApiKey}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        model: EXTRACT_MODEL,
        messages: [
          { role: 'system', content: EXTRACTION_PREFIX },
          { role: 'user', content: cleanText }
        ],
        max_completion_tokens: TOKEN_LIMITS.EXTRACT,
        temperature: 0,
        response_format: { 
          type: "json_schema", 
          json_schema: {
            name: "distribution_agreement_extraction",
            schema: DISTRIBUTION_AGREEMENT_SCHEMA,
            strict: true
          }
        }
      }),
    });

    if (!response.ok) {
      console.log('Strict extraction failed, trying fallback model');
      return await extractWithFallback(cleanText);
    }

    const data = await response.json();
    const result = JSON.parse(data.choices[0].message.content);
    
    // Validate and normalize data structure
    if (!result.confidence_score || !result.extraction_concerns) {
      console.log('Missing critical fields, using fallback');
      return await extractWithFallback(cleanText);
    }

    // Ensure extraction_concerns is always an array
    if (typeof result.extraction_concerns === 'string') {
      result.extraction_concerns = [result.extraction_concerns];
    }
    if (!Array.isArray(result.extraction_concerns)) {
      result.extraction_concerns = ['Invalid extraction_concerns format'];
    }

    return result;
  } catch (error) {
    console.error('Extraction error:', error);
    return await extractWithFallback(cleanText);
  }
}

async function extractWithFallback(cleanText: string) {
  try {
    const response = await fetch('https://api.openai.com/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${openAIApiKey}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        model: EXTRACT_FALLBACK,
        messages: [
          { 
            role: 'system', 
            content: `Extract structured data from document. Return valid JSON with required fields: document_type, parties, confidence_score, extraction_concerns.`
          },
          { role: 'user', content: cleanText }
        ],
        max_tokens: TOKEN_LIMITS.EXTRACT,
        temperature: 0,
        response_format: { type: "json_object" }
      }),
    });

    if (!response.ok) {
      throw new Error(`Fallback extraction failed: ${response.status}`);
    }

    const data = await response.json();
    const result = JSON.parse(data.choices[0].message.content);
    
    // Ensure extraction_concerns is always an array
    if (typeof result.extraction_concerns === 'string') {
      result.extraction_concerns = [result.extraction_concerns];
    }
    if (!Array.isArray(result.extraction_concerns)) {
      result.extraction_concerns = ['Invalid extraction_concerns format'];
    }
    
    return result;
  } catch (error) {
    console.error('Fallback extraction error:', error);
    return {
      document_type: "other",
      parties: ["Unknown"],
      confidence_score: 0.0,
      extraction_concerns: [`Extraction completely failed: ${error.message}`]
    };
  }
}

function sanitizeText(text: string): string {
  // Remove binary content, normalize tables, clean metadata
  return text
    .replace(/[\x00-\x08\x0B\x0C\x0E-\x1F\x7F-\x9F]/g, '') // Remove control chars
    .replace(/\s+/g, ' ') // Normalize whitespace
    .replace(/[^\x20-\x7E\u00A0-\u024F\u1E00-\u1EFF]/g, '') // Keep only printable chars
    .trim()
    .substring(0, 8000); // Limit length for cost control
}