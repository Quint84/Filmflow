
import "https://deno.land/x/xhr@0.1.0/mod.ts";
import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.56.1";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
const supabaseKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;

const supabase = createClient(supabaseUrl, supabaseKey);

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  let requestBody;
  try {
    requestBody = await req.json();
  } catch (parseError) {
    console.error('Error parsing request body:', parseError);
    return new Response(
      JSON.stringify({ error: 'Invalid JSON in request body' }),
      {
        status: 400,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      }
    );
  }

  try {
    const { fileName, docId, uploadPath } = requestBody;
    console.log(`Starting collection for: ${fileName}, docId: ${docId}`);

    if (!fileName || !docId || !uploadPath) {
      throw new Error('Missing required parameters: fileName, docId, or uploadPath');
    }

    // Step 1: Calculate SHA256 hash
    const { data: fileData, error: downloadError } = await supabase.storage
      .from('documents')
      .download(uploadPath);

    if (downloadError) {
      console.error('Download error:', downloadError);
      throw new Error(`Error downloading file: ${downloadError.message}`);
    }

    const arrayBuffer = await fileData.arrayBuffer();
    const hashBuffer = await crypto.subtle.digest('SHA-256', arrayBuffer);
    const sha256 = Array.from(new Uint8Array(hashBuffer))
      .map(b => b.toString(16).padStart(2, '0'))
      .join('');

    console.log(`File SHA256: ${sha256}`);

    // Step 2: Update doc_index with metadata
    const { error: updateError } = await supabase
      .from('doc_index')
      .update({
        file_hash: sha256,
        file_size: arrayBuffer.byteLength,
        mime_type: fileData.type,
        status: 'processing',
        updated_at: new Date().toISOString()
      })
      .eq('id', docId);

    if (updateError) {
      console.error('Error updating doc_index:', updateError);
      throw updateError;
    }

    // Step 3: Enqueue TASK_CLASSIFY
    const { error: taskError } = await supabase
      .from('task_queue')
      .insert({
        task_type: 'TASK_CLASSIFY',
        doc_id: docId,
        payload: {
          file_path: uploadPath,
          filename: fileName,
          file_hash: sha256
        },
        status: 'pending'
      });

    if (taskError) {
      console.error('Error enqueueing task:', taskError);
      throw taskError;
    }

    console.log(`Collection completed for docId: ${docId}`);

    return new Response(
      JSON.stringify({ 
        success: true,
        file_hash: sha256,
        nextStage: 'classify'
      }),
      {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      }
    );

  } catch (error) {
    console.error('Error in document collector:', error);
    
    // Update doc status to error if docId is available
    if (requestBody && requestBody.docId) {
      try {
        await supabase
          .from('doc_index')
          .update({
            status: 'error',
            metadata: { error: error.message }
          })
          .eq('id', requestBody.docId);
      } catch (statusUpdateError) {
        console.error('Error updating doc status:', statusUpdateError);
      }
    }

    return new Response(
      JSON.stringify({ error: error.message }),
      {
        status: 500,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      }
    );
  }
});
