import "https://deno.land/x/xhr@0.1.0/mod.ts";
import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.56.1";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
const supabaseKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
const openAIApiKey = Deno.env.get('OPENAI_API_KEY')!;

const supabase = createClient(supabaseUrl, supabaseKey);

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  let docId: string;
  
  try {
    const reqBody = await req.json();
    docId = reqBody.docId;
    console.log(`Starting document parsing for docId: ${docId}`);

    // Get document info
    const { data: docData, error: docError } = await supabase
      .from('doc_index')
      .select('*')
      .eq('id', docId)
      .single();

    if (docError || !docData) {
      console.error('Document not found:', docError);
      throw new Error('Document not found');
    }

    // Download file for parsing
    const { data: fileData, error: downloadError } = await supabase.storage
      .from('documents')
      .download(docData.file_path);

    if (downloadError) {
      console.error('Download error:', downloadError);
      throw new Error(`Error downloading file: ${downloadError.message}`);
    }

    // Extract text based on file type
    const extractedText = await extractTextFromFile(docData.file_name, docData.mime_type, fileData);
    console.log('Text extracted, length:', extractedText.length);

    // Parse with AI for structured data
    const structuredData = await parseWithAI(extractedText, docData.file_name);
    console.log('AI parsing completed');

    // Sanitize extracted text for database storage (remove null bytes and problematic Unicode)
    const sanitizedText = extractedText
      .replace(/\u0000/g, '') // Remove null bytes that cause PostgreSQL errors
      .replace(/[\u0001-\u0008\u000B\u000C\u000E-\u001F\u007F-\u009F]/g, '') // Remove control characters
      .replace(/\uFFFD/g, ''); // Remove replacement characters
    
    console.log('Text sanitized for database storage');

    // Update doc_index with parsed results
    const { error: updateError } = await supabase
      .from('doc_index')
      .update({
        extracted_text: sanitizedText,
        structured_data: structuredData,
        status: 'processing',
        updated_at: new Date().toISOString()
      })
      .eq('id', docId);

    if (updateError) {
      console.error('Update error:', updateError);
      throw updateError;
    }

    // Enqueue classification task
    const { error: taskError } = await supabase
      .from('task_queue')
      .insert({
        task_type: 'TASK_CLASSIFY',
        doc_id: docId,
        payload: {
          extracted_text: extractedText.substring(0, 1000) // Limit for classification
        },
        status: 'pending'
      });

    if (taskError) {
      console.error('Task queue error:', taskError);
    }

    return new Response(
      JSON.stringify({ 
        success: true,
        extractedText,
        structuredData,
        nextStage: 'classification'
      }),
      {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      }
    );

  } catch (error) {
    console.error('Error in document parser:', error);
    
    // Try to update doc status to error if we have docId
    if (docId) {
      try {
        await supabase
          .from('doc_index')
          .update({
            status: 'error',
            metadata: { error: error.message, stage: 'parsing' }
          })
          .eq('id', docId);
      } catch (updateError) {
        console.error('Error updating doc status:', updateError);
      }
    }

    return new Response(
      JSON.stringify({ 
        success: false,
        error: error.message,
        docId: docId || 'unknown'
      }),
      {
        status: 200, // Return 200 to avoid "non-2xx" error
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      }
    );
  }
});

async function extractTextFromFile(filename: string, mimeType: string, fileData: Blob): Promise<string> {
  console.log(`Extracting text from ${filename} (${mimeType})`);
  
  if (mimeType === 'application/pdf') {
    return await extractFromPDF(fileData);
  } else if (mimeType?.startsWith('image/')) {
    return await extractFromImage(fileData);
  } else if (mimeType?.startsWith('text/')) {
    return await extractFromText(fileData);
  } else {
    // Fallback to generic text extraction
    return await extractFromText(fileData);
  }
}

async function extractFromPDF(fileData: Blob): Promise<string> {
  try {
    console.log('Using Node.js PDF extractor service for proper content stream extraction...');
    
    // Use Node.js service for proper PDF parsing with pdfjs-dist
    const extractorUrl = Deno.env.get('PDF_EXTRACTOR_SERVICE_URL') || 'http://localhost:3001';
    
    const formData = new FormData();
    formData.append('file', fileData);
    
    const response = await fetch(`${extractorUrl}/api/extract`, {
      method: 'POST',
      body: formData
    });
    
    if (!response.ok) {
      console.error(`PDF extractor service error: ${response.status}`);
      throw new Error(`PDF extractor service returned ${response.status}`);
    }
    
    const result = await response.json();
    
    if (!result.success) {
      throw new Error(result.error || 'PDF extraction failed');
    }
    
    console.log(`PDF text extracted successfully: ${result.metadata.textLength} characters`);
    return result.extractedText;
    
  } catch (error) {
    console.error('PDF extraction via Node.js service failed:', error);
    console.log('Falling back to basic text extraction...');
    
    // Simple fallback - return basic file info instead of OCR
    return `Document: ${fileData.type || 'application/pdf'}
Size: ${fileData.size} bytes
Note: Text extraction failed. Manual review required.`;
  }
}

// Old PDF parsing functions removed - now using Node.js service with pdfjs-dist

async function extractFromImage(fileData: Blob): Promise<string> {
  return await performOCR(fileData);
}

async function extractFromText(fileData: Blob): Promise<string> {
  const text = await fileData.text();
  return text.trim();
}

async function performOCR(fileData: Blob): Promise<string> {
  if (!openAIApiKey) {
    throw new Error('OpenAI API key not available for OCR');
  }

  try {
    // Convert to base64 for OpenAI Vision API
    const arrayBuffer = await fileData.arrayBuffer();
    const base64Data = btoa(String.fromCharCode(...new Uint8Array(arrayBuffer)));
    
    const response = await fetch('https://api.openai.com/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${openAIApiKey}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        model: 'gpt-4o',
        messages: [
          {
            role: 'system',
            content: 'You are an expert OCR system. Extract all text from the image as accurately as possible. Maintain formatting and structure. Return only the extracted text without any additional commentary.'
          },
          {
            role: 'user',
            content: [
              {
                type: 'text',
                text: 'Extract all text from this image:'
              },
              {
                type: 'image_url',
                image_url: {
                  url: `data:image/jpeg;base64,${base64Data}`
                }
              }
            ]
          }
        ],
        max_tokens: 4000,
        temperature: 0
      }),
    });

    if (!response.ok) {
      throw new Error(`OCR API error: ${response.status}`);
    }

    const data = await response.json();
    return data.choices[0].message.content.trim();
  } catch (error) {
    console.error('OCR error:', error);
    throw error;
  }
}

async function parseWithAI(extractedText: string, filename: string) {
  if (!openAIApiKey) {
    throw new Error('OpenAI API key not available for parsing');
  }

  try {
    const systemPrompt = `You are an expert document parser specializing in legal, financial, and audiovisual production documents. Extract structured information from the provided text.

Return a JSON object with this exact structure:

{
  "document_type": "string", // contract, invoice, budget, agreement, etc.
  "title": "string", // document or project title
  "parties": ["string"], // involved parties/companies
  "key_dates": {
    "start_date": "YYYY-MM-DD or null",
    "end_date": "YYYY-MM-DD or null", 
    "payment_dates": ["YYYY-MM-DD"],
    "other_dates": [{"date": "YYYY-MM-DD", "description": "string"}]
  },
  "financial_terms": {
    "total_amount": "number or null",
    "currency": "string or null",
    "payment_schedule": ["string"],
    "hourly_rate": "number or null"
  },
  "project_details": {
    "project_code": "string or null",
    "genre": "string or null",
    "duration": "string or null",
    "locations": ["string"]
  },
  "contact_info": {
    "emails": ["string"],
    "phones": ["string"],
    "addresses": ["string"]
  },
  "key_clauses": ["string"], // important terms/conditions
  "deliverables": ["string"], // expected outputs/deliverables
  "metadata": {
    "confidence_score": 0.0, // 0-1 confidence in extraction
    "language": "string",
    "extracted_fields": ["string"] // fields successfully extracted
  }
}

Use null for missing fields. Be precise and conservative in extraction.`;

    const response = await fetch('https://api.openai.com/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${openAIApiKey}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        model: 'gpt-5-mini-2025-08-07',
        messages: [
          { role: 'system', content: systemPrompt },
          { role: 'user', content: `Parse this document and extract structured data:\n\n${extractedText}` }
        ],
        max_completion_tokens: 2000,
        response_format: { type: "json_object" }
      }),
    });

    if (!response.ok) {
      console.error('Parsing API error:', response.status);
      throw new Error(`OpenAI API error: ${response.status}`);
    }

    const data = await response.json();
    return JSON.parse(data.choices[0].message.content);
  } catch (error) {
    console.error('AI parsing error:', error);
    throw error;
  }
}

// Mock functions removed - no more fake data generation

// Unused PDF parsing functions removed - now using Node.js service with pdfjs-dist