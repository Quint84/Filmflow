-- Add doc_id column to task_queue table
ALTER TABLE sys.task_queue 
ADD COLUMN IF NOT EXISTS doc_id UUID REFERENCES public.doc_index(id);