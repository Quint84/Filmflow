-- Update distribution agreements table structure to match the comprehensive schema
DROP TABLE IF EXISTS public.afma_agreements CASCADE;
DROP TABLE IF EXISTS public.ifta_agreements CASCADE;
DROP TABLE IF EXISTS public.distribution_agreements CASCADE;
DROP TABLE IF EXISTS public.sales_agency_agreements CASCADE;
DROP TABLE IF EXISTS public.co_production_agreements CASCADE;

-- Create comprehensive distribution agreements table
CREATE TABLE public.distribution_agreements (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  doc_id UUID NOT NULL,
  user_id UUID NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  
  -- Basic document info
  doc_type TEXT NOT NULL DEFAULT 'DIST_AGREEMENT',
  document_title TEXT,
  document_date DATE,
  project_title TEXT,
  project_code TEXT,
  
  -- Parties (stored as JSONB for flexibility)
  parties JSONB NOT NULL DEFAULT '{}',
  
  -- Rights and territory
  territory TEXT[] DEFAULT '{}',
  languages_authorized TEXT[] DEFAULT '{}',
  rights_granted TEXT[] DEFAULT '{}',
  exclusivity BOOLEAN DEFAULT false,
  
  -- Term information
  term JSONB NOT NULL DEFAULT '{}',
  
  -- Revenue model (complex nested structure)
  revenue_model JSONB NOT NULL DEFAULT '{}',
  
  -- Holdbacks
  holdbacks JSONB DEFAULT '[]',
  
  -- Release obligations
  release_obligations JSONB DEFAULT '{}',
  
  -- Reporting
  reporting JSONB DEFAULT '{}',
  
  -- Materials and delivery
  materials_delivery JSONB DEFAULT '{}',
  
  -- Banking
  banking JSONB DEFAULT '{}',
  
  -- Security and assignments
  security_and_assignments JSONB DEFAULT '{}',
  
  -- Taxes
  taxes JSONB DEFAULT '{}',
  
  -- Compliance
  compliance JSONB DEFAULT '{}',
  
  -- Subdistribution
  subdistribution JSONB DEFAULT '{}',
  
  -- Approvals
  approvals JSONB DEFAULT '{}',
  
  -- Termination
  termination JSONB DEFAULT '[]',
  
  -- Notices
  notices JSONB DEFAULT '{}',
  
  -- Signatures
  signatures JSONB DEFAULT '[]',
  
  -- Add foreign key to doc_index
  CONSTRAINT fk_distribution_agreements_doc_id FOREIGN KEY (doc_id) REFERENCES public.doc_index(id) ON DELETE CASCADE
);

-- Enable RLS
ALTER TABLE public.distribution_agreements ENABLE ROW LEVEL SECURITY;

-- Create RLS policies
CREATE POLICY "Users can view their own agreements" 
ON public.distribution_agreements 
FOR SELECT 
USING (auth.uid() = user_id);

CREATE POLICY "Users can insert their own agreements" 
ON public.distribution_agreements 
FOR INSERT 
WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update their own agreements" 
ON public.distribution_agreements 
FOR UPDATE 
USING (auth.uid() = user_id);

CREATE POLICY "Service role can manage all agreements" 
ON public.distribution_agreements 
FOR ALL 
USING (true);

CREATE POLICY "Admins and authorized teams can manage all agreements" 
ON public.distribution_agreements 
FOR ALL 
USING (has_role(auth.uid(), 'ADMIN'::app_role) OR has_role(auth.uid(), 'LP_FINANCE'::app_role) OR has_role(auth.uid(), 'PRODUCER'::app_role) OR has_role(auth.uid(), 'LEGAL'::app_role) OR has_role(auth.uid(), 'SALES'::app_role));

-- Add indexes for better performance
CREATE INDEX idx_distribution_agreements_doc_id ON public.distribution_agreements(doc_id);
CREATE INDEX idx_distribution_agreements_user_id ON public.distribution_agreements(user_id);
CREATE INDEX idx_distribution_agreements_project_code ON public.distribution_agreements(project_code);
CREATE INDEX idx_distribution_agreements_doc_type ON public.distribution_agreements(doc_type);

-- Add trigger for updated_at
CREATE TRIGGER update_distribution_agreements_updated_at
BEFORE UPDATE ON public.distribution_agreements
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();