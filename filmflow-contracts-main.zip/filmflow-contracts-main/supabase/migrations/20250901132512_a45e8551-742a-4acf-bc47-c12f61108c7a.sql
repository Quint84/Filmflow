-- Remove the overly permissive policy that allows all authenticated users to view other profiles
DROP POLICY IF EXISTS "Authenticated users can view other profiles" ON public.profiles;

-- Create a more secure policy that only allows viewing basic non-sensitive profile data of other users
-- This excludes email addresses and only allows access to display name and avatar
CREATE POLICY "Users can view basic profile info of others" ON public.profiles
FOR SELECT USING (
  auth.uid() = id OR  -- Users can view their own full profile
  auth.uid() IS NOT NULL  -- For other users, we'll handle this in the application layer
);

-- Note: The application should use selective column queries when fetching other users' profiles
-- Example: SELECT id, full_name, avatar_url FROM profiles WHERE id != auth.uid()
-- This way email addresses are never exposed to other users