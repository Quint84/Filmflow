-- Create document processing pipeline schema
CREATE SCHEMA IF NOT EXISTS sys;
CREATE SCHEMA IF NOT EXISTS inv_tax;
CREATE SCHEMA IF NOT EXISTS sales;
CREATE SCHEMA IF NOT EXISTS dist;
CREATE SCHEMA IF NOT EXISTS legal;

-- Document index system
CREATE TABLE sys.doc_index (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  file_path TEXT NOT NULL,
  file_url TEXT,
  sha256 TEXT NOT NULL UNIQUE,
  filename TEXT NOT NULL,
  file_size BIGINT,
  mime_type TEXT,
  doc_type TEXT,
  project_code TEXT,
  confidence DECIMAL(3,2),
  status TEXT DEFAULT 'pending' CHECK (status IN ('pending', 'processing', 'classified', 'parsed', 'extracted', 'validated', 'published', 'indexed', 'completed', 'error', 'review_required')),
  metadata JSONB DEFAULT '{}',
  embedding VECTOR(1536),
  created_at TIMESTAMPTZ DEFAULT now(),
  updated_at TIMESTAMPTZ DEFAULT now(),
  processed_at TIMESTAMPTZ,
  user_id UUID REFERENCES auth.users(id)
);

-- Task queue system
CREATE TABLE sys.task_queue (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  task_type TEXT NOT NULL CHECK (task_type IN ('TASK_CLASSIFY', 'TASK_PARSE', 'TASK_EXTRACT', 'TASK_VALIDATE', 'TASK_PUBLISH', 'TASK_INDEX')),
  doc_id UUID REFERENCES sys.doc_index(id) ON DELETE CASCADE,
  payload JSONB DEFAULT '{}',
  status TEXT DEFAULT 'pending' CHECK (status IN ('pending', 'processing', 'completed', 'failed', 'retry')),
  retry_count INTEGER DEFAULT 0,
  max_retries INTEGER DEFAULT 3,
  error_message TEXT,
  created_at TIMESTAMPTZ DEFAULT now(),
  started_at TIMESTAMPTZ,
  completed_at TIMESTAMPTZ
);

-- Document types configuration
CREATE TABLE sys.doc_types (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  description TEXT,
  json_schema JSONB NOT NULL,
  validation_rules JSONB DEFAULT '{}',
  regex_patterns TEXT[],
  confidence_threshold DECIMAL(3,2) DEFAULT 0.85,
  active BOOLEAN DEFAULT true,
  created_at TIMESTAMPTZ DEFAULT now()
);

-- Project events system
CREATE TABLE sys.project_events (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  project_code TEXT NOT NULL,
  event_type TEXT NOT NULL,
  event_data JSONB DEFAULT '{}',
  doc_id UUID REFERENCES sys.doc_index(id),
  user_id UUID REFERENCES auth.users(id),
  created_at TIMESTAMPTZ DEFAULT now()
);

-- Legal contracts and parties
CREATE TABLE legal.contracts (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  contract_number TEXT UNIQUE,
  title TEXT NOT NULL,
  contract_type TEXT,
  project_code TEXT,
  total_amount DECIMAL(15,2),
  currency TEXT DEFAULT 'EUR',
  start_date DATE,
  end_date DATE,
  status TEXT DEFAULT 'draft' CHECK (status IN ('draft', 'active', 'completed', 'terminated', 'cancelled')),
  doc_id UUID REFERENCES sys.doc_index(id),
  created_at TIMESTAMPTZ DEFAULT now(),
  updated_at TIMESTAMPTZ DEFAULT now()
);

CREATE TABLE legal.contract_parties (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  contract_id UUID REFERENCES legal.contracts(id) ON DELETE CASCADE,
  party_name TEXT NOT NULL,
  party_type TEXT CHECK (party_type IN ('individual', 'company', 'organization')),
  tax_id TEXT,
  email TEXT,
  phone TEXT,
  address TEXT,
  role TEXT,
  created_at TIMESTAMPTZ DEFAULT now()
);

CREATE TABLE legal.contract_obligations (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  contract_id UUID REFERENCES legal.contracts(id) ON DELETE CASCADE,
  description TEXT NOT NULL,
  party_responsible TEXT,
  due_date DATE,
  amount DECIMAL(15,2),
  currency TEXT DEFAULT 'EUR',
  status TEXT DEFAULT 'pending' CHECK (status IN ('pending', 'completed', 'overdue', 'cancelled')),
  created_at TIMESTAMPTZ DEFAULT now()
);

-- Invoice and tax tables
CREATE TABLE inv_tax.contracts (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  legal_contract_id UUID REFERENCES legal.contracts(id),
  invoice_number TEXT UNIQUE,
  total_base DECIMAL(15,2),
  tax_rate DECIMAL(5,2),
  tax_amount DECIMAL(15,2),
  total_amount DECIMAL(15,2),
  currency TEXT DEFAULT 'EUR',
  issue_date DATE,
  due_date DATE,
  status TEXT DEFAULT 'pending' CHECK (status IN ('pending', 'sent', 'paid', 'overdue', 'cancelled')),
  created_at TIMESTAMPTZ DEFAULT now()
);

-- Sales and distribution tables
CREATE TABLE sales.mla_territory_exhibit (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  project_code TEXT NOT NULL,
  territory TEXT NOT NULL,
  media_type TEXT,
  rights_type TEXT,
  start_date DATE,
  end_date DATE,
  minimum_guarantee DECIMAL(15,2),
  revenue_share DECIMAL(5,2),
  currency TEXT DEFAULT 'EUR',
  status TEXT DEFAULT 'active',
  doc_id UUID REFERENCES sys.doc_index(id),
  created_at TIMESTAMPTZ DEFAULT now()
);

CREATE TABLE dist.agreements (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  project_code TEXT NOT NULL,
  distributor_name TEXT NOT NULL,
  territory TEXT,
  platform TEXT,
  revenue_split DECIMAL(5,2),
  minimum_guarantee DECIMAL(15,2),
  marketing_commitment DECIMAL(15,2),
  currency TEXT DEFAULT 'EUR',
  start_date DATE,
  end_date DATE,
  doc_id UUID REFERENCES sys.doc_index(id),
  created_at TIMESTAMPTZ DEFAULT now()
);

-- Exception handling for HITL
CREATE TABLE sys.processing_exceptions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  doc_id UUID REFERENCES sys.doc_index(id) ON DELETE CASCADE,
  stage TEXT NOT NULL,
  original_data JSONB,
  suggested_data JSONB,
  diff_data JSONB,
  status TEXT DEFAULT 'pending' CHECK (status IN ('pending', 'accepted', 'edited', 'rejected')),
  reviewed_by UUID REFERENCES auth.users(id),
  reviewed_at TIMESTAMPTZ,
  notes TEXT,
  created_at TIMESTAMPTZ DEFAULT now()
);

-- Insert default document types
INSERT INTO sys.doc_types (id, name, description, json_schema, regex_patterns) VALUES 
(
  'contract',
  'Contrato',
  'Contratos legales y acuerdos',
  '{
    "type": "object",
    "properties": {
      "contract_number": {"type": "string"},
      "parties": {"type": "array", "items": {"type": "string"}},
      "total_amount": {"type": "number"},
      "currency": {"type": "string"},
      "start_date": {"type": "string", "format": "date"},
      "end_date": {"type": "string", "format": "date"},
      "obligations": {"type": "array"}
    },
    "required": ["parties", "total_amount"]
  }',
  ARRAY['contrato', 'agreement', 'contract', 'acuerdo']
),
(
  'invoice',
  'Factura',
  'Facturas e invoices',
  '{
    "type": "object",
    "properties": {
      "invoice_number": {"type": "string"},
      "total_base": {"type": "number"},
      "tax_rate": {"type": "number"},
      "tax_amount": {"type": "number"},
      "total_amount": {"type": "number"},
      "currency": {"type": "string"},
      "issue_date": {"type": "string", "format": "date"},
      "due_date": {"type": "string", "format": "date"}
    },
    "required": ["invoice_number", "total_amount"]
  }',
  ARRAY['factura', 'invoice', 'bill']
),
(
  'mla',
  'MLA Territory Exhibit',
  'Minimum License Agreements',
  '{
    "type": "object",
    "properties": {
      "territory": {"type": "string"},
      "media_type": {"type": "string"},
      "rights_type": {"type": "string"},
      "minimum_guarantee": {"type": "number"},
      "revenue_share": {"type": "number"},
      "currency": {"type": "string"}
    },
    "required": ["territory", "minimum_guarantee"]
  }',
  ARRAY['mla', 'territory', 'license', 'distribution']
);

-- Create indexes
CREATE INDEX idx_doc_index_status ON sys.doc_index(status);
CREATE INDEX idx_doc_index_project_code ON sys.doc_index(project_code);
CREATE INDEX idx_doc_index_doc_type ON sys.doc_index(doc_type);
CREATE INDEX idx_task_queue_status ON sys.task_queue(status);
CREATE INDEX idx_task_queue_task_type ON sys.task_queue(task_type);
CREATE INDEX idx_project_events_project_code ON sys.project_events(project_code);
CREATE INDEX idx_legal_contracts_project_code ON legal.contracts(project_code);

-- Enable RLS
ALTER TABLE sys.doc_index ENABLE ROW LEVEL SECURITY;
ALTER TABLE sys.task_queue ENABLE ROW LEVEL SECURITY;
ALTER TABLE sys.project_events ENABLE ROW LEVEL SECURITY;
ALTER TABLE sys.processing_exceptions ENABLE ROW LEVEL SECURITY;
ALTER TABLE legal.contracts ENABLE ROW LEVEL SECURITY;
ALTER TABLE legal.contract_parties ENABLE ROW LEVEL SECURITY;
ALTER TABLE legal.contract_obligations ENABLE ROW LEVEL SECURITY;
ALTER TABLE inv_tax.contracts ENABLE ROW LEVEL SECURITY;
ALTER TABLE sales.mla_territory_exhibit ENABLE ROW LEVEL SECURITY;
ALTER TABLE dist.agreements ENABLE ROW LEVEL SECURITY;

-- RLS Policies
CREATE POLICY "Users can view their documents" ON sys.doc_index FOR SELECT USING (auth.uid() = user_id);
CREATE POLICY "Users can insert their documents" ON sys.doc_index FOR INSERT WITH CHECK (auth.uid() = user_id);
CREATE POLICY "Users can update their documents" ON sys.doc_index FOR UPDATE USING (auth.uid() = user_id);

CREATE POLICY "Users can view their tasks" ON sys.task_queue FOR SELECT USING (
  EXISTS (SELECT 1 FROM sys.doc_index WHERE id = doc_id AND user_id = auth.uid())
);

CREATE POLICY "System can manage tasks" ON sys.task_queue FOR ALL USING (true);

CREATE POLICY "Users can view project events" ON sys.project_events FOR SELECT USING (
  auth.uid() = user_id OR 
  has_role(auth.uid(), 'ADMIN') OR 
  has_role(auth.uid(), 'PRODUCER')
);

CREATE POLICY "Users can view their exceptions" ON sys.processing_exceptions FOR SELECT USING (
  EXISTS (SELECT 1 FROM sys.doc_index WHERE id = doc_id AND user_id = auth.uid())
);

CREATE POLICY "Users can update their exceptions" ON sys.processing_exceptions FOR UPDATE USING (
  EXISTS (SELECT 1 FROM sys.doc_index WHERE id = doc_id AND user_id = auth.uid())
);

-- Triggers for updated_at
CREATE TRIGGER update_doc_index_updated_at
  BEFORE UPDATE ON sys.doc_index
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_legal_contracts_updated_at
  BEFORE UPDATE ON legal.contracts
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();