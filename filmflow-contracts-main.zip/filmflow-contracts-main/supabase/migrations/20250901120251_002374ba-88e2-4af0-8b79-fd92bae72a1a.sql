-- Create the doc_index table with proper structure
CREATE TABLE IF NOT EXISTS public.doc_index (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    file_name TEXT NOT NULL,
    file_path TEXT NOT NULL,
    file_size BIGINT,
    file_hash VARCHAR(64),
    upload_date TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    status TEXT DEFAULT 'uploaded' CHECK (status IN ('uploaded', 'processing', 'completed', 'error')),
    doc_type TEXT,
    project_code TEXT,
    confidence DECIMAL(3,2),
    extracted_text TEXT,
    structured_data JSONB,
    embedding VECTOR(1536),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    user_id UUID REFERENCES auth.users(id)
);

-- Create sys schema for system tables
CREATE SCHEMA IF NOT EXISTS sys;

-- Create task queue table
CREATE TABLE IF NOT EXISTS sys.task_queue (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    task_type TEXT NOT NULL,
    payload JSONB NOT NULL,
    status TEXT DEFAULT 'pending' CHECK (status IN ('pending', 'processing', 'completed', 'failed')),
    attempts INTEGER DEFAULT 0,
    max_attempts INTEGER DEFAULT 3,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    scheduled_for TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    error_message TEXT
);

-- Create doc types configuration table
CREATE TABLE IF NOT EXISTS sys.doc_types (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    type_name TEXT UNIQUE NOT NULL,
    json_schema JSONB NOT NULL,
    validation_rules JSONB,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Create project events table
CREATE TABLE IF NOT EXISTS sys.project_events (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    project_code TEXT NOT NULL,
    event_type TEXT NOT NULL,
    event_data JSONB,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    user_id UUID REFERENCES auth.users(id)
);

-- Create processing exceptions table
CREATE TABLE IF NOT EXISTS sys.processing_exceptions (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    doc_id UUID REFERENCES public.doc_index(id),
    exception_type TEXT NOT NULL,
    original_data JSONB,
    suggested_changes JSONB,
    status TEXT DEFAULT 'pending' CHECK (status IN ('pending', 'approved', 'rejected')),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    reviewed_by UUID REFERENCES auth.users(id),
    reviewed_at TIMESTAMP WITH TIME ZONE
);

-- Enable RLS on all tables
ALTER TABLE public.doc_index ENABLE ROW LEVEL SECURITY;
ALTER TABLE sys.task_queue ENABLE ROW LEVEL SECURITY;
ALTER TABLE sys.doc_types ENABLE ROW LEVEL SECURITY;
ALTER TABLE sys.project_events ENABLE ROW LEVEL SECURITY;
ALTER TABLE sys.processing_exceptions ENABLE ROW LEVEL SECURITY;

-- Create RLS policies for doc_index
CREATE POLICY "Users can view their own documents" ON public.doc_index
    FOR SELECT USING (auth.uid() = user_id);

CREATE POLICY "Users can insert their own documents" ON public.doc_index
    FOR INSERT WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update their own documents" ON public.doc_index
    FOR UPDATE USING (auth.uid() = user_id);

-- Create policies for system tables (admin access only)
CREATE POLICY "Admin access to task queue" ON sys.task_queue
    FOR ALL USING (
        EXISTS (
            SELECT 1 FROM user_roles 
            WHERE user_id = auth.uid() 
            AND role IN ('ADMIN')
        )
    );

CREATE POLICY "Admin access to doc types" ON sys.doc_types
    FOR ALL USING (
        EXISTS (
            SELECT 1 FROM user_roles 
            WHERE user_id = auth.uid() 
            AND role IN ('ADMIN')
        )
    );

-- Create policies for exceptions (reviewers can access)
CREATE POLICY "Reviewers can access exceptions" ON sys.processing_exceptions
    FOR ALL USING (
        EXISTS (
            SELECT 1 FROM user_roles 
            WHERE user_id = auth.uid() 
            AND role IN ('ADMIN', 'LEGAL', 'PRODUCER')
        )
    );

-- Create indexes for performance
CREATE INDEX IF NOT EXISTS idx_doc_index_status ON public.doc_index(status);
CREATE INDEX IF NOT EXISTS idx_doc_index_doc_type ON public.doc_index(doc_type);
CREATE INDEX IF NOT EXISTS idx_doc_index_project_code ON public.doc_index(project_code);
CREATE INDEX IF NOT EXISTS idx_doc_index_user_id ON public.doc_index(user_id);
CREATE INDEX IF NOT EXISTS idx_task_queue_status ON sys.task_queue(status);
CREATE INDEX IF NOT EXISTS idx_task_queue_scheduled ON sys.task_queue(scheduled_for);

-- Create triggers for timestamp updates
CREATE TRIGGER update_doc_index_updated_at
    BEFORE UPDATE ON public.doc_index
    FOR EACH ROW
    EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_task_queue_updated_at
    BEFORE UPDATE ON sys.task_queue
    FOR EACH ROW
    EXECUTE FUNCTION update_updated_at_column();

-- Insert default document types
INSERT INTO sys.doc_types (type_name, json_schema) VALUES
('contract', '{"type": "object", "properties": {"title": {"type": "string"}, "parties": {"type": "array"}, "terms": {"type": "object"}}}'),
('invoice', '{"type": "object", "properties": {"invoice_number": {"type": "string"}, "amount": {"type": "number"}, "currency": {"type": "string"}}}'),
('proposal', '{"type": "object", "properties": {"title": {"type": "string"}, "budget": {"type": "number"}, "timeline": {"type": "string"}}}'),
('legal_document', '{"type": "object", "properties": {"document_type": {"type": "string"}, "jurisdiction": {"type": "string"}, "effective_date": {"type": "string"}}}')
ON CONFLICT (type_name) DO NOTHING;