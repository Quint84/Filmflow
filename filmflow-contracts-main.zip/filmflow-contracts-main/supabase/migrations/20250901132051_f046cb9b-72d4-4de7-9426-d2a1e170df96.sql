-- Update task queue policies to allow edge functions to access it
CREATE POLICY "Service role can manage task queue" ON sys.task_queue
    FOR ALL USING (true);

-- Update doc_index policies to allow edge functions to access it  
CREATE POLICY "Service role can manage doc_index" ON public.doc_index
    FOR ALL USING (true);