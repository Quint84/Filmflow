-- Create RLS policies for sys.doc_types
CREATE POLICY "Users can view doc types" ON sys.doc_types
    FOR SELECT USING (true);

-- Create RLS policies for sys.project_events  
CREATE POLICY "Users can view project events for their projects" ON sys.project_events
    FOR SELECT USING (
        EXISTS (
            SELECT 1 FROM user_roles 
            WHERE user_id = auth.uid() 
            AND role IN ('ADMIN', 'PRODUCER', 'LEGAL', 'HOD')
        ) OR auth.uid() = user_id
    );

CREATE POLICY "Users can insert project events" ON sys.project_events
    FOR INSERT WITH CHECK (
        EXISTS (
            SELECT 1 FROM user_roles 
            WHERE user_id = auth.uid() 
            AND role IN ('ADMIN', 'PRODUCER', 'LEGAL', 'HOD')
        ) OR auth.uid() = user_id
    );