-- Create a function to promote a user to admin (for initial setup)
CREATE OR REPLACE FUNCTION public.promote_user_to_admin(user_email TEXT)
RETURNS boolean
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  target_user_id UUID;
BEGIN
  -- Find the user by email
  SELECT id INTO target_user_id
  FROM auth.users
  WHERE email = user_email;
  
  IF target_user_id IS NULL THEN
    RAISE EXCEPTION 'User with email % not found', user_email;
  END IF;
  
  -- Remove existing roles for this user
  DELETE FROM public.user_roles WHERE user_id = target_user_id;
  
  -- Add ADMIN role
  INSERT INTO public.user_roles (user_id, role)
  VALUES (target_user_id, 'ADMIN');
  
  RETURN TRUE;
END;
$$;

-- Create a function to make the first registered user an admin automatically
CREATE OR REPLACE FUNCTION public.auto_promote_first_user()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  user_count INTEGER;
BEGIN
  -- Count total users
  SELECT COUNT(*) INTO user_count FROM auth.users;
  
  -- If this is the first user, make them admin
  IF user_count = 1 THEN
    -- Remove the default HOD role
    DELETE FROM public.user_roles WHERE user_id = NEW.id;
    
    -- Add ADMIN role
    INSERT INTO public.user_roles (user_id, role)
    VALUES (NEW.id, 'ADMIN');
    
    -- Also add PRODUCER role for full access
    INSERT INTO public.user_roles (user_id, role)
    VALUES (NEW.id, 'PRODUCER');
  END IF;
  
  RETURN NEW;
END;
$$;

-- Create trigger to auto-promote first user
DROP TRIGGER IF EXISTS auto_promote_first_user_trigger ON public.profiles;
CREATE TRIGGER auto_promote_first_user_trigger
  AFTER INSERT ON public.profiles
  FOR EACH ROW
  EXECUTE FUNCTION public.auto_promote_first_user();