-- Create pipeline schema
CREATE SCHEMA IF NOT EXISTS pipeline;

-- Create task queue table
CREATE TABLE pipeline.tasks(
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  task_type text NOT NULL, -- TASK_CLASSIFY, TASK_PARSE, TASK_EXTRACT, etc.
  status text NOT NULL DEFAULT 'PENDING', -- PENDING, PROCESSING, COMPLETED, FAILED
  priority integer DEFAULT 0,
  payload jsonb NOT NULL,
  result jsonb,
  error_message text,
  retry_count integer DEFAULT 0,
  max_retries integer DEFAULT 3,
  created_at timestamptz DEFAULT now(),
  started_at timestamptz,
  completed_at timestamptz,
  scheduled_for timestamptz DEFAULT now()
);

-- Create document processing pipeline table
CREATE TABLE pipeline.document_processing(
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  doc_index_id uuid REFERENCES sys.doc_index(id) ON DELETE CASCADE,
  original_filename text,
  file_size bigint,
  file_hash char(64),
  mime_type text,
  status text NOT NULL DEFAULT 'UPLOADED', -- UPLOADED, CLASSIFIED, PARSED, EXTRACTED, VALIDATED, PUBLISHED, INDEXED, COMPLETED, FAILED
  current_step text,
  confidence_score numeric(3,2),
  requires_review boolean DEFAULT false,
  metadata jsonb DEFAULT '{}',
  extracted_data jsonb,
  validation_errors jsonb,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create document classification results
CREATE TABLE pipeline.classification_results(
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  document_id uuid REFERENCES pipeline.document_processing(id) ON DELETE CASCADE,
  detected_doc_type text,
  detected_project_code text,
  confidence_score numeric(3,2),
  llm_response jsonb,
  regex_matches jsonb,
  created_at timestamptz DEFAULT now()
);

-- Create validation results table
CREATE TABLE pipeline.validation_results(
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  document_id uuid REFERENCES pipeline.document_processing(id) ON DELETE CASCADE,
  rule_name text NOT NULL,
  rule_type text NOT NULL, -- SUM_CHECK, IBAN_VALIDATION, CURRENCY_CHECK, DATE_VALIDATION, etc.
  passed boolean NOT NULL,
  expected_value text,
  actual_value text,
  error_message text,
  created_at timestamptz DEFAULT now()
);

-- Create human review queue
CREATE TABLE pipeline.review_queue(
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  document_id uuid REFERENCES pipeline.document_processing(id) ON DELETE CASCADE,
  review_type text NOT NULL, -- LOW_CONFIDENCE, VALIDATION_FAILED, MANUAL_REQUEST
  assigned_to uuid REFERENCES profiles(id),
  status text DEFAULT 'PENDING', -- PENDING, IN_REVIEW, APPROVED, REJECTED
  original_data jsonb,
  suggested_data jsonb,
  reviewer_notes text,
  created_at timestamptz DEFAULT now(),
  reviewed_at timestamptz
);

-- Create project events table
CREATE TABLE pipeline.project_events(
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  project_code text REFERENCES core.projects(code) ON UPDATE CASCADE,
  event_type text NOT NULL, -- DOCUMENT_UPLOADED, DOCUMENT_PROCESSED, CONTRACT_CREATED, etc.
  event_data jsonb,
  document_id uuid REFERENCES pipeline.document_processing(id),
  created_by uuid REFERENCES profiles(id),
  created_at timestamptz DEFAULT now()
);

-- Create storage bucket for documents
INSERT INTO storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
VALUES (
  'document-processing', 
  'document-processing', 
  false,
  52428800, -- 50MB limit
  ARRAY['application/pdf', 'image/jpeg', 'image/png', 'image/tiff', 'application/msword', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document']
) ON CONFLICT (id) DO NOTHING;

-- Create indexes
CREATE INDEX idx_pipeline_tasks_status ON pipeline.tasks(status);
CREATE INDEX idx_pipeline_tasks_type_status ON pipeline.tasks(task_type, status);
CREATE INDEX idx_pipeline_tasks_scheduled ON pipeline.tasks(scheduled_for) WHERE status = 'PENDING';
CREATE INDEX idx_pipeline_document_processing_status ON pipeline.document_processing(status);
CREATE INDEX idx_pipeline_document_processing_doc_index ON pipeline.document_processing(doc_index_id);
CREATE INDEX idx_pipeline_review_queue_status ON pipeline.review_queue(status);
CREATE INDEX idx_pipeline_review_queue_assigned ON pipeline.review_queue(assigned_to) WHERE status = 'PENDING';
CREATE INDEX idx_pipeline_project_events_project ON pipeline.project_events(project_code);
CREATE INDEX idx_pipeline_project_events_created_at ON pipeline.project_events(created_at);

-- Create trigger for updating timestamps
CREATE TRIGGER update_pipeline_document_processing_updated_at
  BEFORE UPDATE ON pipeline.document_processing
  FOR EACH ROW
  EXECUTE FUNCTION public.update_updated_at_column();

-- Enable RLS
ALTER TABLE pipeline.tasks ENABLE ROW LEVEL SECURITY;
ALTER TABLE pipeline.document_processing ENABLE ROW LEVEL SECURITY;
ALTER TABLE pipeline.classification_results ENABLE ROW LEVEL SECURITY;
ALTER TABLE pipeline.validation_results ENABLE ROW LEVEL SECURITY;
ALTER TABLE pipeline.review_queue ENABLE ROW LEVEL SECURITY;
ALTER TABLE pipeline.project_events ENABLE ROW LEVEL SECURITY;

-- RLS Policies for pipeline tables
CREATE POLICY "Admins can manage pipeline tasks"
ON pipeline.tasks FOR ALL
USING (public.has_role(auth.uid(), 'ADMIN'));

CREATE POLICY "Authorized users can view document processing"
ON pipeline.document_processing FOR ALL
USING (
  public.has_role(auth.uid(), 'ADMIN') OR 
  public.has_role(auth.uid(), 'LP_FINANCE') OR
  public.has_role(auth.uid(), 'PRODUCER') OR
  public.has_role(auth.uid(), 'LEGAL') OR
  public.has_role(auth.uid(), 'SALES')
);

CREATE POLICY "Authorized users can view classification results"
ON pipeline.classification_results FOR ALL
USING (
  public.has_role(auth.uid(), 'ADMIN') OR 
  public.has_role(auth.uid(), 'LP_FINANCE') OR
  public.has_role(auth.uid(), 'PRODUCER') OR
  public.has_role(auth.uid(), 'LEGAL') OR
  public.has_role(auth.uid(), 'SALES')
);

CREATE POLICY "Authorized users can view validation results"
ON pipeline.validation_results FOR ALL
USING (
  public.has_role(auth.uid(), 'ADMIN') OR 
  public.has_role(auth.uid(), 'LP_FINANCE') OR
  public.has_role(auth.uid(), 'PRODUCER') OR
  public.has_role(auth.uid(), 'LEGAL') OR
  public.has_role(auth.uid(), 'SALES')
);

CREATE POLICY "Users can view assigned reviews and admins can view all"
ON pipeline.review_queue FOR SELECT
USING (
  assigned_to = auth.uid() OR
  public.has_role(auth.uid(), 'ADMIN') OR 
  public.has_role(auth.uid(), 'LEGAL')
);

CREATE POLICY "Authorized users can insert reviews"
ON pipeline.review_queue FOR INSERT
WITH CHECK (
  public.has_role(auth.uid(), 'ADMIN') OR 
  public.has_role(auth.uid(), 'LEGAL') OR
  public.has_role(auth.uid(), 'LP_FINANCE')
);

CREATE POLICY "Authorized users can update reviews"
ON pipeline.review_queue FOR UPDATE
USING (
  public.has_role(auth.uid(), 'ADMIN') OR 
  public.has_role(auth.uid(), 'LEGAL') OR
  public.has_role(auth.uid(), 'LP_FINANCE') OR
  assigned_to = auth.uid()
);

CREATE POLICY "Admins can delete reviews"
ON pipeline.review_queue FOR DELETE
USING (public.has_role(auth.uid(), 'ADMIN'));

CREATE POLICY "Project members can view events for their projects"
ON pipeline.project_events FOR SELECT
USING (
  EXISTS (
    SELECT 1 FROM core.projects p
    JOIN core.project_members pm ON p.id = pm.project_id
    WHERE p.code = pipeline.project_events.project_code 
    AND pm.user_id = auth.uid()
  ) OR
  public.has_role(auth.uid(), 'ADMIN') OR 
  public.has_role(auth.uid(), 'LP_FINANCE') OR
  public.has_role(auth.uid(), 'PRODUCER') OR
  public.has_role(auth.uid(), 'LEGAL') OR
  public.has_role(auth.uid(), 'SALES')
);

CREATE POLICY "Authorized users can create project events"
ON pipeline.project_events FOR INSERT
WITH CHECK (
  public.has_role(auth.uid(), 'ADMIN') OR 
  public.has_role(auth.uid(), 'LP_FINANCE') OR
  public.has_role(auth.uid(), 'PRODUCER') OR
  public.has_role(auth.uid(), 'LEGAL') OR
  public.has_role(auth.uid(), 'SALES')
);

-- Storage policies for document processing bucket
CREATE POLICY "Authorized users can upload documents"
ON storage.objects FOR INSERT
WITH CHECK (
  bucket_id = 'document-processing' AND
  (public.has_role(auth.uid(), 'ADMIN') OR 
   public.has_role(auth.uid(), 'LP_FINANCE') OR
   public.has_role(auth.uid(), 'PRODUCER') OR
   public.has_role(auth.uid(), 'LEGAL') OR
   public.has_role(auth.uid(), 'SALES'))
);

CREATE POLICY "Authorized users can view documents"
ON storage.objects FOR SELECT
USING (
  bucket_id = 'document-processing' AND
  (public.has_role(auth.uid(), 'ADMIN') OR 
   public.has_role(auth.uid(), 'LP_FINANCE') OR
   public.has_role(auth.uid(), 'PRODUCER') OR
   public.has_role(auth.uid(), 'LEGAL') OR
   public.has_role(auth.uid(), 'SALES'))
);

CREATE POLICY "Authorized users can update documents"
ON storage.objects FOR UPDATE
USING (
  bucket_id = 'document-processing' AND
  (public.has_role(auth.uid(), 'ADMIN') OR 
   public.has_role(auth.uid(), 'LP_FINANCE') OR
   public.has_role(auth.uid(), 'PRODUCER') OR
   public.has_role(auth.uid(), 'LEGAL') OR
   public.has_role(auth.uid(), 'SALES'))
);

CREATE POLICY "Admins can delete documents"
ON storage.objects FOR DELETE
USING (
  bucket_id = 'document-processing' AND
  public.has_role(auth.uid(), 'ADMIN')
);