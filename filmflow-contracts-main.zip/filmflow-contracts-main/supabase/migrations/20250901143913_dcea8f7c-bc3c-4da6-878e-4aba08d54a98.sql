-- Create comprehensive projects table as central hub
CREATE TABLE public.projects (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  
  -- Basic project information
  project_code TEXT NOT NULL UNIQUE,
  project_title TEXT NOT NULL,
  original_title TEXT,
  project_status TEXT NOT NULL DEFAULT 'development' CHECK (project_status IN ('development', 'pre_production', 'production', 'post_production', 'completed', 'distribution', 'archived')),
  
  -- Project details
  genre TEXT[],
  format TEXT CHECK (format IN ('feature', 'series', 'short', 'documentary', 'animation', 'other')),
  runtime_minutes INTEGER,
  language TEXT,
  country_of_origin TEXT,
  production_year INTEGER,
  
  -- Key dates
  development_start DATE,
  production_start DATE,
  production_end DATE,
  post_production_end DATE,
  delivery_date DATE,
  release_date DATE,
  
  -- Budget information
  total_budget JSONB DEFAULT '{"amount": 0, "currency": "USD"}',
  financing_plan JSONB DEFAULT '[]', -- Array of financing sources
  
  -- Production details
  production_company TEXT,
  director TEXT,
  producer TEXT,
  executive_producer TEXT,
  writer TEXT,
  cast_lead TEXT[],
  
  -- Distribution and sales
  sales_agent TEXT,
  distributor_domestic TEXT,
  distributor_international TEXT,
  
  -- Contact information
  primary_contact JSONB DEFAULT '{}', -- {name, role, email, phone}
  additional_contacts JSONB DEFAULT '[]',
  
  -- Technical specs
  aspect_ratio TEXT,
  sound_format TEXT,
  color_format TEXT,
  shooting_format TEXT,
  delivery_format TEXT,
  
  -- Legal and compliance
  chain_of_title_complete BOOLEAN DEFAULT false,
  errors_omissions_insurance BOOLEAN DEFAULT false,
  completion_bond BOOLEAN DEFAULT false,
  
  -- Marketing materials
  key_art_locked BOOLEAN DEFAULT false,
  trailer_available BOOLEAN DEFAULT false,
  press_kit_complete BOOLEAN DEFAULT false,
  
  -- Metadata
  synopsis TEXT,
  logline TEXT,
  keywords TEXT[],
  notes TEXT,
  
  -- Project team access
  team_members JSONB DEFAULT '[]' -- Array of {user_id, role, permissions}
);

-- Enable RLS
ALTER TABLE public.projects ENABLE ROW LEVEL SECURITY;

-- Create RLS policies
CREATE POLICY "Users can view their own projects" 
ON public.projects 
FOR SELECT 
USING (auth.uid() = user_id);

CREATE POLICY "Users can insert their own projects" 
ON public.projects 
FOR INSERT 
WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update their own projects" 
ON public.projects 
FOR UPDATE 
USING (auth.uid() = user_id);

CREATE POLICY "Users can delete their own projects" 
ON public.projects 
FOR DELETE 
USING (auth.uid() = user_id);

CREATE POLICY "Service role can manage all projects" 
ON public.projects 
FOR ALL 
USING (true);

CREATE POLICY "Admins and authorized teams can manage all projects" 
ON public.projects 
FOR ALL 
USING (has_role(auth.uid(), 'ADMIN'::app_role) OR has_role(auth.uid(), 'LP_FINANCE'::app_role) OR has_role(auth.uid(), 'PRODUCER'::app_role) OR has_role(auth.uid(), 'LEGAL'::app_role) OR has_role(auth.uid(), 'SALES'::app_role));

-- Team members can view projects they're assigned to
CREATE POLICY "Team members can view assigned projects"
ON public.projects
FOR SELECT
USING (
  EXISTS (
    SELECT 1 
    FROM jsonb_array_elements(team_members) AS member
    WHERE (member->>'user_id')::uuid = auth.uid()
  )
);

-- Add indexes for better performance
CREATE INDEX idx_projects_user_id ON public.projects(user_id);
CREATE INDEX idx_projects_project_code ON public.projects(project_code);
CREATE INDEX idx_projects_status ON public.projects(project_status);
CREATE INDEX idx_projects_production_year ON public.projects(production_year);
CREATE INDEX idx_projects_genre ON public.projects USING GIN(genre);
CREATE INDEX idx_projects_team_members ON public.projects USING GIN(team_members);

-- Add trigger for updated_at
CREATE TRIGGER update_projects_updated_at
BEFORE UPDATE ON public.projects
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();

-- Update existing tables to properly reference projects
-- Add foreign key to doc_index
ALTER TABLE public.doc_index 
ADD CONSTRAINT fk_doc_index_project_code 
FOREIGN KEY (project_code) REFERENCES public.projects(project_code) 
ON DELETE SET NULL;

-- Update distribution_agreements to have proper project reference
ALTER TABLE public.distribution_agreements 
ADD CONSTRAINT fk_distribution_agreements_project_code 
FOREIGN KEY (project_code) REFERENCES public.projects(project_code) 
ON DELETE SET NULL;