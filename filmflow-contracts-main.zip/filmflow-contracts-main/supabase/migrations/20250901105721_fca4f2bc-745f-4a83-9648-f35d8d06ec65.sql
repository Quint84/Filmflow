-- Create distribution schema
CREATE SCHEMA IF NOT EXISTS dist;

-- Create party role enum
CREATE TYPE dist.party_role AS ENUM ('LICENSOR','DISTRIBUTOR_FINAL','LICENSEE_INTERMEDIARY');

-- Create main contracts table
CREATE TABLE dist.contracts(
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  project_code text NOT NULL REFERENCES core.projects(code) ON UPDATE CASCADE,
  document_title text, 
  document_date date,
  exclusivity boolean DEFAULT false,
  term_start_event text, 
  term_start_date date, 
  term_duration_years int, 
  term_end_date date,
  reporting_frequency text, 
  statement_due_days int,
  audit_allowed boolean DEFAULT false, 
  audit_periodicity_months int, 
  audit_lookback_years int,
  noa_required boolean DEFAULT false,
  payments_flow text CHECK (payments_flow IN ('DIRECT_TO_LICENSOR', 'THROUGH_INTERMEDIARY', 'COLLECTION_ACCOUNT')),
  notices_licensor text, 
  notices_distributor text, 
  notices_intermediary text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create parties table
CREATE TABLE dist.parties(
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  contract_id uuid NOT NULL REFERENCES dist.contracts(id) ON DELETE CASCADE,
  role dist.party_role NOT NULL, 
  name text NOT NULL, 
  vat_or_reg text, 
  address text, 
  contact text, 
  email text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create territories table
CREATE TABLE dist.territories(
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  contract_id uuid NOT NULL REFERENCES dist.contracts(id) ON DELETE CASCADE,
  territory text NOT NULL,
  created_at timestamptz DEFAULT now()
);

-- Create languages table
CREATE TABLE dist.languages(
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  contract_id uuid NOT NULL REFERENCES dist.contracts(id) ON DELETE CASCADE,
  lang text NOT NULL,
  created_at timestamptz DEFAULT now()
);

-- Create rights granted table
CREATE TABLE dist.rights_granted(
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  contract_id uuid NOT NULL REFERENCES dist.contracts(id) ON DELETE CASCADE,
  media text NOT NULL, -- Theatrical, Home Video, TVOD, EST, SVOD, AVOD, Pay TV, Free TV, Ancillary, Internet/Wireless
  created_at timestamptz DEFAULT now()
);

-- Create minimum guarantee table
CREATE TABLE dist.mg(
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  contract_id uuid NOT NULL REFERENCES dist.contracts(id) ON DELETE CASCADE,
  amount numeric(14,2) NOT NULL, 
  currency char(3) NOT NULL DEFAULT 'EUR',
  created_at timestamptz DEFAULT now()
);

-- Create MG schedule table
CREATE TABLE dist.mg_schedule(
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  contract_id uuid NOT NULL REFERENCES dist.contracts(id) ON DELETE CASCADE,
  trigger text NOT NULL, 
  due_days int, 
  percent numeric(6,3), 
  amount numeric(14,2),
  created_at timestamptz DEFAULT now()
);

-- Create fees table
CREATE TABLE dist.fees(
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  contract_id uuid NOT NULL REFERENCES dist.contracts(id) ON DELETE CASCADE,
  media text NOT NULL, 
  percent numeric(6,3) NOT NULL,
  created_at timestamptz DEFAULT now()
);

-- Create expense caps table
CREATE TABLE dist.expense_caps(
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  contract_id uuid NOT NULL REFERENCES dist.contracts(id) ON DELETE CASCADE,
  kind text NOT NULL, 
  amount numeric(14,2) NOT NULL, 
  currency char(3) NOT NULL DEFAULT 'EUR',
  created_at timestamptz DEFAULT now()
);

-- Create waterfall table
CREATE TABLE dist.waterfall(
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  contract_id uuid NOT NULL REFERENCES dist.contracts(id) ON DELETE CASCADE,
  tier int NOT NULL, 
  beneficiary text NOT NULL, 
  percent numeric(6,3) NOT NULL,
  created_at timestamptz DEFAULT now()
);

-- Create holdbacks table
CREATE TABLE dist.holdbacks(
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  contract_id uuid NOT NULL REFERENCES dist.contracts(id) ON DELETE CASCADE,
  media text NOT NULL, 
  duration_months int, 
  notes text,
  created_at timestamptz DEFAULT now()
);

-- Create collection account table
CREATE TABLE dist.collection_account(
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  contract_id uuid NOT NULL REFERENCES dist.contracts(id) ON DELETE CASCADE,
  enabled boolean DEFAULT false, 
  beneficiary text, 
  bank text, 
  iban text, 
  swift text, 
  currency char(3) DEFAULT 'EUR',
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create taxes table
CREATE TABLE dist.taxes(
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  contract_id uuid NOT NULL REFERENCES dist.contracts(id) ON DELETE CASCADE,
  withholding_percent numeric(5,2), 
  vat_applicable boolean DEFAULT false, 
  gross_up boolean DEFAULT false,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create termination table
CREATE TABLE dist.termination(
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  contract_id uuid NOT NULL REFERENCES dist.contracts(id) ON DELETE CASCADE,
  trigger text NOT NULL, 
  cure_days int, 
  effect text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Add constraints
ALTER TABLE dist.contracts 
  ADD CONSTRAINT contracts_term_duration_positive 
  CHECK (term_duration_years IS NULL OR term_duration_years > 0);

ALTER TABLE dist.contracts 
  ADD CONSTRAINT contracts_statement_due_positive 
  CHECK (statement_due_days IS NULL OR statement_due_days > 0);

ALTER TABLE dist.contracts 
  ADD CONSTRAINT contracts_audit_periodicity_positive 
  CHECK (audit_periodicity_months IS NULL OR audit_periodicity_months > 0);

ALTER TABLE dist.contracts 
  ADD CONSTRAINT contracts_audit_lookback_positive 
  CHECK (audit_lookback_years IS NULL OR audit_lookback_years > 0);

-- Add currency constraints
ALTER TABLE dist.mg 
  ADD CONSTRAINT mg_currency_length 
  CHECK (length(currency) = 3);

ALTER TABLE dist.expense_caps 
  ADD CONSTRAINT expense_caps_currency_length 
  CHECK (length(currency) = 3);

ALTER TABLE dist.collection_account 
  ADD CONSTRAINT collection_account_currency_length 
  CHECK (currency IS NULL OR length(currency) = 3);

-- Add percentage constraints
ALTER TABLE dist.mg_schedule 
  ADD CONSTRAINT mg_schedule_percent_range 
  CHECK (percent IS NULL OR (percent >= 0 AND percent <= 100));

ALTER TABLE dist.fees 
  ADD CONSTRAINT fees_percent_range 
  CHECK (percent >= 0 AND percent <= 100);

ALTER TABLE dist.waterfall 
  ADD CONSTRAINT waterfall_percent_range 
  CHECK (percent >= 0 AND percent <= 100);

ALTER TABLE dist.taxes 
  ADD CONSTRAINT taxes_withholding_range 
  CHECK (withholding_percent IS NULL OR (withholding_percent >= 0 AND withholding_percent <= 100));

-- Create trigger function for updating timestamps
CREATE OR REPLACE FUNCTION dist.touch_updated_at() 
RETURNS TRIGGER 
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = dist, public
AS $$
BEGIN 
  NEW.updated_at = now(); 
  RETURN NEW; 
END $$;

-- Create triggers for timestamp updates on tables with updated_at
CREATE TRIGGER trg_contracts_touch 
  BEFORE UPDATE ON dist.contracts
  FOR EACH ROW EXECUTE FUNCTION dist.touch_updated_at();

CREATE TRIGGER trg_parties_touch 
  BEFORE UPDATE ON dist.parties
  FOR EACH ROW EXECUTE FUNCTION dist.touch_updated_at();

CREATE TRIGGER trg_collection_account_touch 
  BEFORE UPDATE ON dist.collection_account
  FOR EACH ROW EXECUTE FUNCTION dist.touch_updated_at();

CREATE TRIGGER trg_taxes_touch 
  BEFORE UPDATE ON dist.taxes
  FOR EACH ROW EXECUTE FUNCTION dist.touch_updated_at();

CREATE TRIGGER trg_termination_touch 
  BEFORE UPDATE ON dist.termination
  FOR EACH ROW EXECUTE FUNCTION dist.touch_updated_at();

-- Enable RLS on all tables
ALTER TABLE dist.contracts ENABLE ROW LEVEL SECURITY;
ALTER TABLE dist.parties ENABLE ROW LEVEL SECURITY;
ALTER TABLE dist.territories ENABLE ROW LEVEL SECURITY;
ALTER TABLE dist.languages ENABLE ROW LEVEL SECURITY;
ALTER TABLE dist.rights_granted ENABLE ROW LEVEL SECURITY;
ALTER TABLE dist.mg ENABLE ROW LEVEL SECURITY;
ALTER TABLE dist.mg_schedule ENABLE ROW LEVEL SECURITY;
ALTER TABLE dist.fees ENABLE ROW LEVEL SECURITY;
ALTER TABLE dist.expense_caps ENABLE ROW LEVEL SECURITY;
ALTER TABLE dist.waterfall ENABLE ROW LEVEL SECURITY;
ALTER TABLE dist.holdbacks ENABLE ROW LEVEL SECURITY;
ALTER TABLE dist.collection_account ENABLE ROW LEVEL SECURITY;
ALTER TABLE dist.taxes ENABLE ROW LEVEL SECURITY;
ALTER TABLE dist.termination ENABLE ROW LEVEL SECURITY;

-- RLS Policies for contracts
CREATE POLICY "Admins and distribution teams can manage all contracts" 
ON dist.contracts 
FOR ALL 
USING (
  public.has_role(auth.uid(), 'ADMIN') OR 
  public.has_role(auth.uid(), 'SALES') OR
  public.has_role(auth.uid(), 'PRODUCER') OR
  public.has_role(auth.uid(), 'LEGAL')
);

CREATE POLICY "Project members can view distribution contracts for their projects" 
ON dist.contracts 
FOR SELECT 
USING (
  EXISTS (
    SELECT 1 FROM core.projects p
    JOIN core.project_members pm ON p.id = pm.project_id
    WHERE p.code = dist.contracts.project_code 
    AND pm.user_id = auth.uid()
  )
);

-- Create function to check distribution contract access
CREATE OR REPLACE FUNCTION dist.has_contract_access(_contract_id uuid)
RETURNS boolean
LANGUAGE sql
STABLE SECURITY DEFINER
SET search_path = dist, core, public
AS $$
  SELECT EXISTS (
    SELECT 1 FROM dist.contracts c
    WHERE c.id = _contract_id
    AND (
      public.has_role(auth.uid(), 'ADMIN') OR 
      public.has_role(auth.uid(), 'SALES') OR
      public.has_role(auth.uid(), 'PRODUCER') OR
      public.has_role(auth.uid(), 'LEGAL') OR
      EXISTS (
        SELECT 1 FROM core.projects p
        JOIN core.project_members pm ON p.id = pm.project_id
        WHERE p.code = c.project_code 
        AND pm.user_id = auth.uid()
      )
    )
  )
$$;

-- Apply the same pattern to all related tables
CREATE POLICY "Contract access for parties" ON dist.parties FOR ALL USING (dist.has_contract_access(contract_id));
CREATE POLICY "Contract access for territories" ON dist.territories FOR ALL USING (dist.has_contract_access(contract_id));
CREATE POLICY "Contract access for languages" ON dist.languages FOR ALL USING (dist.has_contract_access(contract_id));
CREATE POLICY "Contract access for rights_granted" ON dist.rights_granted FOR ALL USING (dist.has_contract_access(contract_id));
CREATE POLICY "Contract access for mg" ON dist.mg FOR ALL USING (dist.has_contract_access(contract_id));
CREATE POLICY "Contract access for mg_schedule" ON dist.mg_schedule FOR ALL USING (dist.has_contract_access(contract_id));
CREATE POLICY "Contract access for fees" ON dist.fees FOR ALL USING (dist.has_contract_access(contract_id));
CREATE POLICY "Contract access for expense_caps" ON dist.expense_caps FOR ALL USING (dist.has_contract_access(contract_id));
CREATE POLICY "Contract access for waterfall" ON dist.waterfall FOR ALL USING (dist.has_contract_access(contract_id));
CREATE POLICY "Contract access for holdbacks" ON dist.holdbacks FOR ALL USING (dist.has_contract_access(contract_id));
CREATE POLICY "Contract access for collection_account" ON dist.collection_account FOR ALL USING (dist.has_contract_access(contract_id));
CREATE POLICY "Contract access for taxes" ON dist.taxes FOR ALL USING (dist.has_contract_access(contract_id));
CREATE POLICY "Contract access for termination" ON dist.termination FOR ALL USING (dist.has_contract_access(contract_id));

-- Create indexes for better performance
CREATE INDEX idx_dist_contracts_project_code ON dist.contracts(project_code);
CREATE INDEX idx_dist_parties_contract_id ON dist.parties(contract_id);
CREATE INDEX idx_dist_parties_role ON dist.parties(role);
CREATE INDEX idx_dist_territories_contract_id ON dist.territories(contract_id);
CREATE INDEX idx_dist_languages_contract_id ON dist.languages(contract_id);
CREATE INDEX idx_dist_rights_granted_contract_id ON dist.rights_granted(contract_id);
CREATE INDEX idx_dist_mg_contract_id ON dist.mg(contract_id);
CREATE INDEX idx_dist_mg_schedule_contract_id ON dist.mg_schedule(contract_id);
CREATE INDEX idx_dist_fees_contract_id ON dist.fees(contract_id);
CREATE INDEX idx_dist_expense_caps_contract_id ON dist.expense_caps(contract_id);
CREATE INDEX idx_dist_waterfall_contract_id ON dist.waterfall(contract_id);
CREATE INDEX idx_dist_waterfall_tier ON dist.waterfall(tier);
CREATE INDEX idx_dist_holdbacks_contract_id ON dist.holdbacks(contract_id);
CREATE INDEX idx_dist_collection_account_contract_id ON dist.collection_account(contract_id);
CREATE INDEX idx_dist_taxes_contract_id ON dist.taxes(contract_id);
CREATE INDEX idx_dist_termination_contract_id ON dist.termination(contract_id);