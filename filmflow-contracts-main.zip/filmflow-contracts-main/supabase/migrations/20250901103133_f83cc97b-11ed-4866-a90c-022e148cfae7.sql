-- Create schemas for filmflow contracts system
CREATE SCHEMA IF NOT EXISTS core;
CREATE SCHEMA IF NOT EXISTS legal;
CREATE SCHEMA IF NOT EXISTS dist;
CREATE SCHEMA IF NOT EXISTS sales;
CREATE SCHEMA IF NOT EXISTS inv_tax;
CREATE SCHEMA IF NOT EXISTS sys;

-- Create enum for user roles
CREATE TYPE public.app_role AS ENUM (
  'ADMIN', 
  'PRODUCER', 
  'LP_FINANCE', 
  'LEGAL', 
  'SALES', 
  'HOD', 
  'INVESTOR_VIEW'
);

-- Create enum for document types
CREATE TYPE public.doc_type AS ENUM (
  'INV_TAX',
  'COPRODUCTION', 
  'TALENT',
  'DISTRIBUTION',
  'SALES_AGENT',
  'BANKING',
  'SUPPLIER',
  'LICENSE_DIRECT',
  'LICENSE_INTERMEDIARY'
);

-- Create enum for project status
CREATE TYPE public.project_status AS ENUM (
  'DEVELOPMENT',
  'PRE_PRODUCTION',
  'PRODUCTION', 
  'POST_PRODUCTION',
  'DISTRIBUTION',
  'COMPLETED',
  'CANCELLED'
);

-- User roles table
CREATE TABLE public.user_roles (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  role app_role NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
  UNIQUE (user_id, role)
);

-- User profiles table
CREATE TABLE public.profiles (
  id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  email TEXT NOT NULL,
  full_name TEXT,
  avatar_url TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT now()
);

-- Core projects table
CREATE TABLE core.projects (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  project_code TEXT UNIQUE NOT NULL,
  title TEXT NOT NULL,
  genre TEXT,
  status project_status DEFAULT 'DEVELOPMENT',
  budget_total DECIMAL(15,2),
  currency TEXT DEFAULT 'EUR',
  start_date DATE,
  end_date DATE,
  description TEXT,
  created_by UUID REFERENCES auth.users(id),
  created_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT now()
);

-- Project team members
CREATE TABLE core.project_members (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  project_id UUID REFERENCES core.projects(id) ON DELETE CASCADE,
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE,
  role TEXT NOT NULL,
  permissions JSONB DEFAULT '{}',
  created_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
  UNIQUE (project_id, user_id)
);

-- Documents storage metadata
CREATE TABLE core.documents (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  project_id UUID REFERENCES core.projects(id) ON DELETE CASCADE,
  filename TEXT NOT NULL,
  original_filename TEXT NOT NULL,
  storage_path TEXT NOT NULL UNIQUE,
  doc_type doc_type,
  doc_type_confidence FLOAT,
  file_size BIGINT,
  mime_type TEXT,
  sha256_hash TEXT,
  uploader_id UUID REFERENCES auth.users(id),
  status TEXT DEFAULT 'PENDING',
  extracted_data JSONB,
  validation_errors JSONB,
  processed_at TIMESTAMP WITH TIME ZONE,
  uploaded_at TIMESTAMP WITH TIME ZONE DEFAULT now()
);

-- Contract events timeline
CREATE TABLE core.contract_events (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  project_id UUID REFERENCES core.projects(id) ON DELETE CASCADE,
  document_id UUID REFERENCES core.documents(id) ON DELETE CASCADE,
  event_type TEXT NOT NULL,
  event_date DATE,
  description TEXT,
  amount DECIMAL(15,2),
  currency TEXT,
  metadata JSONB,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT now()
);

-- Enable RLS on all tables
ALTER TABLE public.user_roles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE core.projects ENABLE ROW LEVEL SECURITY;
ALTER TABLE core.project_members ENABLE ROW LEVEL SECURITY;
ALTER TABLE core.documents ENABLE ROW LEVEL SECURITY;
ALTER TABLE core.contract_events ENABLE ROW LEVEL SECURITY;

-- Security definer function to check user roles
CREATE OR REPLACE FUNCTION public.has_role(_user_id uuid, _role app_role)
RETURNS boolean
LANGUAGE sql
STABLE
SECURITY DEFINER
AS $$
  SELECT EXISTS (
    SELECT 1
    FROM public.user_roles
    WHERE user_id = _user_id
      AND role = _role
  )
$$;

-- Function to check if user has access to project
CREATE OR REPLACE FUNCTION public.has_project_access(_user_id uuid, _project_id uuid)
RETURNS boolean
LANGUAGE sql
STABLE
SECURITY DEFINER
AS $$
  SELECT EXISTS (
    SELECT 1
    FROM core.project_members
    WHERE user_id = _user_id
      AND project_id = _project_id
  ) OR public.has_role(_user_id, 'ADMIN')
     OR public.has_role(_user_id, 'PRODUCER')
     OR public.has_role(_user_id, 'LP_FINANCE')
     OR public.has_role(_user_id, 'LEGAL')
     OR public.has_role(_user_id, 'SALES')
$$;

-- RLS Policies for user_roles
CREATE POLICY "Users can view their own roles"
  ON public.user_roles FOR SELECT
  USING (auth.uid() = user_id);

CREATE POLICY "Admins can manage all roles"
  ON public.user_roles FOR ALL
  USING (public.has_role(auth.uid(), 'ADMIN'));

-- RLS Policies for profiles
CREATE POLICY "Users can view and update their own profile"
  ON public.profiles FOR ALL
  USING (auth.uid() = id);

CREATE POLICY "Authenticated users can view other profiles"
  ON public.profiles FOR SELECT
  TO authenticated
  USING (true);

-- RLS Policies for projects
CREATE POLICY "Users can view projects they have access to"
  ON core.projects FOR SELECT
  USING (public.has_project_access(auth.uid(), id));

CREATE POLICY "Admins and producers can create projects"
  ON core.projects FOR INSERT
  WITH CHECK (public.has_role(auth.uid(), 'ADMIN') OR public.has_role(auth.uid(), 'PRODUCER'));

CREATE POLICY "Admins and producers can update projects"
  ON core.projects FOR UPDATE
  USING (public.has_role(auth.uid(), 'ADMIN') OR public.has_role(auth.uid(), 'PRODUCER'));

-- RLS Policies for project members
CREATE POLICY "Users can view project members for accessible projects"
  ON core.project_members FOR SELECT
  USING (public.has_project_access(auth.uid(), project_id));

CREATE POLICY "Admins and producers can manage project members"
  ON core.project_members FOR ALL
  USING (public.has_role(auth.uid(), 'ADMIN') OR public.has_role(auth.uid(), 'PRODUCER'));

-- RLS Policies for documents
CREATE POLICY "Users can view documents for accessible projects"
  ON core.documents FOR SELECT
  USING (public.has_project_access(auth.uid(), project_id));

CREATE POLICY "Users can upload documents to accessible projects"
  ON core.documents FOR INSERT
  WITH CHECK (public.has_project_access(auth.uid(), project_id) AND auth.uid() = uploader_id);

-- RLS Policies for contract events
CREATE POLICY "Users can view contract events for accessible projects"
  ON core.contract_events FOR SELECT
  USING (public.has_project_access(auth.uid(), project_id));

-- Create storage bucket for documents
INSERT INTO storage.buckets (id, name, public) VALUES ('documents', 'documents', false);

-- Storage policies for documents
CREATE POLICY "Users can view documents for accessible projects"
  ON storage.objects FOR SELECT
  USING (bucket_id = 'documents' AND auth.uid() IS NOT NULL);

CREATE POLICY "Users can upload documents"
  ON storage.objects FOR INSERT
  WITH CHECK (bucket_id = 'documents' AND auth.uid() IS NOT NULL);

-- Function to handle new user registration
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER SET search_path = public
AS $$
BEGIN
  INSERT INTO public.profiles (id, email, full_name)
  VALUES (new.id, new.email, new.raw_user_meta_data ->> 'full_name');
  
  -- Assign default role
  INSERT INTO public.user_roles (user_id, role)
  VALUES (new.id, 'HOD');
  
  RETURN new;
END;
$$;

-- Trigger for new user registration
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE PROCEDURE public.handle_new_user();

-- Function to update timestamps
CREATE OR REPLACE FUNCTION public.update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Triggers for timestamp updates
CREATE TRIGGER update_profiles_updated_at
  BEFORE UPDATE ON public.profiles
  FOR EACH ROW
  EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_projects_updated_at
  BEFORE UPDATE ON core.projects
  FOR EACH ROW
  EXECUTE FUNCTION public.update_updated_at_column();