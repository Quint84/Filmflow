-- Fix function search path security issue by setting search_path for functions
-- Update the core.touch_updated_at function to be secure
CREATE OR REPLACE FUNCTION core.touch_updated_at() 
RETURNS TRIGGER 
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = core, public
AS $$
BEGIN 
  NEW.updated_at = now(); 
  RETURN NEW; 
END $$;