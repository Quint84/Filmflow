-- Create missing task_queue table
CREATE TABLE IF NOT EXISTS public.task_queue (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  task_type TEXT NOT NULL,
  doc_id UUID NOT NULL REFERENCES public.doc_index(id) ON DELETE CASCADE,
  payload JSONB,
  status TEXT NOT NULL DEFAULT 'pending',
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  completed_at TIMESTAMP WITH TIME ZONE,
  error_message TEXT
);

-- Create missing processing_exceptions table
CREATE TABLE IF NOT EXISTS public.processing_exceptions (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  doc_id UUID NOT NULL REFERENCES public.doc_index(id) ON DELETE CASCADE,
  exception_type TEXT NOT NULL,
  error_message TEXT,
  payload JSONB,
  status TEXT NOT NULL DEFAULT 'pending',
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  resolved_at TIMESTAMP WITH TIME ZONE
);

-- Enable RLS
ALTER TABLE public.task_queue ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.processing_exceptions ENABLE ROW LEVEL SECURITY;

-- Create policies for task_queue
CREATE POLICY "Service role can manage task_queue" ON public.task_queue
FOR ALL USING (true);

CREATE POLICY "Users can view their own document tasks" ON public.task_queue
FOR SELECT USING (
  EXISTS (
    SELECT 1 FROM public.doc_index 
    WHERE doc_index.id = task_queue.doc_id 
    AND doc_index.user_id = auth.uid()
  )
);

-- Create policies for processing_exceptions
CREATE POLICY "Service role can manage processing_exceptions" ON public.processing_exceptions
FOR ALL USING (true);

CREATE POLICY "Users can view their own document exceptions" ON public.processing_exceptions
FOR SELECT USING (
  EXISTS (
    SELECT 1 FROM public.doc_index 
    WHERE doc_index.id = processing_exceptions.doc_id 
    AND doc_index.user_id = auth.uid()
  )
);

-- Add trigger for updated_at
CREATE TRIGGER update_task_queue_updated_at
BEFORE UPDATE ON public.task_queue
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_processing_exceptions_updated_at
BEFORE UPDATE ON public.processing_exceptions
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();