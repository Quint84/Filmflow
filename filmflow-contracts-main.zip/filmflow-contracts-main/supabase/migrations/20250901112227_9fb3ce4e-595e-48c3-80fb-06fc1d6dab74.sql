-- Enable vector extension for embeddings
CREATE EXTENSION IF NOT EXISTS vector;

-- Create sys schema if it doesn't exist
CREATE SCHEMA IF NOT EXISTS sys;

-- Create document index table for semantic search
CREATE TABLE sys.doc_index(
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  project_code text REFERENCES core.projects(code) ON UPDATE CASCADE,
  doc_type text,
  file_hash char(64),
  file_url text,
  title text,
  created_at timestamptz DEFAULT now(),
  embedding vector(1536)
);

-- Create vector similarity search index
CREATE INDEX idx_sys_doc_index_embedding_ivfflat 
ON sys.doc_index USING ivfflat (embedding vector_cosine_ops);

-- Create additional indexes for better query performance
CREATE INDEX idx_sys_doc_index_project_code ON sys.doc_index(project_code);
CREATE INDEX idx_sys_doc_index_doc_type ON sys.doc_index(doc_type);
CREATE INDEX idx_sys_doc_index_file_hash ON sys.doc_index(file_hash);
CREATE INDEX idx_sys_doc_index_created_at ON sys.doc_index(created_at);

-- Enable RLS on the table
ALTER TABLE sys.doc_index ENABLE ROW LEVEL SECURITY;

-- RLS Policies for document index
CREATE POLICY "Admins and authorized teams can manage all document indexes" 
ON sys.doc_index 
FOR ALL 
USING (
  public.has_role(auth.uid(), 'ADMIN') OR 
  public.has_role(auth.uid(), 'LP_FINANCE') OR
  public.has_role(auth.uid(), 'PRODUCER') OR
  public.has_role(auth.uid(), 'LEGAL') OR
  public.has_role(auth.uid(), 'SALES')
);

CREATE POLICY "Project members can view document indexes for their projects" 
ON sys.doc_index 
FOR SELECT 
USING (
  EXISTS (
    SELECT 1 FROM core.projects p
    JOIN core.project_members pm ON p.id = pm.project_id
    WHERE p.code = sys.doc_index.project_code 
    AND pm.user_id = auth.uid()
  )
);