-- Create sales schema
CREATE SCHEMA IF NOT EXISTS sales;

-- Create MLA table
CREATE TABLE sales.mla(
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  project_code text NOT NULL REFERENCES core.projects(code) ON UPDATE CASCADE,
  document_title text, 
  document_date date,
  licensor_name text, 
  licensee_intermediary_name text,
  governing_law text, 
  jurisdiction text,
  accounting_frequency text, 
  audit_rights text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create MLA split schedule table
CREATE TABLE sales.mla_split_schedule(
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  mla_id uuid NOT NULL REFERENCES sales.mla(id) ON DELETE CASCADE,
  gross_band text NOT NULL, 
  percent_to_licensor numeric(6,3) NOT NULL,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create territory exhibit table
CREATE TABLE sales.territory_exhibit(
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  mla_id uuid NOT NULL REFERENCES sales.mla(id) ON DELETE CASCADE,
  exhibit_title text, 
  exhibit_date date,
  territory jsonb, 
  languages_authorized text,
  rights_granted jsonb, 
  term_start_event text, 
  term_years int,
  essential_elements jsonb, 
  production_deadlines jsonb,
  mg_amount numeric(14,2), 
  mg_currency char(3) DEFAULT 'EUR',
  bank_instructions jsonb,
  final_distributor jsonb, -- null si aún no designado
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Add constraints for data validation
ALTER TABLE sales.mla_split_schedule 
  ADD CONSTRAINT mla_split_percent_range 
  CHECK (percent_to_licensor >= 0 AND percent_to_licensor <= 100);

ALTER TABLE sales.territory_exhibit 
  ADD CONSTRAINT territory_exhibit_term_years_positive 
  CHECK (term_years IS NULL OR term_years > 0);

ALTER TABLE sales.territory_exhibit 
  ADD CONSTRAINT territory_exhibit_mg_currency_length 
  CHECK (mg_currency IS NULL OR length(mg_currency) = 3);

ALTER TABLE sales.territory_exhibit 
  ADD CONSTRAINT territory_exhibit_mg_amount_positive 
  CHECK (mg_amount IS NULL OR mg_amount >= 0);

-- Create trigger function for updating timestamps
CREATE OR REPLACE FUNCTION sales.touch_updated_at() 
RETURNS TRIGGER 
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = sales, public
AS $$
BEGIN 
  NEW.updated_at = now(); 
  RETURN NEW; 
END $$;

-- Create triggers for timestamp updates
CREATE TRIGGER trg_mla_touch 
  BEFORE UPDATE ON sales.mla
  FOR EACH ROW EXECUTE FUNCTION sales.touch_updated_at();

CREATE TRIGGER trg_mla_split_schedule_touch 
  BEFORE UPDATE ON sales.mla_split_schedule
  FOR EACH ROW EXECUTE FUNCTION sales.touch_updated_at();

CREATE TRIGGER trg_territory_exhibit_touch 
  BEFORE UPDATE ON sales.territory_exhibit
  FOR EACH ROW EXECUTE FUNCTION sales.touch_updated_at();

-- Enable RLS on all tables
ALTER TABLE sales.mla ENABLE ROW LEVEL SECURITY;
ALTER TABLE sales.mla_split_schedule ENABLE ROW LEVEL SECURITY;
ALTER TABLE sales.territory_exhibit ENABLE ROW LEVEL SECURITY;

-- RLS Policies for MLA
CREATE POLICY "Admins and sales teams can manage all MLAs" 
ON sales.mla 
FOR ALL 
USING (
  public.has_role(auth.uid(), 'ADMIN') OR 
  public.has_role(auth.uid(), 'SALES') OR
  public.has_role(auth.uid(), 'PRODUCER') OR
  public.has_role(auth.uid(), 'LEGAL')
);

CREATE POLICY "Project members can view MLAs for their projects" 
ON sales.mla 
FOR SELECT 
USING (
  EXISTS (
    SELECT 1 FROM core.projects p
    JOIN core.project_members pm ON p.id = pm.project_id
    WHERE p.code = sales.mla.project_code 
    AND pm.user_id = auth.uid()
  )
);

-- Create function to check MLA access
CREATE OR REPLACE FUNCTION sales.has_mla_access(_mla_id uuid)
RETURNS boolean
LANGUAGE sql
STABLE SECURITY DEFINER
SET search_path = sales, core, public
AS $$
  SELECT EXISTS (
    SELECT 1 FROM sales.mla m
    WHERE m.id = _mla_id
    AND (
      public.has_role(auth.uid(), 'ADMIN') OR 
      public.has_role(auth.uid(), 'SALES') OR
      public.has_role(auth.uid(), 'PRODUCER') OR
      public.has_role(auth.uid(), 'LEGAL') OR
      EXISTS (
        SELECT 1 FROM core.projects p
        JOIN core.project_members pm ON p.id = pm.project_id
        WHERE p.code = m.project_code 
        AND pm.user_id = auth.uid()
      )
    )
  )
$$;

-- Apply the same pattern to related tables
CREATE POLICY "MLA access for split schedule" 
ON sales.mla_split_schedule 
FOR ALL 
USING (sales.has_mla_access(mla_id));

CREATE POLICY "MLA access for territory exhibit" 
ON sales.territory_exhibit 
FOR ALL 
USING (sales.has_mla_access(mla_id));

-- Create indexes for better performance
CREATE INDEX idx_sales_mla_project_code ON sales.mla(project_code);
CREATE INDEX idx_sales_mla_document_date ON sales.mla(document_date);
CREATE INDEX idx_sales_mla_split_schedule_mla_id ON sales.mla_split_schedule(mla_id);
CREATE INDEX idx_sales_territory_exhibit_mla_id ON sales.territory_exhibit(mla_id);
CREATE INDEX idx_sales_territory_exhibit_date ON sales.territory_exhibit(exhibit_date);

-- Create GIN indexes for JSONB columns for better query performance
CREATE INDEX idx_sales_territory_exhibit_territory_gin ON sales.territory_exhibit USING GIN(territory);
CREATE INDEX idx_sales_territory_exhibit_rights_granted_gin ON sales.territory_exhibit USING GIN(rights_granted);
CREATE INDEX idx_sales_territory_exhibit_essential_elements_gin ON sales.territory_exhibit USING GIN(essential_elements);
CREATE INDEX idx_sales_territory_exhibit_production_deadlines_gin ON sales.territory_exhibit USING GIN(production_deadlines);
CREATE INDEX idx_sales_territory_exhibit_bank_instructions_gin ON sales.territory_exhibit USING GIN(bank_instructions);
CREATE INDEX idx_sales_territory_exhibit_final_distributor_gin ON sales.territory_exhibit USING GIN(final_distributor);