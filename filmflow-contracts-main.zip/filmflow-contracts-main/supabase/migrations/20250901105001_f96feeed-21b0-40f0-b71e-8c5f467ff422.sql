-- Create legal schema
CREATE SCHEMA IF NOT EXISTS legal;

-- Create contract type enum
CREATE TYPE legal.contract_type AS ENUM (
  'INV_TAX','COPRO','TALENT','CREW','DIST','SALES_AGENCY','BANK','VENDOR','SALE_OTHER','AMENDMENT'
);

-- Create contracts table
CREATE TABLE legal.contracts(
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  project_code text NOT NULL REFERENCES core.projects(code) ON UPDATE CASCADE,
  type legal.contract_type NOT NULL,
  document_title text, 
  document_date date,
  governing_law text, 
  jurisdiction text,
  status text DEFAULT 'DRAFT', -- DRAFT|SIGNED|TERMINATED
  currency char(3) DEFAULT 'EUR',
  total_value numeric(14,2),
  file_url text, 
  file_hash char(64),
  version int DEFAULT 1, 
  parent_id uuid REFERENCES legal.contracts(id),
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create parties table
CREATE TABLE legal.parties(
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  contract_id uuid NOT NULL REFERENCES legal.contracts(id) ON DELETE CASCADE,
  role text NOT NULL, 
  name text NOT NULL, 
  country text, 
  tax_id text, 
  address text, 
  email text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create obligations table
CREATE TABLE legal.obligations(
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  contract_id uuid NOT NULL REFERENCES legal.contracts(id) ON DELETE CASCADE,
  clause text NOT NULL, 
  value text, 
  frequency text, 
  penalty text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create events table
CREATE TABLE legal.events(
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  contract_id uuid NOT NULL REFERENCES legal.contracts(id) ON DELETE CASCADE,
  occurred_at timestamptz DEFAULT now(),
  kind text NOT NULL, 
  message text, 
  confidence numeric(4,3),
  created_at timestamptz DEFAULT now()
);

-- Add constraints for status and currency
ALTER TABLE legal.contracts 
  ADD CONSTRAINT contracts_status_check 
  CHECK (status IN ('DRAFT', 'SIGNED', 'TERMINATED'));

ALTER TABLE legal.contracts 
  ADD CONSTRAINT contracts_currency_length 
  CHECK (length(currency) = 3);

ALTER TABLE legal.contracts 
  ADD CONSTRAINT contracts_confidence_range 
  CHECK (version >= 1);

ALTER TABLE legal.events 
  ADD CONSTRAINT events_confidence_range 
  CHECK (confidence >= 0 AND confidence <= 1);

-- Add file hash constraint (64 chars for SHA-256)
ALTER TABLE legal.contracts 
  ADD CONSTRAINT contracts_file_hash_length 
  CHECK (file_hash IS NULL OR length(file_hash) = 64);

-- Create trigger function for updating timestamps
CREATE OR REPLACE FUNCTION legal.touch_updated_at() 
RETURNS TRIGGER 
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = legal, public
AS $$
BEGIN 
  NEW.updated_at = now(); 
  RETURN NEW; 
END $$;

-- Create triggers for timestamp updates
CREATE TRIGGER trg_contracts_touch 
  BEFORE UPDATE ON legal.contracts
  FOR EACH ROW EXECUTE FUNCTION legal.touch_updated_at();

CREATE TRIGGER trg_parties_touch 
  BEFORE UPDATE ON legal.parties
  FOR EACH ROW EXECUTE FUNCTION legal.touch_updated_at();

CREATE TRIGGER trg_obligations_touch 
  BEFORE UPDATE ON legal.obligations
  FOR EACH ROW EXECUTE FUNCTION legal.touch_updated_at();

-- Enable RLS on all tables
ALTER TABLE legal.contracts ENABLE ROW LEVEL SECURITY;
ALTER TABLE legal.parties ENABLE ROW LEVEL SECURITY;
ALTER TABLE legal.obligations ENABLE ROW LEVEL SECURITY;
ALTER TABLE legal.events ENABLE ROW LEVEL SECURITY;

-- RLS Policies for contracts
CREATE POLICY "Admins and legal can manage all contracts" 
ON legal.contracts 
FOR ALL 
USING (
  public.has_role(auth.uid(), 'ADMIN') OR 
  public.has_role(auth.uid(), 'LEGAL') OR
  public.has_role(auth.uid(), 'PRODUCER')
);

CREATE POLICY "Project members can view contracts for their projects" 
ON legal.contracts 
FOR SELECT 
USING (
  EXISTS (
    SELECT 1 FROM core.projects p
    JOIN core.project_members pm ON p.id = pm.project_id
    WHERE p.code = legal.contracts.project_code 
    AND pm.user_id = auth.uid()
  )
);

-- RLS Policies for parties
CREATE POLICY "Contract access for parties" 
ON legal.parties 
FOR ALL 
USING (
  EXISTS (
    SELECT 1 FROM legal.contracts c
    WHERE c.id = legal.parties.contract_id
    AND (
      public.has_role(auth.uid(), 'ADMIN') OR 
      public.has_role(auth.uid(), 'LEGAL') OR
      public.has_role(auth.uid(), 'PRODUCER') OR
      EXISTS (
        SELECT 1 FROM core.projects p
        JOIN core.project_members pm ON p.id = pm.project_id
        WHERE p.code = c.project_code 
        AND pm.user_id = auth.uid()
      )
    )
  )
);

-- RLS Policies for obligations
CREATE POLICY "Contract access for obligations" 
ON legal.obligations 
FOR ALL 
USING (
  EXISTS (
    SELECT 1 FROM legal.contracts c
    WHERE c.id = legal.obligations.contract_id
    AND (
      public.has_role(auth.uid(), 'ADMIN') OR 
      public.has_role(auth.uid(), 'LEGAL') OR
      public.has_role(auth.uid(), 'PRODUCER') OR
      EXISTS (
        SELECT 1 FROM core.projects p
        JOIN core.project_members pm ON p.id = pm.project_id
        WHERE p.code = c.project_code 
        AND pm.user_id = auth.uid()
      )
    )
  )
);

-- RLS Policies for events
CREATE POLICY "Contract access for events" 
ON legal.events 
FOR ALL 
USING (
  EXISTS (
    SELECT 1 FROM legal.contracts c
    WHERE c.id = legal.events.contract_id
    AND (
      public.has_role(auth.uid(), 'ADMIN') OR 
      public.has_role(auth.uid(), 'LEGAL') OR
      public.has_role(auth.uid(), 'PRODUCER') OR
      EXISTS (
        SELECT 1 FROM core.projects p
        JOIN core.project_members pm ON p.id = pm.project_id
        WHERE p.code = c.project_code 
        AND pm.user_id = auth.uid()
      )
    )
  )
);

-- Create indexes for better performance
CREATE INDEX idx_contracts_project_code ON legal.contracts(project_code);
CREATE INDEX idx_contracts_type ON legal.contracts(type);
CREATE INDEX idx_contracts_status ON legal.contracts(status);
CREATE INDEX idx_contracts_parent_id ON legal.contracts(parent_id);
CREATE INDEX idx_parties_contract_id ON legal.parties(contract_id);
CREATE INDEX idx_parties_role ON legal.parties(role);
CREATE INDEX idx_obligations_contract_id ON legal.obligations(contract_id);
CREATE INDEX idx_events_contract_id ON legal.events(contract_id);
CREATE INDEX idx_events_kind ON legal.events(kind);
CREATE INDEX idx_events_occurred_at ON legal.events(occurred_at);