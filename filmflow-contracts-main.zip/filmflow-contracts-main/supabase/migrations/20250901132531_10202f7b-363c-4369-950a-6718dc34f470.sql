-- Remove the current policy and create a more secure one
DROP POLICY IF EXISTS "Users can view basic profile info of others" ON public.profiles;

-- Create a secure policy that only allows users to view their own profile
-- This completely prevents access to other users' data including emails
CREATE POLICY "Users can only view their own profile" ON public.profiles
FOR SELECT USING (auth.uid() = id);

-- If the application needs to display other users' names (e.g., for collaboration features),
-- create a separate view or use application-level logic with specific column selection