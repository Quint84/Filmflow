-- Create core schema
CREATE SCHEMA IF NOT EXISTS core;

-- Create project status enum
CREATE TYPE core.project_status AS ENUM ('DEV','PREP','ROD','POST','ENTREGADA','CATALOGO');

-- Create milestone kind enum
CREATE TYPE core.milestone_kind AS ENUM (
  'GREENLIGHT','PP_START','SHOOT_START','SHOOT_END','LOCK_CUT','DELIVERY_ESSENTIAL',
  'DELIVERY_COMPLETE','CERT_CULTURAL','CERT_NACIONALIDAD','CERT_36X','NOA',
  'FEST_PREMIERE','THEATRICAL_RELEASE','SVOD_START','TV_FREE_START','OTHER'
);

-- Create projects table
CREATE TABLE core.projects(
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  code text NOT NULL UNIQUE CHECK (code ~ '^[A-Z0-9_]+$'),
  title text NOT NULL,
  original_language text,
  country_of_origin text DEFAULT 'ES',
  status core.project_status NOT NULL DEFAULT 'DEV',
  regime text,                -- '36.1','36.2','39.7','MIXTO'
  currency char(3) NOT NULL DEFAULT 'EUR',
  budget_estimated numeric(14,2),
  budget_final numeric(14,2),
  eligible_base_est numeric(14,2),
  eligible_base_final numeric(14,2),
  incentive_est numeric(14,2),
  incentive_final numeric(14,2),
  greenlight_date date,
  pp_start date, 
  pp_end date,
  shoot_start date, 
  shoot_end date,
  post_start date, 
  post_end date,
  lock_cut_date date,
  delivery_essential_date date,
  delivery_complete_date date,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create project milestones table
CREATE TABLE core.project_milestones(
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  project_id uuid NOT NULL REFERENCES core.projects(id) ON DELETE CASCADE,
  kind core.milestone_kind NOT NULL,
  planned_date date,
  actual_date date,
  is_blocking boolean DEFAULT false,
  notes text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create project parties table
CREATE TABLE core.project_parties(
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  project_id uuid NOT NULL REFERENCES core.projects(id) ON DELETE CASCADE,
  role text NOT NULL, 
  name text NOT NULL,
  vat_or_reg text, 
  email text, 
  phone text, 
  address text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  UNIQUE(project_id, role, name)
);

-- Create release dates table
CREATE TABLE core.release_dates(
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  project_id uuid NOT NULL REFERENCES core.projects(id) ON DELETE CASCADE,
  territory text NOT NULL,  -- ISO o libre
  media text NOT NULL,      -- THEATRICAL, SVOD, TV_FREE, etc.
  planned_date date, 
  actual_date date,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  UNIQUE(project_id, territory, media)
);

-- Create project members table for access control
CREATE TABLE core.project_members(
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  project_id uuid NOT NULL REFERENCES core.projects(id) ON DELETE CASCADE,
  user_id uuid NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  role text NOT NULL DEFAULT 'MEMBER', -- MANAGER, MEMBER, VIEWER
  created_at timestamptz DEFAULT now(),
  UNIQUE(project_id, user_id)
);

-- Create trigger function for updating timestamps
CREATE OR REPLACE FUNCTION core.touch_updated_at() 
RETURNS TRIGGER AS $$
BEGIN 
  NEW.updated_at = now(); 
  RETURN NEW; 
END $$ LANGUAGE plpgsql;

-- Create triggers for all tables
CREATE TRIGGER trg_projects_touch 
  BEFORE UPDATE ON core.projects
  FOR EACH ROW EXECUTE FUNCTION core.touch_updated_at();

CREATE TRIGGER trg_project_milestones_touch 
  BEFORE UPDATE ON core.project_milestones
  FOR EACH ROW EXECUTE FUNCTION core.touch_updated_at();

CREATE TRIGGER trg_project_parties_touch 
  BEFORE UPDATE ON core.project_parties
  FOR EACH ROW EXECUTE FUNCTION core.touch_updated_at();

CREATE TRIGGER trg_release_dates_touch 
  BEFORE UPDATE ON core.release_dates
  FOR EACH ROW EXECUTE FUNCTION core.touch_updated_at();

CREATE TRIGGER trg_project_members_touch 
  BEFORE UPDATE ON core.project_members
  FOR EACH ROW EXECUTE FUNCTION core.touch_updated_at();

-- Enable RLS on all tables
ALTER TABLE core.projects ENABLE ROW LEVEL SECURITY;
ALTER TABLE core.project_milestones ENABLE ROW LEVEL SECURITY;
ALTER TABLE core.project_parties ENABLE ROW LEVEL SECURITY;
ALTER TABLE core.release_dates ENABLE ROW LEVEL SECURITY;
ALTER TABLE core.project_members ENABLE ROW LEVEL SECURITY;

-- RLS Policies for projects
CREATE POLICY "Admins and producers can manage all projects" 
ON core.projects 
FOR ALL 
USING (
  public.has_role(auth.uid(), 'ADMIN') OR 
  public.has_role(auth.uid(), 'PRODUCER') OR
  public.has_role(auth.uid(), 'LP_FINANCE') OR
  public.has_role(auth.uid(), 'LEGAL') OR
  public.has_role(auth.uid(), 'SALES')
);

CREATE POLICY "Project members can view their projects" 
ON core.projects 
FOR SELECT 
USING (
  EXISTS (
    SELECT 1 FROM core.project_members 
    WHERE project_id = core.projects.id 
    AND user_id = auth.uid()
  )
);

-- RLS Policies for project milestones
CREATE POLICY "Project access for milestones" 
ON core.project_milestones 
FOR ALL 
USING (public.has_project_access(auth.uid(), project_id));

-- RLS Policies for project parties
CREATE POLICY "Project access for parties" 
ON core.project_parties 
FOR ALL 
USING (public.has_project_access(auth.uid(), project_id));

-- RLS Policies for release dates
CREATE POLICY "Project access for release dates" 
ON core.release_dates 
FOR ALL 
USING (public.has_project_access(auth.uid(), project_id));

-- RLS Policies for project members
CREATE POLICY "Admins and producers can manage project members" 
ON core.project_members 
FOR ALL 
USING (
  public.has_role(auth.uid(), 'ADMIN') OR 
  public.has_role(auth.uid(), 'PRODUCER')
);

CREATE POLICY "Users can view project members for their projects" 
ON core.project_members 
FOR SELECT 
USING (public.has_project_access(auth.uid(), project_id));

-- Create indexes for better performance
CREATE INDEX idx_projects_code ON core.projects(code);
CREATE INDEX idx_projects_status ON core.projects(status);
CREATE INDEX idx_project_milestones_project_id ON core.project_milestones(project_id);
CREATE INDEX idx_project_milestones_kind ON core.project_milestones(kind);
CREATE INDEX idx_project_parties_project_id ON core.project_parties(project_id);
CREATE INDEX idx_release_dates_project_id ON core.release_dates(project_id);
CREATE INDEX idx_project_members_project_id ON core.project_members(project_id);
CREATE INDEX idx_project_members_user_id ON core.project_members(user_id);