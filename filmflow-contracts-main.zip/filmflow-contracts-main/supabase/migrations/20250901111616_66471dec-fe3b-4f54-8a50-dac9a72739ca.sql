-- Create investment/tax schema
CREATE SCHEMA IF NOT EXISTS inv_tax;

-- Create investment/tax contracts table
CREATE TABLE inv_tax.contracts(
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  project_code text NOT NULL REFERENCES core.projects(code) ON UPDATE CASCADE,
  document_title text, 
  document_date date,
  producer_name text, 
  producer_tax_id text, 
  producer_representative text, 
  domicile_required_canary boolean DEFAULT false,
  financier_name text, 
  financier_tax_id text,
  contribution_amount_eur numeric(14,2),
  transfer_window_note text,
  bank_account_iban text,
  other_financiers_amount_eur numeric(14,2),
  producer_contribution_amount_eur numeric(14,2),
  subsidies_expected_eur numeric(14,2),
  minimum_total_cost_eur numeric(14,2),
  estimated_total_deduction_2025_eur numeric(14,2),
  articles text, 
  deduction_multiplier numeric(6,3),
  deduction_amount_eur numeric(14,2),
  producer_renounces_deduction_eur numeric(14,2),
  interest_or_other_compensation boolean DEFAULT false,
  expansion_option_if_higher_final_deduction boolean DEFAULT false,
  docs_to_financier_by date, 
  request_certificates_by date, 
  deposit_archive_copy_by date, 
  communication_39_7_by date,
  required_docs jsonb,
  signatures jsonb,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Add constraints for data validation
ALTER TABLE inv_tax.contracts 
  ADD CONSTRAINT contracts_contribution_amount_positive 
  CHECK (contribution_amount_eur IS NULL OR contribution_amount_eur >= 0);

ALTER TABLE inv_tax.contracts 
  ADD CONSTRAINT contracts_other_financiers_amount_positive 
  CHECK (other_financiers_amount_eur IS NULL OR other_financiers_amount_eur >= 0);

ALTER TABLE inv_tax.contracts 
  ADD CONSTRAINT contracts_producer_contribution_positive 
  CHECK (producer_contribution_amount_eur IS NULL OR producer_contribution_amount_eur >= 0);

ALTER TABLE inv_tax.contracts 
  ADD CONSTRAINT contracts_subsidies_expected_positive 
  CHECK (subsidies_expected_eur IS NULL OR subsidies_expected_eur >= 0);

ALTER TABLE inv_tax.contracts 
  ADD CONSTRAINT contracts_minimum_total_cost_positive 
  CHECK (minimum_total_cost_eur IS NULL OR minimum_total_cost_eur >= 0);

ALTER TABLE inv_tax.contracts 
  ADD CONSTRAINT contracts_estimated_deduction_positive 
  CHECK (estimated_total_deduction_2025_eur IS NULL OR estimated_total_deduction_2025_eur >= 0);

ALTER TABLE inv_tax.contracts 
  ADD CONSTRAINT contracts_deduction_multiplier_positive 
  CHECK (deduction_multiplier IS NULL OR deduction_multiplier >= 0);

ALTER TABLE inv_tax.contracts 
  ADD CONSTRAINT contracts_deduction_amount_positive 
  CHECK (deduction_amount_eur IS NULL OR deduction_amount_eur >= 0);

ALTER TABLE inv_tax.contracts 
  ADD CONSTRAINT contracts_producer_renounces_positive 
  CHECK (producer_renounces_deduction_eur IS NULL OR producer_renounces_deduction_eur >= 0);

-- Add IBAN format validation (basic check for length and structure)
ALTER TABLE inv_tax.contracts 
  ADD CONSTRAINT contracts_iban_format 
  CHECK (bank_account_iban IS NULL OR (length(bank_account_iban) >= 15 AND length(bank_account_iban) <= 34));

-- Create trigger function for updating timestamps
CREATE OR REPLACE FUNCTION inv_tax.touch_updated_at() 
RETURNS TRIGGER 
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = inv_tax, public
AS $$
BEGIN 
  NEW.updated_at = now(); 
  RETURN NEW; 
END $$;

-- Create trigger for timestamp updates
CREATE TRIGGER trg_contracts_touch 
  BEFORE UPDATE ON inv_tax.contracts
  FOR EACH ROW EXECUTE FUNCTION inv_tax.touch_updated_at();

-- Enable RLS on the table
ALTER TABLE inv_tax.contracts ENABLE ROW LEVEL SECURITY;

-- RLS Policies for contracts
CREATE POLICY "Admins and finance teams can manage all inv_tax contracts" 
ON inv_tax.contracts 
FOR ALL 
USING (
  public.has_role(auth.uid(), 'ADMIN') OR 
  public.has_role(auth.uid(), 'LP_FINANCE') OR
  public.has_role(auth.uid(), 'PRODUCER') OR
  public.has_role(auth.uid(), 'LEGAL')
);

CREATE POLICY "Project members can view inv_tax contracts for their projects" 
ON inv_tax.contracts 
FOR SELECT 
USING (
  EXISTS (
    SELECT 1 FROM core.projects p
    JOIN core.project_members pm ON p.id = pm.project_id
    WHERE p.code = inv_tax.contracts.project_code 
    AND pm.user_id = auth.uid()
  )
);

-- Create indexes for better performance
CREATE INDEX idx_inv_tax_contracts_project_code ON inv_tax.contracts(project_code);
CREATE INDEX idx_inv_tax_contracts_document_date ON inv_tax.contracts(document_date);
CREATE INDEX idx_inv_tax_contracts_producer_name ON inv_tax.contracts(producer_name);
CREATE INDEX idx_inv_tax_contracts_financier_name ON inv_tax.contracts(financier_name);
CREATE INDEX idx_inv_tax_contracts_producer_tax_id ON inv_tax.contracts(producer_tax_id);
CREATE INDEX idx_inv_tax_contracts_financier_tax_id ON inv_tax.contracts(financier_tax_id);

-- Create indexes for deadline tracking
CREATE INDEX idx_inv_tax_contracts_docs_to_financier_by ON inv_tax.contracts(docs_to_financier_by);
CREATE INDEX idx_inv_tax_contracts_request_certificates_by ON inv_tax.contracts(request_certificates_by);
CREATE INDEX idx_inv_tax_contracts_deposit_archive_by ON inv_tax.contracts(deposit_archive_copy_by);
CREATE INDEX idx_inv_tax_contracts_communication_39_7_by ON inv_tax.contracts(communication_39_7_by);

-- Create indexes for financial amounts
CREATE INDEX idx_inv_tax_contracts_contribution_amount ON inv_tax.contracts(contribution_amount_eur);
CREATE INDEX idx_inv_tax_contracts_deduction_amount ON inv_tax.contracts(deduction_amount_eur);

-- Create GIN indexes for JSONB columns for better query performance
CREATE INDEX idx_inv_tax_contracts_required_docs_gin ON inv_tax.contracts USING GIN(required_docs);
CREATE INDEX idx_inv_tax_contracts_signatures_gin ON inv_tax.contracts USING GIN(signatures);

-- Create index for domicile requirement (useful for Canary Islands projects)
CREATE INDEX idx_inv_tax_contracts_domicile_canary ON inv_tax.contracts(domicile_required_canary);

-- Create compound indexes for common queries
CREATE INDEX idx_inv_tax_contracts_project_producer ON inv_tax.contracts(project_code, producer_name);
CREATE INDEX idx_inv_tax_contracts_project_financier ON inv_tax.contracts(project_code, financier_name);