-- Update project status enum to include new values (using public schema)
DO $$ 
BEGIN
    BEGIN
        ALTER TYPE public.project_status ADD VALUE 'DEV';
    EXCEPTION
        WHEN duplicate_object THEN null;
    END;
    BEGIN
        ALTER TYPE public.project_status ADD VALUE 'PREP';
    EXCEPTION
        WHEN duplicate_object THEN null;
    END;
    BEGIN
        ALTER TYPE public.project_status ADD VALUE 'ROD';
    EXCEPTION
        WHEN duplicate_object THEN null;
    END;
    BEGIN
        ALTER TYPE public.project_status ADD VALUE 'POST';
    EXCEPTION
        WHEN duplicate_object THEN null;
    END;
    BEGIN
        ALTER TYPE public.project_status ADD VALUE 'ENTREGADA';
    EXCEPTION
        WHEN duplicate_object THEN null;
    END;
    BEGIN
        ALTER TYPE public.project_status ADD VALUE 'CATALOGO';
    EXCEPTION
        WHEN duplicate_object THEN null;
    END;
END $$;

-- Create milestone kind enum in public schema
DO $$ 
BEGIN
    CREATE TYPE public.milestone_kind AS ENUM (
      'GREENLIGHT','PP_START','SHOOT_START','SHOOT_END','LOCK_CUT','DELIVERY_ESSENTIAL',
      'DELIVERY_COMPLETE','CERT_CULTURAL','CERT_NACIONALIDAD','CERT_36X','NOA',
      'FEST_PREMIERE','THEATRICAL_RELEASE','SVOD_START','TV_FREE_START','OTHER'
    );
EXCEPTION
    WHEN duplicate_object THEN null;
END $$;

-- Rename project_code to code if it exists
DO $$ 
BEGIN
    -- First check if project_code exists and code doesn't
    IF EXISTS (SELECT 1 FROM information_schema.columns WHERE table_schema = 'core' AND table_name = 'projects' AND column_name = 'project_code')
    AND NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_schema = 'core' AND table_name = 'projects' AND column_name = 'code') THEN
        ALTER TABLE core.projects RENAME COLUMN project_code TO code;
    END IF;
EXCEPTION
    WHEN OTHERS THEN null;
END $$;

-- Add new columns to projects table
DO $$
BEGIN
    -- Add columns one by one with error handling
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_schema = 'core' AND table_name = 'projects' AND column_name = 'original_language') THEN
        ALTER TABLE core.projects ADD COLUMN original_language text;
    END IF;
    
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_schema = 'core' AND table_name = 'projects' AND column_name = 'country_of_origin') THEN
        ALTER TABLE core.projects ADD COLUMN country_of_origin text DEFAULT 'ES';
    END IF;
    
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_schema = 'core' AND table_name = 'projects' AND column_name = 'regime') THEN
        ALTER TABLE core.projects ADD COLUMN regime text;
    END IF;
    
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_schema = 'core' AND table_name = 'projects' AND column_name = 'budget_estimated') THEN
        ALTER TABLE core.projects ADD COLUMN budget_estimated numeric(14,2);
    END IF;
    
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_schema = 'core' AND table_name = 'projects' AND column_name = 'budget_final') THEN
        ALTER TABLE core.projects ADD COLUMN budget_final numeric(14,2);
    END IF;
    
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_schema = 'core' AND table_name = 'projects' AND column_name = 'eligible_base_est') THEN
        ALTER TABLE core.projects ADD COLUMN eligible_base_est numeric(14,2);
    END IF;
    
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_schema = 'core' AND table_name = 'projects' AND column_name = 'eligible_base_final') THEN
        ALTER TABLE core.projects ADD COLUMN eligible_base_final numeric(14,2);
    END IF;
    
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_schema = 'core' AND table_name = 'projects' AND column_name = 'incentive_est') THEN
        ALTER TABLE core.projects ADD COLUMN incentive_est numeric(14,2);
    END IF;
    
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_schema = 'core' AND table_name = 'projects' AND column_name = 'incentive_final') THEN
        ALTER TABLE core.projects ADD COLUMN incentive_final numeric(14,2);
    END IF;
    
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_schema = 'core' AND table_name = 'projects' AND column_name = 'greenlight_date') THEN
        ALTER TABLE core.projects ADD COLUMN greenlight_date date;
    END IF;
    
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_schema = 'core' AND table_name = 'projects' AND column_name = 'pp_start') THEN
        ALTER TABLE core.projects ADD COLUMN pp_start date;
    END IF;
    
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_schema = 'core' AND table_name = 'projects' AND column_name = 'pp_end') THEN
        ALTER TABLE core.projects ADD COLUMN pp_end date;
    END IF;
    
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_schema = 'core' AND table_name = 'projects' AND column_name = 'shoot_start') THEN
        ALTER TABLE core.projects ADD COLUMN shoot_start date;
    END IF;
    
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_schema = 'core' AND table_name = 'projects' AND column_name = 'shoot_end') THEN
        ALTER TABLE core.projects ADD COLUMN shoot_end date;
    END IF;
    
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_schema = 'core' AND table_name = 'projects' AND column_name = 'post_start') THEN
        ALTER TABLE core.projects ADD COLUMN post_start date;
    END IF;
    
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_schema = 'core' AND table_name = 'projects' AND column_name = 'post_end') THEN
        ALTER TABLE core.projects ADD COLUMN post_end date;
    END IF;
    
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_schema = 'core' AND table_name = 'projects' AND column_name = 'lock_cut_date') THEN
        ALTER TABLE core.projects ADD COLUMN lock_cut_date date;
    END IF;
    
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_schema = 'core' AND table_name = 'projects' AND column_name = 'delivery_essential_date') THEN
        ALTER TABLE core.projects ADD COLUMN delivery_essential_date date;
    END IF;
    
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_schema = 'core' AND table_name = 'projects' AND column_name = 'delivery_complete_date') THEN
        ALTER TABLE core.projects ADD COLUMN delivery_complete_date date;
    END IF;
END $$;

-- Update defaults 
ALTER TABLE core.projects ALTER COLUMN currency SET DEFAULT 'EUR';

-- Create project milestones table
CREATE TABLE IF NOT EXISTS core.project_milestones(
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  project_id uuid NOT NULL REFERENCES core.projects(id) ON DELETE CASCADE,
  kind public.milestone_kind NOT NULL,
  planned_date date,
  actual_date date,
  is_blocking boolean DEFAULT false,
  notes text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create project parties table
CREATE TABLE IF NOT EXISTS core.project_parties(
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  project_id uuid NOT NULL REFERENCES core.projects(id) ON DELETE CASCADE,
  role text NOT NULL, 
  name text NOT NULL,
  vat_or_reg text, 
  email text, 
  phone text, 
  address text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create release dates table
CREATE TABLE IF NOT EXISTS core.release_dates(
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  project_id uuid NOT NULL REFERENCES core.projects(id) ON DELETE CASCADE,
  territory text NOT NULL,
  media text NOT NULL,
  planned_date date, 
  actual_date date,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Add unique constraints
DO $$
BEGIN
    IF NOT EXISTS (SELECT 1 FROM information_schema.table_constraints WHERE constraint_name = 'project_parties_unique_role_name') THEN
        ALTER TABLE core.project_parties ADD CONSTRAINT project_parties_unique_role_name UNIQUE(project_id, role, name);
    END IF;
    
    IF NOT EXISTS (SELECT 1 FROM information_schema.table_constraints WHERE constraint_name = 'release_dates_unique_territory_media') THEN
        ALTER TABLE core.release_dates ADD CONSTRAINT release_dates_unique_territory_media UNIQUE(project_id, territory, media);
    END IF;
END $$;

-- Create trigger function for updating timestamps
CREATE OR REPLACE FUNCTION core.touch_updated_at() 
RETURNS TRIGGER AS $$
BEGIN 
  NEW.updated_at = now(); 
  RETURN NEW; 
END $$ LANGUAGE plpgsql;

-- Create triggers for new tables
DROP TRIGGER IF EXISTS trg_project_milestones_touch ON core.project_milestones;
CREATE TRIGGER trg_project_milestones_touch 
  BEFORE UPDATE ON core.project_milestones
  FOR EACH ROW EXECUTE FUNCTION core.touch_updated_at();

DROP TRIGGER IF EXISTS trg_project_parties_touch ON core.project_parties;
CREATE TRIGGER trg_project_parties_touch 
  BEFORE UPDATE ON core.project_parties
  FOR EACH ROW EXECUTE FUNCTION core.touch_updated_at();

DROP TRIGGER IF EXISTS trg_release_dates_touch ON core.release_dates;
CREATE TRIGGER trg_release_dates_touch 
  BEFORE UPDATE ON core.release_dates
  FOR EACH ROW EXECUTE FUNCTION core.touch_updated_at();

-- Update existing projects trigger
DROP TRIGGER IF EXISTS trg_projects_touch ON core.projects;
CREATE TRIGGER trg_projects_touch 
  BEFORE UPDATE ON core.projects
  FOR EACH ROW EXECUTE FUNCTION core.touch_updated_at();

-- Enable RLS on new tables
ALTER TABLE core.project_milestones ENABLE ROW LEVEL SECURITY;
ALTER TABLE core.project_parties ENABLE ROW LEVEL SECURITY;
ALTER TABLE core.release_dates ENABLE ROW LEVEL SECURITY;

-- Drop existing policies if they exist
DROP POLICY IF EXISTS "Project access for milestones" ON core.project_milestones;
DROP POLICY IF EXISTS "Project access for parties" ON core.project_parties;
DROP POLICY IF EXISTS "Project access for release dates" ON core.release_dates;

-- RLS Policies for project milestones
CREATE POLICY "Project access for milestones" 
ON core.project_milestones 
FOR ALL 
USING (public.has_project_access(auth.uid(), project_id));

-- RLS Policies for project parties
CREATE POLICY "Project access for parties" 
ON core.project_parties 
FOR ALL 
USING (public.has_project_access(auth.uid(), project_id));

-- RLS Policies for release dates
CREATE POLICY "Project access for release dates" 
ON core.release_dates 
FOR ALL 
USING (public.has_project_access(auth.uid(), project_id));

-- Create indexes for better performance
CREATE INDEX IF NOT EXISTS idx_projects_status ON core.projects(status);
CREATE INDEX IF NOT EXISTS idx_project_milestones_project_id ON core.project_milestones(project_id);
CREATE INDEX IF NOT EXISTS idx_project_milestones_kind ON core.project_milestones(kind);
CREATE INDEX IF NOT EXISTS idx_project_parties_project_id ON core.project_parties(project_id);
CREATE INDEX IF NOT EXISTS idx_release_dates_project_id ON core.release_dates(project_id);