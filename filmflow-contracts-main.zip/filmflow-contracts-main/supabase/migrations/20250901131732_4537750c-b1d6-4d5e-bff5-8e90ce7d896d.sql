-- Add missing columns to doc_index table
ALTER TABLE public.doc_index 
ADD COLUMN IF NOT EXISTS mime_type TEXT,
ADD COLUMN IF NOT EXISTS metadata JSONB;