-- Update project status enum to include new values
ALTER TYPE core.project_status ADD VALUE IF NOT EXISTS 'PREP';
ALTER TYPE core.project_status ADD VALUE IF NOT EXISTS 'ROD'; 
ALTER TYPE core.project_status ADD VALUE IF NOT EXISTS 'POST';
ALTER TYPE core.project_status ADD VALUE IF NOT EXISTS 'ENTREGADA';
ALTER TYPE core.project_status ADD VALUE IF NOT EXISTS 'CATALOGO';

-- Create milestone kind enum
CREATE TYPE core.milestone_kind AS ENUM (
  'GREENLIGHT','PP_START','SHOOT_START','SHOOT_END','LOCK_CUT','DELIVERY_ESSENTIAL',
  'DELIVERY_COMPLETE','CERT_CULTURAL','CERT_NACIONALIDAD','CERT_36X','NOA',
  'FEST_PREMIERE','THEATRICAL_RELEASE','SVOD_START','TV_FREE_START','OTHER'
);

-- Update projects table to match requirements
ALTER TABLE core.projects 
  RENAME COLUMN project_code TO code;

-- Add new columns to projects table
ALTER TABLE core.projects 
  ADD COLUMN IF NOT EXISTS original_language text,
  ADD COLUMN IF NOT EXISTS country_of_origin text DEFAULT 'ES',
  ADD COLUMN IF NOT EXISTS regime text,
  ADD COLUMN IF NOT EXISTS budget_estimated numeric(14,2),
  ADD COLUMN IF NOT EXISTS budget_final numeric(14,2),
  ADD COLUMN IF NOT EXISTS eligible_base_est numeric(14,2),
  ADD COLUMN IF NOT EXISTS eligible_base_final numeric(14,2),
  ADD COLUMN IF NOT EXISTS incentive_est numeric(14,2),
  ADD COLUMN IF NOT EXISTS incentive_final numeric(14,2),
  ADD COLUMN IF NOT EXISTS greenlight_date date,
  ADD COLUMN IF NOT EXISTS pp_start date,
  ADD COLUMN IF NOT EXISTS pp_end date,
  ADD COLUMN IF NOT EXISTS shoot_start date,
  ADD COLUMN IF NOT EXISTS shoot_end date,
  ADD COLUMN IF NOT EXISTS post_start date,
  ADD COLUMN IF NOT EXISTS post_end date,
  ADD COLUMN IF NOT EXISTS lock_cut_date date,
  ADD COLUMN IF NOT EXISTS delivery_essential_date date,
  ADD COLUMN IF NOT EXISTS delivery_complete_date date;

-- Update default status
ALTER TABLE core.projects ALTER COLUMN status SET DEFAULT 'DEV';

-- Add constraint for code format
ALTER TABLE core.projects 
  ADD CONSTRAINT IF NOT EXISTS projects_code_format 
  CHECK (code ~ '^[A-Z0-9_]+$');

-- Update currency default and constraint
ALTER TABLE core.projects ALTER COLUMN currency SET DEFAULT 'EUR';
ALTER TABLE core.projects 
  ADD CONSTRAINT IF NOT EXISTS projects_currency_length 
  CHECK (length(currency) = 3);

-- Create project milestones table
CREATE TABLE IF NOT EXISTS core.project_milestones(
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  project_id uuid NOT NULL REFERENCES core.projects(id) ON DELETE CASCADE,
  kind core.milestone_kind NOT NULL,
  planned_date date,
  actual_date date,
  is_blocking boolean DEFAULT false,
  notes text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create project parties table
CREATE TABLE IF NOT EXISTS core.project_parties(
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  project_id uuid NOT NULL REFERENCES core.projects(id) ON DELETE CASCADE,
  role text NOT NULL, 
  name text NOT NULL,
  vat_or_reg text, 
  email text, 
  phone text, 
  address text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  UNIQUE(project_id, role, name)
);

-- Create release dates table
CREATE TABLE IF NOT EXISTS core.release_dates(
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  project_id uuid NOT NULL REFERENCES core.projects(id) ON DELETE CASCADE,
  territory text NOT NULL,
  media text NOT NULL,
  planned_date date, 
  actual_date date,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  UNIQUE(project_id, territory, media)
);

-- Create trigger function for updating timestamps
CREATE OR REPLACE FUNCTION core.touch_updated_at() 
RETURNS TRIGGER AS $$
BEGIN 
  NEW.updated_at = now(); 
  RETURN NEW; 
END $$ LANGUAGE plpgsql;

-- Create triggers for new tables
DROP TRIGGER IF EXISTS trg_project_milestones_touch ON core.project_milestones;
CREATE TRIGGER trg_project_milestones_touch 
  BEFORE UPDATE ON core.project_milestones
  FOR EACH ROW EXECUTE FUNCTION core.touch_updated_at();

DROP TRIGGER IF EXISTS trg_project_parties_touch ON core.project_parties;
CREATE TRIGGER trg_project_parties_touch 
  BEFORE UPDATE ON core.project_parties
  FOR EACH ROW EXECUTE FUNCTION core.touch_updated_at();

DROP TRIGGER IF EXISTS trg_release_dates_touch ON core.release_dates;
CREATE TRIGGER trg_release_dates_touch 
  BEFORE UPDATE ON core.release_dates
  FOR EACH ROW EXECUTE FUNCTION core.touch_updated_at();

-- Update existing projects trigger
DROP TRIGGER IF EXISTS trg_projects_touch ON core.projects;
CREATE TRIGGER trg_projects_touch 
  BEFORE UPDATE ON core.projects
  FOR EACH ROW EXECUTE FUNCTION core.touch_updated_at();

-- Enable RLS on new tables
ALTER TABLE core.project_milestones ENABLE ROW LEVEL SECURITY;
ALTER TABLE core.project_parties ENABLE ROW LEVEL SECURITY;
ALTER TABLE core.release_dates ENABLE ROW LEVEL SECURITY;

-- RLS Policies for project milestones
CREATE POLICY "Project access for milestones" 
ON core.project_milestones 
FOR ALL 
USING (public.has_project_access(auth.uid(), project_id));

-- RLS Policies for project parties
CREATE POLICY "Project access for parties" 
ON core.project_parties 
FOR ALL 
USING (public.has_project_access(auth.uid(), project_id));

-- RLS Policies for release dates
CREATE POLICY "Project access for release dates" 
ON core.release_dates 
FOR ALL 
USING (public.has_project_access(auth.uid(), project_id));

-- Create indexes for better performance
CREATE INDEX IF NOT EXISTS idx_projects_code ON core.projects(code);
CREATE INDEX IF NOT EXISTS idx_projects_status ON core.projects(status);
CREATE INDEX IF NOT EXISTS idx_project_milestones_project_id ON core.project_milestones(project_id);
CREATE INDEX IF NOT EXISTS idx_project_milestones_kind ON core.project_milestones(kind);
CREATE INDEX IF NOT EXISTS idx_project_parties_project_id ON core.project_parties(project_id);
CREATE INDEX IF NOT EXISTS idx_release_dates_project_id ON core.release_dates(project_id);