import express from 'express';
import cors from 'cors';
import multer from 'multer';
import { fileURLToPath } from 'url';
import { dirname, join } from 'path';
import dotenv from 'dotenv';
import * as pdfjs from 'pdfjs-dist/build/pdf.js';
import { createCanvas } from 'canvas';

// Configure canvas for PDF.js in Node.js
const NodeCanvasFactory = {
  create: (width, height) => {
    const canvas = createCanvas(width, height);
    const context = canvas.getContext('2d');
    return { canvas, context };
  },
  reset: (canvasAndContext, width, height) => {
    canvasAndContext.canvas.width = width;
    canvasAndContext.canvas.height = height;
  },
  destroy: (canvasAndContext) => {
    canvasAndContext.canvas.width = 0;
    canvasAndContext.canvas.height = 0;
    canvasAndContext.canvas = null;
    canvasAndContext.context = null;
  }
};

// Set PDF.js worker
const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

dotenv.config();

const app = express();
const port = process.env.PORT || 3001;

// Middleware
app.use(cors());
app.use(express.json({ limit: '50mb' }));

// Configure multer for file uploads
const storage = multer.memoryStorage();
const upload = multer({ 
  storage,
  limits: { fileSize: 50 * 1024 * 1024 } // 50MB limit
});

// PDF text extraction endpoint
app.post('/api/extract', upload.single('file'), async (req, res) => {
  try {
    if (!req.file) {
      return res.status(400).json({ error: 'No file provided' });
    }

    console.log(`Extracting text from ${req.file.originalname} (${req.file.mimetype})`);

    let extractedText = '';

    if (req.file.mimetype === 'application/pdf') {
      extractedText = await extractTextFromPDF(req.file.buffer);
    } else if (req.file.mimetype.startsWith('text/')) {
      extractedText = req.file.buffer.toString('utf-8');
    } else {
      return res.status(400).json({ 
        error: 'Unsupported file type. Only PDF and text files are supported.' 
      });
    }

    // Sanitize text for database storage
    const sanitizedText = extractedText
      .replace(/\u0000/g, '') // Remove null bytes
      .replace(/[\u0001-\u0008\u000B\u000C\u000E-\u001F\u007F-\u009F]/g, '') // Remove control characters
      .replace(/\uFFFD/g, ''); // Remove replacement characters

    console.log(`Text extracted successfully. Length: ${sanitizedText.length} characters`);

    res.json({
      success: true,
      extractedText: sanitizedText,
      metadata: {
        filename: req.file.originalname,
        mimetype: req.file.mimetype,
        size: req.file.size,
        textLength: sanitizedText.length
      }
    });

  } catch (error) {
    console.error('Text extraction error:', error);
    res.status(500).json({ 
      error: 'Failed to extract text from document',
      details: error.message 
    });
  }
});

async function extractTextFromPDF(buffer) {
  try {
    // Load PDF document
    const loadingTask = pdfjs.getDocument({
      data: buffer,
      canvasFactory: NodeCanvasFactory,
      isEvalSupported: false,
      useSystemFonts: true
    });
    
    const pdfDocument = await loadingTask.promise;
    console.log(`PDF loaded. Pages: ${pdfDocument.numPages}`);

    const textContent = [];

    // Extract text from each page
    for (let pageNum = 1; pageNum <= pdfDocument.numPages; pageNum++) {
      try {
        const page = await pdfDocument.getPage(pageNum);
        const content = await page.getTextContent();
        
        // Extract text items and combine them
        const pageText = content.items
          .filter(item => item.str && item.str.trim())
          .map(item => item.str)
          .join(' ');

        if (pageText.trim()) {
          // Filter out XMP metadata and DocuSign signatures
          if (!isMetadataOrSignature(pageText)) {
            console.log(`Page ${pageNum}: ${pageText.length} characters extracted`);
            textContent.push(pageText);
          } else {
            console.log(`Page ${pageNum}: Filtered out metadata/signature content`);
          }
        }
      } catch (pageError) {
        console.error(`Error extracting text from page ${pageNum}:`, pageError);
        // Continue with other pages
      }
    }

    await pdfDocument.destroy();

    if (textContent.length === 0) {
      return 'No extractable text content found in PDF';
    }

    const fullText = textContent.join('\n\n').trim();
    
    // Pre-classify document types
    const detectedType = detectDocumentType(fullText);
    if (detectedType) {
      console.log(`Detected document type: ${detectedType}`);
      return `[DOCUMENT_TYPE_DETECTED: ${detectedType}]\n\n${fullText}`;
    }

    return fullText;

  } catch (error) {
    console.error('PDF processing error:', error);
    throw new Error(`Failed to process PDF: ${error.message}`);
  }
}

function isMetadataOrSignature(text) {
  const metadataIndicators = [
    'xmp:',
    'adobe:ns:meta',
    'rdf:Description',
    'dc:creator',
    'xap:CreatorTool',
    'DocuSign',
    'digitally signed',
    'certificate',
    'W5M0MpCehiHzreSzNTczkc9d',
    'application/pdf'
  ];

  const normalizedText = text.toLowerCase();
  
  // Check for metadata indicators
  if (metadataIndicators.some(indicator => normalizedText.includes(indicator.toLowerCase()))) {
    return true;
  }

  // Check for high ratio of non-readable characters
  const readableChars = text.match(/[a-zA-Z0-9\s.,;:!?\-()]/g) || [];
  const readableRatio = readableChars.length / text.length;
  
  if (readableRatio < 0.6) {
    return true; // Likely binary/encoded content
  }

  // Check for very short pages that are mostly symbols
  if (text.length < 100 && !/[a-zA-Z]{10,}/.test(text)) {
    return true;
  }

  return false;
}

function detectDocumentType(text) {
  const normalizedText = text.toLowerCase();
  
  // AFMA document detection
  if (normalizedText.includes('afma') || 
      normalizedText.includes('australian film') ||
      normalizedText.includes('screen australia')) {
    return 'AFMA';
  }
  
  // IFTA document detection
  if (normalizedText.includes('ifta') || 
      normalizedText.includes('international film') ||
      normalizedText.includes('sales agent agreement')) {
    return 'IFTA';
  }

  // Contract detection
  if (normalizedText.includes('contrato') || 
      normalizedText.includes('contract') ||
      normalizedText.includes('agreement')) {
    return 'CONTRACT';
  }

  // Invoice detection
  if (normalizedText.includes('factura') || 
      normalizedText.includes('invoice') ||
      normalizedText.includes('billing')) {
    return 'INVOICE';
  }

  return null;
}

// Health check endpoint
app.get('/health', (req, res) => {
  res.json({ status: 'ok', service: 'PDF Extractor Service' });
});

app.listen(port, () => {
  console.log(`PDF Extractor Service running on port ${port}`);
  console.log(`Health check: http://localhost:${port}/health`);
  console.log(`Extract endpoint: POST http://localhost:${port}/api/extract`);
});