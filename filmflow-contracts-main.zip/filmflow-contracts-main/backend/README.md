# PDF Extractor Service

Node.js service for extracting text from PDF documents using pdfjs-dist.

## Features

- Proper PDF content stream extraction using pdfjs-dist
- Filters out XMP metadata and DocuSign signatures  
- Document type detection (AFMA, IFTA, contracts, invoices)
- Text sanitization for database storage
- CORS enabled for web applications

## Setup

1. Install dependencies:
```bash
npm install
```

2. Copy environment variables:
```bash
cp .env.example .env
```

3. Start the service:
```bash
# Development
npm run dev

# Production
npm start
```

## API Endpoints

### POST /api/extract
Extract text from uploaded PDF or text files.

**Request:**
- Multipart form with 'file' field
- Supports PDF and text files up to 50MB

**Response:**
```json
{
  "success": true,
  "extractedText": "Document content...",
  "metadata": {
    "filename": "document.pdf",
    "mimetype": "application/pdf", 
    "size": 1234567,
    "textLength": 5000
  }
}
```

### GET /health
Service health check.

## Usage with Supabase Edge Functions

Update your edge function to call this service instead of doing PDF parsing in Deno:

```javascript
// In your edge function
const formData = new FormData();
formData.append('file', fileBlob);

const response = await fetch('http://your-service-url/api/extract', {
  method: 'POST',
  body: formData
});

const result = await response.json();
```

## Deployment

Deploy to any Node.js hosting service (Railway, Render, Fly.io, etc.) and update your edge function to use the deployed URL.